# 爬虫调度入口
# 读取 search_plan → 调用各平台爬虫 → 去重 → 补邮箱 → 过滤 → 输出 customers.json

import hashlib
import json
import logging
import os
import shutil
import time
from typing import Any, Dict, List, Optional

from config import CRAWLER_CONFIG

from crawler_plugins import alibaba_rfq, made_in_china, globalsources, ddg_search, bing_search
from crawler_plugins.contact_scanner import scan as scan_contact
from crawler_plugins._common import random_delay
from company_analyzer import analyze_company

logger = logging.getLogger(__name__)

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
CUSTOMERS_JSON = os.path.join(DATA_DIR, "customers.json")

os.makedirs(DATA_DIR, exist_ok=True)


def run(product_id: str = "") -> bool:
    """执行一次完整的爬虫流程。

    流程：
    1. 优先读取 buyer_strategy.json（新），其次 search_plan.json（旧）
    2. 依次搜索各平台
    3. 按公司官网去重
    4. 调用 contact_scanner 补邮箱
    5. 调用 filter 做规则过滤
    6. 输出到 data/customers.json

    Args:
        product_id: 产品 ID，可选。为空时自动查找最新 search_plan。

    Returns:
        True 表示成功（至少有一条结果），False 表示失败。
    """
    start_time = time.time()

    # 每次运行前重置搜索计数器
    ddg_search.reset_count()
    bing_search.reset_count()

    # ── 1. 读取策略（优先 buyer_strategy，其次 search_plan） ──
    search_plan = load_search_plan(product_id)
    if search_plan is None:
        logger.error("run: 未找到 search_plan，无法执行爬虫")
        return False

    # 尝试加载 buyer_strategy（新版）
    buyer_strategy = None

    # 先判断 load_search_plan 返回的是不是 buyer_strategy
    if "product_info" in search_plan:
        # load_search_plan 直接返回了 buyer_strategy
        buyer_strategy = search_plan
    elif product_id:
        # 按 product_id 单独加载 buyer_strategy 文件
        bs_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json")
        if os.path.exists(bs_path):
            with open(bs_path, "r", encoding="utf-8") as f:
                buyer_strategy = json.load(f)

    # 从 buyer_strategy 提取搜索词
    search_queries = []
    target_industries = search_plan.get("target_industries", [])
    target_countries = search_plan.get("target_countries", [])
    product_name = search_plan.get("product_name", "")

    if buyer_strategy:
        # 新版：使用 buyer_strategy 的搜索词
        all_queries = buyer_strategy.get("search_strategy", {}).get("search_queries", [])
        # 每次随机抽取 12 个，保证每次跑的结果不同
        if len(all_queries) > 12:
            import random
            random.shuffle(all_queries)
            search_queries = all_queries[:12]
            logger.info(f"使用 buyer_strategy: {len(all_queries)} 个搜索词池，本轮抽取 {len(search_queries)} 个")
        else:
            search_queries = all_queries
            logger.info(f"使用 buyer_strategy: {len(search_queries)} 个搜索词")
        target_industries = buyer_strategy.get("buyer_analysis", {}).get("buyer_industries", [])
        product_name = buyer_strategy.get("product_info", {}).get("product_name", product_name)
    else:
        # 旧版：使用 search_plan 的关键词
        keywords = search_plan.get("keywords", [])
        search_queries = keywords[:3] if keywords else []
        target_industries = search_plan.get("target_industries", [])
        logger.info(f"使用 search_plan: {len(search_queries)} 个关键词")

    if not search_queries:
        logger.error("run: 无搜索词")
        return False

    logger.info(
        f"=== 开始爬虫任务 ==="
        f"\n  产品: {product_name}"
        f"\n  搜索词数: {len(search_queries)}"
        f"\n  目标行业: {target_industries[:3]}..."
        f"\n  目标国家: {target_countries}"
    )

    # ── 2. 执行各平台爬虫 ───────────────────────────────────
    all_customers: list[dict] = []

    daily_limit = CRAWLER_CONFIG.get("daily_limit", 200)
    per_source_limit = CRAWLER_CONFIG.get("per_source_limit", 50)

    for kw in search_queries:
        if len(all_customers) >= daily_limit:
            break

        logger.info(f"--- 搜索: {kw[:60]} ---")

        # Alibaba RFQ
        try:
            results = alibaba_rfq.search(kw, target_countries[0] if target_countries else "")
            _add_results(all_customers, results, "阿里巴巴", per_source_limit)
            logger.info(f"  alibaba_rfq: {len(results)} 条")
        except Exception as e:
            logger.error(f"  alibaba_rfq 异常: {e}")
        random_delay(2, 4)

        # Made-in-China
        try:
            results = made_in_china.search(kw, target_countries[0] if target_countries else "")
            _add_results(all_customers, results, "中国制造网", per_source_limit)
            logger.info(f"  made_in_china: {len(results)} 条")
        except Exception as e:
            logger.error(f"  made_in_china 异常: {e}")
        random_delay(2, 4)

        # Global Sources
        try:
            results = globalsources.search(kw, target_countries[0] if target_countries else "")
            _add_results(all_customers, results, "Global Sources", per_source_limit)
            logger.info(f"  globalsources: {len(results)} 条")
        except Exception as e:
            logger.error(f"  globalsources 异常: {e}")
        random_delay(2, 4)

        # DuckDuckGo 搜索
        try:
            results = ddg_search.search(
                kw,
                target_countries[0] if target_countries else "",
                industries=target_industries,
            )
            _add_results(all_customers, results, "DuckDuckGo", per_source_limit)
            logger.info(f"  ddg_search: {len(results)} 条")
        except Exception as e:
            logger.error(f"  ddg_search 异常: {e}")
        random_delay(3, 6)

        # Bing 搜索（DDG 不可用时的备用方案）
        try:
            results = bing_search.search(
                kw,
                target_countries[0] if target_countries else "",
                industries=target_industries,
            )
            _add_results(all_customers, results, "Bing", per_source_limit)
            logger.info(f"  bing_search: {len(results)} 条")
        except Exception as e:
            logger.error(f"  bing_search 异常: {e}")
        random_delay(2, 4)

    logger.info(f"合并前共 {len(all_customers)} 条")

    # ── 3. 去重（按公司官网） ────────────────────────────────
    deduped = _deduplicate(all_customers)
    logger.info(f"去重后共 {len(deduped)} 条")

    # ── 3.5. 跳过已推荐客户 ──────────────────────────────────
    known_set = load_known_set()
    before_skip = len(deduped)
    deduped = [c for c in deduped if not is_known(c, known_set)]
    skipped = before_skip - len(deduped)
    if skipped:
        logger.info(f"跳过已推荐客户 {skipped} 条")

    if not deduped:
        logger.warning("run: 去重且跳过已推荐后无新客户")
        _save_customers(deduped, product_name, search_plan)
        return False

    # ── 4. contact_scanner 补邮箱 ────────────────────────────
    _enrich_emails(deduped)

    # ── 5. filter 规则过滤 ──────────────────────────────────
    from filter import filter_customers

    filtered = filter_customers(deduped)
    logger.info(f"过滤后共 {len(filtered)} 条")

    # ── 6. AI 公司分析（判断是否买家） ──────────────────────
    if filtered and buyer_strategy:
        logger.info("开始 AI 公司分析...")
        analyzed_count = 0
        for c in filtered:
            analysis = analyze_company(c, buyer_strategy)
            c["ai_analysis"] = analysis
            grade = analysis.get("grade", "D")
            if grade in ("A", "B", "C"):
                c["buyer_score"] = analysis.get("confidence", 50)
                c["buyer_reason"] = analysis.get("reason", "")
                c["buyer_type"] = analysis.get("buyer_type", "")
                c["candidate_grade"] = grade
                analyzed_count += 1
        logger.info(f"AI 分析完成: {analyzed_count}/{len(filtered)} 个候选人")

    # ── 6.5. 筛选精品 ────────────────────────────────────
    before_quality = len(filtered)
    if buyer_strategy:
        # 有AI分析：按等级筛选
        filtered = [
            c for c in filtered
            if c.get("email")
            and c.get("candidate_grade") in ("A", "B", "C")
        ]
    else:
        # 无AI分析：只要求有邮箱
        filtered = [c for c in filtered if c.get("email")]
    quality_dropped = before_quality - len(filtered)
    logger.info(f"质量筛选: {quality_dropped} 条因无邮箱/低分被丢弃, 保留 {len(filtered)} 条")

    if not filtered:
        logger.warning("run: 质量筛选后无有效客户")
        # 仍保存空列表（更新已推荐名单）
        _save_customers(filtered, product_name, search_plan)
        return False

    # ── 7. 输出 ─────────────────────────────────────────────
    _save_customers(filtered, product_name, search_plan)

    elapsed = time.time() - start_time
    logger.info(
        f"=== 爬虫任务完成 ==="
        f"\n  耗时: {elapsed:.1f}s"
        f"\n  输出: {CUSTOMERS_JSON}"
        f"\n  新增优质客户: {len(filtered)}"
    )
    return True


# ── 内部函数 ──────────────────────────────────────────────────


def load_search_plan(product_id: str = "") -> Optional[dict]:
    """加载搜索策略。优先 search_plan，其次 buyer_strategy。"""
    if product_id:
        # search_plan 优先
        plan_path = os.path.join(
            PRODUCT_DATA_DIR, f"{product_id}_search_plan.json"
        )
        if os.path.exists(plan_path):
            with open(plan_path, "r", encoding="utf-8") as f:
                return json.load(f)

        # buyer_strategy 兜底
        bs_path = os.path.join(
            PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json"
        )
        if os.path.exists(bs_path):
            with open(bs_path, "r", encoding="utf-8") as f:
                return json.load(f)

        logger.warning(f"搜索策略不存在: {product_id}")
        return None

    # 未指定 product_id → 找最新的
    if not os.path.isdir(PRODUCT_DATA_DIR):
        return None

    plan_files = []
    for f in os.listdir(PRODUCT_DATA_DIR):
        if f.endswith("_search_plan.json") or f.endswith("_buyer_strategy.json"):
            plan_files.append(f)
    if not plan_files:
        return None

    # 按修改时间排序，取最新的
    plan_files.sort(
        key=lambda f: os.path.getmtime(os.path.join(PRODUCT_DATA_DIR, f)),
        reverse=True,
    )
    latest = os.path.join(PRODUCT_DATA_DIR, plan_files[0])
    with open(latest, "r", encoding="utf-8") as f:
        return json.load(f)


def format_product_info(plan: dict) -> str:
    """将 search_plan 格式化为产品描述文本（供 matcher/mail_generator 使用）。"""
    parts = [
        f"产品名称: {plan.get('product_name', '')}",
        f"关键词: {', '.join(plan.get('keywords', []))}",
        f"目标行业: {', '.join(plan.get('target_industries', []))}",
        f"目标国家: {', '.join(plan.get('target_countries', []))}",
        f"HS编码: {', '.join(plan.get('hs_codes', []))}",
        f"主要竞争对手: {', '.join(plan.get('competitors', []))}",
    ]
    return "\n".join(parts)


def _add_results(
    pool: list, new_results: list, source: str, limit: int
) -> None:
    """将爬虫结果加入总池，标注来源，不超过 limit。"""
    for r in new_results:
        r["source"] = source
        r["crawl_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    pool.extend(new_results[:limit])


def _deduplicate(customers: list) -> list:
    """按公司官网去重，无官网的按公司名去重。"""
    seen_websites: set = set()
    seen_names: set = set()
    result: list = []

    for c in customers:
        website = (c.get("website") or "").strip().lower()
        name = (c.get("company_name") or "").strip().lower()

        if website and website not in seen_websites:
            seen_websites.add(website)
            result.append(c)
        elif not website and name and name not in seen_names:
            seen_names.add(name)
            result.append(c)

    return result


def _enrich_emails(customers: list) -> None:
    """并行扫描公司网站补邮箱（最多 10 线程）。"""
    import concurrent.futures

    def _scan_one(c):
        if c.get("email"):
            return
        website = c.get("website", "")
        if not website:
            return
        logger.info(f"contact_scanner: 扫描 {website}")
        try:
            email = scan_contact(website)
            if email:
                c["email"] = email
                c["email_source"] = "官网扫描"
                logger.info(f"  -> 找到邮箱: {email}")
        except Exception as e:
            logger.error(f"contact_scanner 扫描失败 {website}: {e}")

    to_scan = [c for c in customers if not c.get("email") and c.get("website")]
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
        pool.map(_scan_one, to_scan)


def _ensure_customer_id(customer: dict) -> dict:
    """为单条客户生成稳定 customer_id（sha256 截取 16 位）"""
    if customer.get("customer_id"):
        return customer

    company_name = (customer.get("company_name") or "").strip()
    website = (customer.get("website") or "").strip()
    email = (customer.get("email") or "").strip()
    country = (customer.get("country") or "").strip()

    if website:
        raw = f"{website}|{company_name}".lower()
    else:
        raw = f"{email}|{company_name}|{country}".lower()

    customer["customer_id"] = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return customer


def load_known_set() -> set:
    """加载已推荐客户的特征集合（website + company_name），用于跳过。

    Returns:
        已推荐特征集合，元素格式为 "website:xxx" 或 "name:xxx"。
    """
    known: set = set()
    if not os.path.exists(CUSTOMERS_JSON):
        return known
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        for c in data.get("customers", []):
            w = (c.get("website") or "").strip().lower()
            if w:
                known.add(f"website:{w}")
            n = (c.get("company_name") or "").strip().lower()
            if n:
                known.add(f"name:{n}")
    except Exception:
        pass
    return known


def is_known(company: dict, known_set: set) -> bool:
    """检查公司是否已在已推荐名单中。"""
    w = (company.get("website") or "").strip().lower()
    if w and f"website:{w}" in known_set:
        return True
    n = (company.get("company_name") or "").strip().lower()
    if n and f"name:{n}" in known_set:
        return True
    return False


def delete_customer(customer_id: str) -> bool:
    """从数据库中删除指定客户。

    Args:
        customer_id: 客户唯一 ID。

    Returns:
        True 表示删除成功，False 表示未找到。
    """
    if not os.path.exists(CUSTOMERS_JSON):
        return False
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return False

    old_len = len(data.get("customers", []))
    data["customers"] = [c for c in data.get("customers", []) if c.get("customer_id") != customer_id]
    data["meta"] = data.get("meta", {})
    data["meta"]["total"] = len(data["customers"])

    if len(data["customers"]) == old_len:
        return False  # 没找到

    _atomic_save_customers(
        customers=data["customers"],
        meta=data["meta"],
        customers_json_path=CUSTOMERS_JSON,
    )
    return True


def _atomic_save_customers(
    customers: List[dict],
    meta: Dict[str, Any],
    *,
    customers_json_path: str,
) -> None:
    """
    三段式原子写入 + meta 深合并：
    1. copy2 备份旧文件 → .bak
    2. 写入临时文件 → .tmp
    3. os.replace 原子替换
    meta 深合并：保留已有全部字段，只补充/覆盖新 stage 信息
    """
    # 读取现有文件
    existing = None
    if os.path.exists(customers_json_path):
        try:
            with open(customers_json_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            existing = None

    existing_meta = {}
    if existing and isinstance(existing, dict):
        existing_meta = existing.get("meta", {}) or {}

    # 深合并 meta
    def deep_merge(a: dict, b: dict) -> dict:
        out = dict(a)
        for k, v in b.items():
            if k in out and isinstance(out[k], dict) and isinstance(v, dict):
                out[k] = deep_merge(out[k], v)
            else:
                out[k] = v
        return out

    merged_meta = deep_merge(existing_meta, meta)
    payload = {"meta": merged_meta, "customers": customers}

    # 备份旧文件（copy2 保留原文件，避免写入失败时丢失）
    bak_path = f"{customers_json_path}.bak"
    tmp_path = f"{customers_json_path}.tmp"

    if os.path.exists(customers_json_path):
        try:
            shutil.copy2(customers_json_path, bak_path)
        except Exception:
            pass

    # 写入临时文件
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    # 原子替换
    os.replace(tmp_path, customers_json_path)


def _save_customers(customers: list, product_name: str, search_plan: dict) -> None:
    """保存客户数据到 data/customers.json（增量累积，不覆盖后续阶段字段）"""
    # 读取现有客户（按 customer_id 建立索引）
    existing_customers: list[dict] = []
    if os.path.exists(CUSTOMERS_JSON):
        try:
            with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
                existing_data = json.load(f)
            existing_customers = existing_data.get("customers", []) or []
        except Exception:
            pass

    # 为现有客户补 customer_id
    for c in existing_customers:
        _ensure_customer_id(c)

    by_id: dict[str, dict] = {}
    for c in existing_customers:
        if isinstance(c, dict) and c.get("customer_id"):
            by_id[c["customer_id"]] = c

    # crawler 负责的字段白名单（只更新这些，不覆盖后续阶段字段）
    CRAWLER_FIELDS = {
        "company_name", "country", "website", "email",
        "requirement", "industry", "source", "crawl_time",
        "priority", "filter_reason", "business_type", "name_type",
        "email_source",
    }

    # 新客户生成 customer_id 并按字段白名单合并
    for c in customers:
        _ensure_customer_id(c)
        cid = c.get("customer_id")
        if not cid:
            continue

        if cid not in by_id:
            # 新客户：整条加入
            by_id[cid] = dict(c)
        else:
            # 已有客户：只更新 crawler 负责的字段，保留后续阶段字段
            target = by_id[cid]
            for k in CRAWLER_FIELDS:
                if k in c:
                    target[k] = c[k]

    merged = list(by_id.values())

    # 写入 meta
    output_meta = {
        "total": len(merged),
        "stages": {
            "crawled": {
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                "product_name": product_name,
                "product_id": search_plan.get("product_id", ""),
                "keywords_used": search_plan.get("keywords", []),
            }
        }
    }

    _atomic_save_customers(
        customers=merged,
        meta=output_meta,
        customers_json_path=CUSTOMERS_JSON,
    )


def get_customers() -> list:
    """读取已保存的客户列表。

    Returns:
        客户列表，文件不存在或解析失败返回空列表。
    """
    if not os.path.exists(CUSTOMERS_JSON):
        return []
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("customers", [])
    except Exception:
        return []