"""
公司分析器（Company Analyzer v1.0）

核心功能：
1. 读取公司信息（名称、网站、摘要）
2. 访问公司官网首页，让 AI 判断公司类型
3. 综合判断：这个公司是不是潜在买家？评分多少？

与旧 filter.py 的区别：
- filter.py 做规则过滤（国家、MX 解析）
- company_analyzer.py 做 AI 理解（这个公司做什么的、会不会买我们的产品）
"""

import json
import logging
import re
from typing import Optional

import requests

from translator import ai_chat

logger = logging.getLogger(__name__)


def analyze_company(company: dict, strategy: dict) -> dict:
    """分析单个公司是否值得开发。

    三道闸门：
    1. 页面类型判断 → 是公司官网/产品页，还是文章/博客？
    2. 产品匹配判断 → 这家公司消耗我们的产品吗？
    3. 采购信号判断 → 有没有采购需求？

    Args:
        company: 公司信息（含 company_name, website, requirement 等）
        strategy: 买家策略（来自 buyer_profile_generator）

    Returns:
        分析结果：
        {
            "is_buyer": True/False,
            "confidence": 0-100,
            "reason": "判断理由",
            "buyer_type": "买家类型",
            "company_type": "公司类型",
            "grade": "A/B/C/D",
            "page_type": "company_homepage / blog_article / directory / unknown",
        }
    """
    company_name = company.get("company_name", "")
    website = company.get("website", "")
    snippet = company.get("requirement", "")

    # ── 第一关：URL 前置过滤 ──
    # 明显不是公司页面的 URL 直接降级，不浪费 AI 调用
    url_check = _check_url_type(website)
    if url_check == "blog_article":
        return _grade_result(company_name, "D", "非公司页面：博客/文章", "页面类型: 博客或文章，不是公司官网")
    if url_check == "directory":
        return _grade_result(company_name, "D", "非公司页面：目录页", "页面类型: 目录或聚合页面")
    if url_check == "association":
        return _grade_result(company_name, "D", "行业协会", "页面类型: 行业协会，非采购企业")
    if url_check == "news":
        return _grade_result(company_name, "C", "新闻页面", "页面类型: 新闻，需要人工确认公司信息")

    # 没有官网的，凭摘要信息简单判断
    if not website:
        return _analyze_by_snippet(company_name, snippet, strategy)

    # 有官网的，尝试获取首页内容让 AI 判断
    homepage_content = _fetch_homepage(website)

    if homepage_content:
        return _analyze_with_ai(company_name, website, homepage_content, snippet, strategy)
    else:
        # 抓不到首页内容，改为 AI 分析 URL 和摘要
        return _analyze_by_url(company_name, website, snippet, strategy)


def _check_url_type(url: str) -> str:
    """通过 URL 路径判断页面类型。

    Returns:
        "company_homepage", "blog_article", "directory", "association", "news", "unknown"
    """
    if not url:
        return "unknown"

    url_lower = url.lower()

    # 博客/文章/指南
    blog_patterns = [
        "/blog/", "/blogs/", "/article/", "/articles/",
        "/news/", "/guide/", "/guides/", "/how-to/",
        "/tutorial/", "/faq/", "/questions/", "/wiki/",
        "/knowledge/", "/resource/", "/resources/",
        "/insights/", "/insight/", "/learn/", "/learning/",
    ]
    for p in blog_patterns:
        if p in url_lower:
            return "blog_article"

    # 目录/聚合
    directory_patterns = [
        "/directory", "/list/", "/top-", "/best-",
        "/companies/", "/suppliers/", "/vendors/",
    ]
    for p in directory_patterns:
        if p in url_lower:
            return "directory"

    # 第三方组织架构/人事页面
    org_patterns = ["theorg.com/org/", "linkedin.com/in/", "linkedin.com/company/"]
    for p in org_patterns:
        if p in url_lower:
            return "directory"

    # 行业协会
    assoc_patterns = [
        "association", "associations", "institute", "federation",
        "chamber", "council", "society",
    ]
    for p in assoc_patterns:
        if f"/{p}/" in url_lower or f"-{p}" in url_lower or url_lower.startswith(p):
            return "association"

    return "unknown"


def _fetch_homepage(url: str) -> Optional[str]:
    """获取公司官网首页的文本内容。"""
    try:
        # 尝试获取首页
        resp = requests.get(
            url,
            timeout=10,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html",
            },
        )
        if resp.status_code != 200:
            # 尝试获取根域名
            from urllib.parse import urlparse
            parsed = urlparse(url)
            base = f"{parsed.scheme}://{parsed.netloc}"
            resp = requests.get(base, timeout=10, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            })
            if resp.status_code != 200:
                return None

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "lxml")

        # 移除 script、style、nav、footer
        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()

        # 获取正文文本
        text = soup.get_text(separator=" ", strip=True)
        # 清理多余空格，截取前 2000 字符
        text = re.sub(r"\s+", " ", text)[:2000]
        return text if len(text) > 100 else None

    except Exception as e:
        logger.debug(f"获取首页失败 {url}: {e}")
        return None


def _analyze_with_ai(company_name: str, website: str, homepage: str,
                      snippet: str, strategy: dict) -> dict:
    """三道闸门分析：页面类型 → 产品匹配 → 采购信号。"""
    product_info = strategy.get("product_info", {})
    product_name = product_info.get("product_name", "")
    buyer_analysis = strategy.get("buyer_analysis", {})
    buyer_types = buyer_analysis.get("buyer_types", [])
    avoid_types = buyer_analysis.get("avoid_types", [])
    purchase_triggers = buyer_analysis.get("purchase_triggers", [])
    negative_keywords = strategy.get("search_strategy", {}).get("negative_keywords", [])

    system_prompt = (
        "你是一个B2B国际贸易采购机会分析专家 + 供应商能力匹配专家。\n"
        "你的任务不是寻找公司，而是寻找'当前存在采购可能性、且供应链未被锁定的企业'。\n\n"
        "分析时必须按以下四道闸门顺序判断：\n\n"
        "第一关：页面类型判断（最重要）\n"
        "先判断当前看到的页面是什么类型：\n"
        "- company_homepage: 公司官网首页\n"
        "- product_page: 公司产品页面\n"
        "- blog_article: 博客、文章、指南（不是公司官网，不能证明采购需求）\n"
        "- news_article: 新闻\n"
        "- directory: 公司目录、供应商列表\n"
        "- association: 行业协会\n"
        "- unknown: 无法判断\n\n"
        "如果页面类型是 blog_article / news_article / directory / association，\n"
        "直接判定为 D 级，不需要继续分析。\n\n"
        "第二关：产品匹配判断\n"
        "这家公司消耗我们的产品吗？\n"
        "例如：我们的产品是 PP 塑料粒子，\n"
        "高匹配：注塑厂、塑料包装厂、食品容器制造商、汽车塑料零件供应商\n"
        "低匹配：模具厂、塑料设计公司、塑料咨询公司、塑料新闻网站\n\n"
        "第三关：采购信号判断\n"
        "在页面内容中寻找以下采购信号：\n\n"
        "一级信号（明确采购需求）：\n"
        "- RFQ / Request for quotation\n"
        "- Supplier registration / Vendor registration\n"
        "- Tender / Procurement notice\n"
        "- Sourcing request / Looking for supplier\n\n"
        "二级信号（业务变化，可能产生采购）：\n"
        "- 扩建工厂 / New plant / Expansion\n"
        "- 新增生产线 / New production line\n"
        "- 招聘采购经理 / Procurement manager hiring\n"
        "- 新产品发布 / New product launch\n\n"
        "三级信号（供应商替换机会）：\n"
        "- Alternative supplier / Second source\n"
        "- Dual sourcing / Supplier diversification\n"
        "- Reduce cost / Cost reduction\n\n"
        "第四关（新增）：供应链开放度判断\n"
        "这是最关键的一步——判断这家公司是否容易让中国中小企业切入：\n\n"
        "高开放度（加分项）：\n"
        "- 中小型企业（员工 < 500 人）\n"
        "- 发展中地区（东南亚、中东、非洲、拉美）\n"
        "- 网站出现「join supplier」「vendor registration」「become a partner」等字眼\n"
        "- 公司描述强调成本控制或寻找全球供应商\n"
        "- 正在快速扩张的公司\n\n"
        "低开放度（降级信号）：\n"
        "- 大型跨国企业（员工 > 1000 人或全球业务）\n"
        "- 公司历史悠久（100 年+），供应链成熟\n"
        "- 欧美老牌企业，供应商体系已经完善\n"
        "- 网站没有任何供应商入口\n"
        "- 强调高端/精密/专利，不强调成本\n\n"
        "等级判定标准（结合四道关）：\n"
        "A = 明确采购需求（有一级信号）+ 高产品匹配 + 供应链开放\n"
        "B = 有业务变化信号（二级信号）+ 匹配 + 供应链开放度可接受\n"
        "C = 匹配但无信号，或匹配但供应链开放度一般（如中小企但无明确需求）\n"
        "D = 非目标（不匹配、大型跨国企业就算有需求也切不入、页面类型不对）\n"
        "注意：即使有采购信号，如果是大型跨国企业 + 欧美成熟市场 → 仍然 D 级\n\n"
        "只输出合法的 JSON，不要包含 markdown 代码块标记。"
    )

    user_prompt = f"""## 我们的产品
{product_name}

## 目标买家类型
{', '.join(buyer_types) if buyer_types else '无'}

## 要避免的类型
{', '.join(avoid_types) if avoid_types else '无'}

## 采购触发条件
{', '.join(purchase_triggers) if purchase_triggers else '无'}

## 排除关键词
{', '.join(negative_keywords) if negative_keywords else '无'}

## 公司名称
{company_name}

## 公司网站
{website}

## 页面内容
{homepage[:1500]}

## 搜索摘要
{snippet[:300] if snippet else '无'}

请按四道闸门顺序分析，输出以下 JSON：
{{
  "page_type": "company_homepage / product_page / blog_article / news_article / directory / association / unknown",
  "page_type_reason": "为什么判断是这个页面类型",

  "match_level": "high / medium / low / none",
  "match_reason": "为什么匹配或不匹配",

  "signals_found": [
    "发现的信号1",
    "发现的信号2"
  ],
  "signal_level": "level1 / level2 / level3 / none",

  "supply_chain_fit": "high / medium / low / locked",
  "supply_chain_reason": "为什么认为这家公司供应链开放度如何",

  "company_scale": "small / medium / large / multinational",

  "grade": "A / B / C / D",
  "grade_reason": "为什么是这个等级",

  "is_potential_buyer": true / false,
  "confidence": 0-100,
  "company_type": "公司类型描述",
  "buyer_type_match": "匹配的买家类型",
  "reason": "综合判断理由"
}}

等级标准：
A = 明确采购需求（有一级信号）+ 高匹配 + 供应链开放
B = 有业务变化信号（二级信号）+ 匹配 + 供应链开放度可接受
C = 匹配但无明确信号，或中小企业但信号不明确
D = 非目标（不匹配、大型跨国企业、页面类型不对）"""

    try:
        result = ai_chat(
            messages=[{"role": "user", "content": user_prompt}],
            system_prompt=system_prompt,
            temperature=0.2,
        )
        if result is None:
            return _default_result(company_name, "AI 调用失败")

        # 解析 JSON
        json_str = result.strip()
        if "```" in json_str:
            m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
            if m:
                json_str = m.group(1)
            else:
                json_str = json_str.replace("```json", "").replace("```", "").strip()

        data = json.loads(json_str)
        grade = data.get("grade", "D")
        is_buyer = grade in ("A", "B", "C")

        # 如果供应链锁定或大型跨国企业，强制降级
        supply_chain_fit = data.get("supply_chain_fit", "")
        company_scale = data.get("company_scale", "")
        if grade in ("A", "B") and (supply_chain_fit == "locked" or company_scale == "multinational"):
            logger.info(f"  供应链降级: {company_name} {grade}→C (大企业/供应链锁定)")
            grade = "C"

        confidence_map = {"A": 85, "B": 65, "C": 40, "D": 10}
        return {
            "is_buyer": is_buyer,
            "confidence": confidence_map.get(grade, 10),
            "reason": data.get("grade_reason", data.get("reason", "")),
            "buyer_type": data.get("buyer_type_match", ""),
            "company_type": data.get("company_type", ""),
            "grade": grade,
            "page_type": data.get("page_type", "unknown"),
        }

    except Exception as e:
        logger.warning(f"AI 分析异常 {company_name}: {e}")
        return _default_result(company_name, "分析异常")


def _analyze_by_url(company_name: str, website: str, snippet: str, strategy: dict) -> dict:
    """无法获取首页时，仅凭 URL 和摘要做判断。"""
    url_check = _check_url_type(website)
    if url_check in ("blog_article", "directory", "association"):
        return _grade_result(company_name, "D", f"非公司页面: {url_check}", f"URL 类型: {url_check}")

    if not snippet:
        return _grade_result(company_name, "D", "无法获取页面内容", "无首页内容且无摘要")

    # 有摘要，让 AI 做基本判断
    product_info = strategy.get("product_info", {})
    product_name = product_info.get("product_name", "")
    negative_keywords = strategy.get("search_strategy", {}).get("negative_keywords", [])

    for kw in negative_keywords:
        if kw.lower() in snippet.lower():
            return _grade_result(company_name, "D", f"摘要含排除词: {kw}", "")

    if not product_name:
        return _grade_result(company_name, "C", "仅有摘要，无法确认", "无产品信息，保守判断为 C")

    # 调用 AI 做简要判断
    system_prompt = (
        "根据公司名称和搜索摘要，快速判断这家公司是否可能采购我们的产品。\n"
        "只输出 JSON，不要解释。"
    )
    user_prompt = f"""产品: {product_name}
公司: {company_name}
网站: {website}
摘要: {snippet[:300]}

请判断：
{{
  "is_matching": true/false,
  "reason": "理由",
  "grade": "C / D"
}}"""

    try:
        result = ai_chat(messages=[{"role": "user", "content": user_prompt}], system_prompt=system_prompt, temperature=0.2)
        if result:
            json_str = result.strip()
            if "```" in json_str:
                m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
                if m:
                    json_str = m.group(1)
            data = json.loads(json_str)
            grade = data.get("grade", "D")
            return _grade_result(company_name, grade, data.get("reason", "无法获取首页内容"), "基于摘要的初步判断")
    except Exception:
        pass

    return _grade_result(company_name, "C", "无法获取首页内容，保守判断", "建议人工确认")


def _analyze_by_snippet(company_name: str, snippet: str, strategy: dict) -> dict:
    """没有官网时，仅凭搜索摘要做简单判断。"""
    if not snippet:
        return _grade_result(company_name, "D", "信息不足", "无搜索摘要，无法判断")

    # 简单关键词匹配
    negative_keywords = strategy.get("search_strategy", {}).get("negative_keywords", [])
    snippet_lower = snippet.lower()

    for kw in negative_keywords:
        if kw.lower() in snippet_lower:
            return _grade_result(company_name, "D", f"摘要含排除词: {kw}", "")

    # 无法判断，给 C 级（潜在客户，需人工确认）
    return {
        "is_buyer": None,
        "confidence": 30,
        "reason": "仅有搜索摘要，无法确认，建议人工查看",
        "buyer_type": "",
        "company_type": "",
        "grade": "C",
        "page_type": "unknown",
    }


def _grade_result(company_name: str, grade: str, reason: str, detail: str) -> dict:
    """返回分级结果。"""
    confidence_map = {"A": 85, "B": 65, "C": 40, "D": 10}
    is_buyer_map = {"A": True, "B": True, "C": None, "D": False}
    return {
        "is_buyer": is_buyer_map.get(grade, False),
        "confidence": confidence_map.get(grade, 10),
        "reason": reason,
        "buyer_type": "",
        "company_type": "",
        "grade": grade,
        "page_type": "unknown",
    }


def _default_result(company_name: str, reason: str) -> dict:
    """返回默认分析结果（D 级）。"""
    return {
        "is_buyer": None,
        "confidence": 0,
        "reason": reason,
        "buyer_type": "",
        "company_type": "",
        "grade": "D",
        "page_type": "unknown",
    }