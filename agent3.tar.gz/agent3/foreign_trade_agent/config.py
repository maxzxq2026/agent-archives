# 配置模块
# 所有配置集中管理，业务模块引用此模块获取配置
# 运行时 API 配置优先从 data/api_config.json 读取（通过 Web 界面保存）

import json
import os

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
API_CONFIG_JSON = os.path.join(_BASE_DIR, "data", "api_config.json")
SMTP_CONFIG_JSON = os.path.join(_BASE_DIR, "data", "smtp_config.json")


def _load_api_config_json() -> dict:
    """从 data/api_config.json 加载运行时 API 配置。"""
    if not os.path.isfile(API_CONFIG_JSON):
        return {}
    try:
        with open(API_CONFIG_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def _load_config_json(path: str) -> dict:
    """通用 JSON 配置文件加载。"""
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_api_config(base_url: str, api_key: str, model: str) -> dict:
    """保存 API 配置到 data/api_config.json 并更新内存中的配置。"""
    data = {"base_url": base_url, "api_key": api_key, "model": model}
    os.makedirs(os.path.dirname(API_CONFIG_JSON), exist_ok=True)
    with open(API_CONFIG_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    # 同步更新内存中的配置，当前会话立即生效
    API_CONFIG["default"]["base_url"] = base_url
    API_CONFIG["default"]["api_key"] = api_key
    API_CONFIG["default"]["model"] = model
    return data


def save_smtp_config(smtp_server: str, port: int, use_ssl: bool, email: str, password: str) -> dict:
    """保存 SMTP 配置到 data/smtp_config.json 并更新内存中的配置。"""
    data = {
        "smtp_server": smtp_server, "port": port,
        "use_ssl": use_ssl, "email": email, "password": password,
    }
    os.makedirs(os.path.dirname(SMTP_CONFIG_JSON), exist_ok=True)
    with open(SMTP_CONFIG_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    SMTP_CONFIG["default"].update(data)
    return data


# 默认 API 配置（会被 api_config.json 覆盖）
API_CONFIG = {
    "default": {
        "base_url": "",
        "api_key": "",
        "model": "",
        "vision_supported": False,
    }
}

# 运行时配置覆盖
_runtime_api = _load_api_config_json()
if _runtime_api.get("base_url"):
    API_CONFIG["default"]["base_url"] = _runtime_api["base_url"]
if _runtime_api.get("api_key"):
    API_CONFIG["default"]["api_key"] = _runtime_api["api_key"]
if _runtime_api.get("model"):
    API_CONFIG["default"]["model"] = _runtime_api["model"]

SMTP_CONFIG = {
    "default": {
        "smtp_server": "",
        "port": 465,
        "use_ssl": True,
        "email": "",
        "password": "",
    }
}

# 运行时 SMTP 配置覆盖
_runtime_smtp = _load_config_json(SMTP_CONFIG_JSON)
if _runtime_smtp.get("smtp_server"):
    SMTP_CONFIG["default"].update(_runtime_smtp)

CRAWLER_CONFIG = {
    "request_timeout": 30,
    "daily_limit": 200,
    "min_delay": 1,
    "max_delay": 4,
    "per_source_limit": 50,
    "max_retries": 1,
    "min_buyer_score": 50,  # AI 分析后，低于此分的客户不存入数据库
}

FILTER_CONFIG = {
    "match_threshold": 6,
    "max_customers_per_page": 20,
    "buyer_threshold": 50,  # 客户页面买家评分阈值
}

MAIL_CONFIG = {
    "batch_interval": 60,
    "daily_safe_limit": 50,
    "max_attachments_mb": 10,
}