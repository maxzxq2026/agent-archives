"""
Google 搜索插件。

通过 HTTP 请求 Google 搜索，提取海外公司官网和采购信息。
不需要 API Key，但需要配置 HTTP_PROXY 代理访问外网。

搜索关键词自动拼接买家意图词（importer, buyer, distributor, procurement 等），
优先找到有采购需求的海外公司。
"""

import logging
import re
import time
from typing import Optional
from urllib.parse import quote

from bs4 import BeautifulSoup

from crawler_plugins._common import (
    build_session, random_delay, safe_request,
    extract_country_from_text, is_domestic,
)

logger = logging.getLogger(__name__)

# 每天最多搜索次数（Google 对自动化搜索有限制）
DAILY_LIMIT = 80

# 意图词：搜索时自动追加，提高命中率
INTENT_KEYWORDS = [
    "importer",
    "buyer",
    "distributor",
    "wholesale",
    "procurement",
    "purchasing",
    "supplier inquiry",
    "request for quotation",
    "RFQ",
    "tender",
]

# 搜索次数计数器（进程级）
_search_count = 0


def search(keyword: str, country: str = "") -> list[dict]:
    """搜索 Google，提取海外公司信息。

    Args:
        keyword: 产品关键词（英文）。
        country: 目标国家（两位代码，如 "US"）

    Returns:
        公司信息列表，每项含 company_name, website, country, industry, requirement, email。
        失败返回空列表。
    """
    global _search_count
    results: list[dict] = []
    session = build_session()

    try:
        # 用不同的意图词组合搜索，扩大覆盖面
        search_queries = _build_search_queries(keyword, country)

        for query in search_queries:
            # 检查每日限额
            if _search_count >= DAILY_LIMIT:
                logger.info(f"google_search: 已达每日限额 {DAILY_LIMIT}，停止搜索")
                break

            search_url = f"https://www.google.com/search?q={quote(query)}&hl=en&num=10"
            logger.info(f"google_search: [{_search_count + 1}/{DAILY_LIMIT}] {search_url[:120]}")

            resp = safe_request(search_url, session=session, timeout=30)
            if resp is None:
                logger.warning("google_search: 请求失败，跳过")
                random_delay(5, 10)
                continue

            _search_count += 1

            # 检查是否被拦截
            if _is_blocked(resp.text):
                logger.warning("google_search: 检测到拦截/验证码，暂停 60 秒")
                time.sleep(60)
                continue

            # 解析搜索结果
            items = _parse_search_results(resp.text)
            logger.info(f"google_search: 解析到 {len(items)} 条结果")

            for item in items:
                if len(results) >= 20:  # 单次搜索最多取 20 条
                    break

                if not item.get("website"):
                    continue

                # 过滤国内公司
                if is_domestic(item):
                    continue

                # 去重（按网站）
                if any(r.get("website") == item["website"] for r in results):
                    continue

                results.append(item)

            if len(results) >= 20:
                break

            # 搜索间隔 3-6 秒，模拟人类行为
            random_delay(3, 6)

        logger.info(f"google_search: 最终获取 {len(results)} 条海外公司信息")
        return results

    finally:
        session.close()


def _build_search_queries(keyword: str, country: str = "") -> list[str]:
    """构建搜索词列表，组合产品和意图词。"""
    base_kw = keyword.strip()
    queries = []

    # 1. 直接搜索 + 意图词
    for intent in INTENT_KEYWORDS[:5]:  # 只用前 5 个意图词
        if country:
            queries.append(f"{base_kw} {intent} {country}")
        else:
            queries.append(f"{base_kw} {intent}")

    # 2. 用引号精确搜索采购意向
    if country:
        queries.append(f'"{base_kw}" "looking for" {country}')
        queries.append(f'"{base_kw}" "we need" {country}')
        queries.append(f'"{base_kw}" "supplier" {country}')
    else:
        queries.append(f'"{base_kw}" "looking for"')
        queries.append(f'"{base_kw}" "we need"')
        queries.append(f'"{base_kw}" "supplier"')

    return queries


def _is_blocked(html: str) -> bool:
    """检查 Google 是否返回了拦截页面。"""
    text_lower = html.lower()
    checks = [
        "unusual traffic" in text_lower,
        "captcha" in text_lower,
        "please show you're not a robot" in text_lower,
        "our systems have detected unusual traffic" in text_lower,
        "sorry, we have detected unusual traffic" in text_lower,
    ]
    return any(checks)


def _parse_search_results(html: str) -> list[dict]:
    """解析 Google 搜索结果页面，提取公司信息。"""
    soup = BeautifulSoup(html, "lxml")
    results = []

    # Google 搜索结果容器
    result_divs = soup.select("div.g, div[data-hveid], div[class*='search-result']")

    if not result_divs:
        # 兜底策略：找所有带链接的区块
        result_divs = soup.find_all("div", class_=re.compile(r"(g|result|search|item)", re.I))

    for div in result_divs:
        try:
            item = _parse_single_result(div)
            if item and item.get("website"):
                results.append(item)
        except Exception:
            continue

    return results


def _parse_single_result(div) -> Optional[dict]:
    """从单个搜索结果 div 中提取字段。"""
    # ── 网站链接 ──
    link_el = div.find("a", href=re.compile(r"^https?://"))
    if not link_el:
        return None

    href = link_el.get("href", "")
    # 去掉 Google 的跳转前缀
    if href.startswith("/url?q="):
        href = href.split("/url?q=")[1].split("&")[0]
    elif href.startswith("/search?"):
        return None  # 跳过 Google 内部链接

    # ── 公司名称 ──
    title_el = div.select_one("h3, a[class*='title'], span[class*='title']")
    company_name = title_el.get_text(strip=True) if title_el else ""

    if not company_name:
        return None

    # 过滤明显不是公司的结果
    if _is_non_company(company_name, href):
        return None

    # ── 摘要文本 ──
    snippet_el = div.select_one(
        "div[class*='VwiC3b'], span[class*='st'], div[class*='snippet'], "
        "div[class*='summary'], div[class*='description']"
    )
    snippet = snippet_el.get_text(strip=True) if snippet_el else ""

    # ── 国家 ──
    country = extract_country_from_text(snippet + " " + company_name)

    # ── 邮箱 ──
    email = ""
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", snippet)
    if email_match:
        email = email_match.group(0)

    # ── 行业 ──
    industry = ""
    # 从摘要中提取行业关键词
    industry_keywords = [
        "manufacturer", "supplier", "distributor", "wholesale",
        "retail", "industry", "company", "inc", "ltd", "gmbh",
        "corporation", "enterprise", "factory",
    ]
    for kw in industry_keywords:
        if kw in snippet.lower() or kw in company_name.lower():
            industry = kw.capitalize()
            break

    return {
        "company_name": company_name[:100],
        "website": href[:200],
        "country": country[:50] if country else "",
        "industry": industry,
        "requirement": snippet[:300],
        "email": email[:100],
    }


def _is_non_company(name: str, url: str) -> bool:
    """判断是否不是目标公司（过滤新闻、论坛、百科等）。"""
    name_lower = name.lower()
    url_lower = url.lower()

    # 排除常见非公司网站
    non_company_domains = [
        "wikipedia.org", "youtube.com", "facebook.com", "twitter.com",
        "linkedin.com", "instagram.com", "reddit.com", "pinterest.com",
        "amazon.com", "ebay.com", "aliexpress.com", "alibaba.com",
        "made-in-china.com", "globalsources.com", "indiamart.com",
        "news.", "blog.", "forums.", "community.",
    ]

    for domain in non_company_domains:
        if domain in url_lower:
            return True

    # 排除明显非公司标题
    non_company_titles = [
        "news", "article", "blog", "forum", "review", "video",
        "how to", "what is", "top 10", "best",
    ]

    for t in non_company_titles:
        if name_lower.startswith(t):
            return True

    return False


def reset_count():
    """重置搜索计数器（每天首次调用时执行）。"""
    global _search_count
    _search_count = 0