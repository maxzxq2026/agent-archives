"""
Bing 搜索插件。

通过 requests 访问 Bing 网页搜索，解析结果页面获取公司信息。
不需要任何 API Key，Bing 在国内可正常访问。
"""

import logging
import random
import re
from typing import Optional
from urllib.parse import quote_plus, urlparse, parse_qs

import base64

import requests
from bs4 import BeautifulSoup

from crawler_plugins._common import (
    random_delay, extract_country_from_text, is_domestic, is_valid_email,
)

logger = logging.getLogger(__name__)

# 每天最多搜索次数
DAILY_LIMIT = 100

# 轮换 User-Agent
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
]

# 搜索计数器
_search_count = 0


def _random_ua() -> str:
    return random.choice(USER_AGENTS)


def search(keyword: str, country: str = "", industries: Optional[list[str]] = None) -> list[dict]:
    """通过 Bing 搜索海外公司信息。

    Args:
        keyword: 搜索关键词（英文）。
        country: 目标国家（可选）。
        industries: 目标行业列表（暂未使用，保留接口兼容）。

    Returns:
        公司信息列表，每项含 company_name, website, country, industry, requirement, email。
    """
    global _search_count
    results: list[dict] = []

    # 直接搜关键词
    query = keyword.strip()
    if country:
        query = f"{keyword} {country}"

    if _search_count >= DAILY_LIMIT:
        logger.info(f"bing_search: 已达每日限额 {DAILY_LIMIT}")
        return results

    search_url = f"https://www.bing.com/search?q={quote_plus(query)}&count=30"
    logger.info(f"bing_search: [{_search_count + 1}/{DAILY_LIMIT}] {query[:80]}")

    try:
        resp = requests.get(
            search_url,
            timeout=30,
            headers={
                "User-Agent": _random_ua(),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
            },
        )
    except Exception as e:
        logger.warning(f"bing_search: 请求失败: {e}")
        return results

    _search_count += 1

    if resp.status_code != 200:
        logger.warning(f"bing_search: HTTP {resp.status_code}")
        return results

    items = _parse_results(resp.text)
    logger.info(f"bing_search: 解析到 {len(items)} 条结果")

    for item in items:
        if len(results) >= 20:
            break
        if not item.get("website"):
            continue
        if is_domestic(item):
            continue
        if any(r.get("website") == item["website"] for r in results):
            continue
        results.append(item)

    logger.info(f"bing_search: 最终获取 {len(results)} 条海外公司信息")
    return results


def _parse_results(html: str) -> list[dict]:
    """解析 Bing 搜索结果。"""
    soup = BeautifulSoup(html, "lxml")
    results = []

    # Bing 的结果容器：li.b_algo
    result_items = soup.select("li.b_algo")
    if not result_items:
        # 备用选择器
        result_items = soup.find_all("li", class_=re.compile(r"b_algo|b_ans"))

    for item in result_items:
        try:
            parsed = _parse_single(item)
            if parsed:
                results.append(parsed)
        except Exception:
            continue

    return results


def _clean_company_name(text: str) -> str:
    """从标题文本中提取干净的公司名。"""
    text = text.strip()

    # 按分隔符拆分
    separators = [" | ", " - ", " — ", ": ", " – "]
    parts = [text]
    for sep in separators:
        if sep in text:
            parts = [p.strip() for p in text.split(sep) if p.strip()]
            break

    noise_words = [
        "news", "trends", "solutions", "article", "blog", "how to",
        "top 10", "best", "guide", "review", "home", "contact us",
    ]

    if len(parts) == 1:
        return text[:100]

    valid = [p for p in parts if len(p) >= 2]
    clean = [p for p in valid if not any(nw in p.lower() for nw in noise_words)]
    if clean:
        return min(clean, key=len)[:100]
    return min(valid, key=len)[:100]


def _extract_real_url(href: str) -> str:
    """从 Bing 的跳转链接中提取真实 URL。

    Bing 搜索结果链接格式：
    https://www.bing.com/ck/a?...&u=a1aHR0cHM6Ly93d3cuZXhhbXBsZS5jb20v
    u 参数是 base64 编码的真实 URL。
    """
    if "bing.com" not in href.lower():
        return href

    try:
        parsed = urlparse(href)
        qs = parse_qs(parsed.query)
        u_param = qs.get("u", [None])[0]
        if u_param:
            # 补全 base64 padding
            padding = 4 - len(u_param) % 4
            if padding != 4:
                u_param += "=" * padding
            real_url = base64.urlsafe_b64decode(u_param).decode("utf-8")
            if real_url:
                return real_url
    except Exception:
        pass

    return href


def _is_non_company(name: str, url: str) -> bool:
    """判断是否非目标公司。"""
    name_lower = name.lower()
    url_lower = url.lower()

    exclude_domains = [
        "wikipedia.org", "youtube.com", "facebook.com", "twitter.com",
        "instagram.com", "reddit.com", "pinterest.com", "amazon.com",
        "ebay.com", "aliexpress.com", "alibaba.com", "made-in-china.com",
        "globalsources.com", "indiamart.com", "news.", "blog.",
    ]
    for domain in exclude_domains:
        if domain in url_lower:
            return True

    exclude_titles = [
        "news", "article", "blog", "forum", "review", "video",
        "how to", "what is", "top 10", "best",
    ]
    for t in exclude_titles:
        if name_lower.startswith(t):
            return True

    return False


def _parse_single(item) -> Optional[dict]:
    """从单个搜索结果中提取字段。"""
    # 标题链接
    title_link = item.select_one("a")
    if not title_link:
        return None

    # 优先从 <cite> 标签提取真实 URL（Bing 在 cite 里渲染的是纯文本网址）
    cite_el = item.select_one("cite, span.b_primaryText, span.fz-14")
    if cite_el:
        href = cite_el.get_text(strip=True)
        # cite 里的 URL 可能省略了协议
        if href and not href.startswith(("http://", "https://")):
            href = "https://" + href.split("/")[0]  # 只取域名部分
    else:
        # 没有 cite 标签才用 href 属性
        href = title_link.get("href", "")
        # 尝试从 Bing 跳转链接提取
        if "bing.com/ck/a" in href.lower():
            from urllib.parse import urlparse, parse_qs
            try:
                parsed = urlparse(href)
                qs = parse_qs(parsed.query)
                u_param = qs.get("u", [None])[0]
                if u_param:
                    import base64
                    padding = 4 - len(u_param) % 4
                    if padding != 4:
                        u_param += "=" * padding
                    real_url = base64.b64decode(u_param).decode("utf-8")
                    if real_url:
                        href = real_url
            except Exception:
                pass
    raw_text = title_link.get_text(strip=True)
    if not raw_text or len(raw_text) < 3:
        return None

    # 提取公司名
    company_name = _clean_company_name(raw_text)
    if not company_name or len(company_name) < 2:
        return None

    if _is_non_company(company_name, href):
        return None

    # 摘要
    snippet_el = item.select_one(".b_caption p, .b_lineclamp2, .b_snippet")
    snippet = snippet_el.get_text(strip=True) if snippet_el else ""

    # 国家
    country = extract_country_from_text(snippet + " " + company_name)

    # 邮箱
    email = ""
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", snippet)
    if email_match:
        candidate = email_match.group(0)
        if is_valid_email(candidate):
            email = candidate

    return {
        "company_name": company_name[:100],
        "website": href[:200],
        "country": country[:50] if country else "",
        "industry": "",
        "requirement": snippet[:300],
        "email": email[:100],
    }


def reset_count():
    """重置搜索计数器。"""
    global _search_count
    _search_count = 0
