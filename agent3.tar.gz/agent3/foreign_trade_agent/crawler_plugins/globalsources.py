"""
Global Sources (globalsources.com) 采购需求爬虫插件。

搜索 Global Sources 上的海外采购需求（Buying Leads），
提取海外采购商信息。只爬静态 HTML，不处理 JS 渲染。
"""

import logging
import re
from typing import Optional

from bs4 import BeautifulSoup

from crawler_plugins._common import (
    build_session, random_delay, safe_request,
    extract_text, extract_country_from_text, is_domestic,
)

logger = logging.getLogger(__name__)

MAX_RESULTS = 50


def search(keyword: str, country: str = "") -> list[dict]:
    """搜索 Global Sources 采购需求页面。

    Args:
        keyword: 搜索关键词（英文）。
        country: 国家过滤（可选，两位国家代码，如 "US"）。

    Returns:
        采购商信息列表，每项含 company_name, website, country, industry, requirement, email。
        失败返回空列表。
    """
    results: list[dict] = []
    session = build_session()

    try:
        search_url = _build_url(keyword, country)
        logger.info(f"globalsources 开始搜索: {search_url}")

        resp = safe_request(search_url, session=session)
        if resp is None:
            logger.warning("globalsources: 请求失败，跳过")
            return results

        soup = BeautifulSoup(resp.text, "lxml")
        items = _extract_lead_items(soup)

        logger.info(f"globalsources: 解析到 {len(items)} 条采购需求条目")

        for item in items:
            if len(results) >= MAX_RESULTS:
                break

            parsed = _parse_single_item(item)
            if parsed and parsed.get("company_name"):
                if is_domestic(parsed):
                    continue
                results.append(parsed)
                random_delay(1, 2)

        logger.info(f"globalsources: 最终获取 {len(results)} 条海外采购商信息")
        return results

    finally:
        session.close()


def _build_url(keyword: str, country: str = "") -> str:
    """构建 Global Sources 采购需求搜索 URL。"""
    kw = keyword.strip().replace(" ", "+")
    url = f"https://www.globalsources.com/buying-leads/search?keyword={kw}"
    if country:
        url += f"&country={country}"
    return url


def _extract_lead_items(soup: BeautifulSoup) -> list:
    """提取采购需求条目容器。"""
    selectors = [
        "div[class*='lead-item']",
        "div[class*='buying-lead']",
        "div[class*='buyinglead']",
        "div[class*='gs-lead']",
        "div[class*='sourcing-item']",
        "div[class*='result-item']",
        "div[class*='purchase-item']",
        "li[class*='lead-item']",
        "div[class*='product-item']",
        "div[class*='list-item']",
    ]

    for selector in selectors:
        items = soup.select(selector)
        if items:
            return items

    items = soup.find_all("div", class_=re.compile(r"(lead|buying|sourcing|purchase|requirement)", re.I))
    if not items:
        items = soup.find_all("li", class_=re.compile(r"(lead|item|result)", re.I))
    return items


def _parse_single_item(item) -> Optional[dict]:
    """从单个条目 HTML 中提取字段。"""
    try:
        text = item.get_text(separator=" ", strip=True)

        # ── 公司名称 ────────────────────────────────────────
        company_name = extract_text(item, [
            "a[class*='company']", "span[class*='company']",
            "a[class*='supplier']", "span[class*='supplier']",
            "a[class*='buyer']", "span[class*='buyer']",
            "a[class*='name']", "span[class*='name']",
            "a[class*='store']", "span[class*='store']",
            "a[class*='member']", "span[class*='member']",
            "a[class*='vendor']", "span[class*='vendor']",
        ])
        if not company_name:
            for a in item.find_all("a", href=True):
                txt = a.get_text(strip=True)
                if len(txt) > 3:
                    company_name = txt
                    break

        if not company_name:
            return None

        # ── 国家 ────────────────────────────────────────────
        country = extract_text(item, [
            "span[class*='country']", "span[class*='location']",
            "span[class*='region']", "span[class*='place']",
            "img[class*='flag']", "i[class*='flag']",
            "span[class*='area']", "span[class*='origin']",
        ])
        if not country:
            country = extract_country_from_text(text)

        # ── 行业 ────────────────────────────────────────────
        industry = extract_text(item, [
            "a[class*='category']", "span[class*='category']",
            "a[class*='industry']", "span[class*='industry']",
            "span[class*='cate']", "a[class*='cate']",
            "span[class*='breadcrumb']", "a[class*='breadcrumb']",
        ])

        # ── 需求描述 ────────────────────────────────────────
        requirement = extract_text(item, [
            "h2", "h3", "h4",
            "p[class*='desc']", "div[class*='desc']",
            "p[class*='title']", "a[class*='title']",
            "p[class*='detail']", "div[class*='detail']",
            "p[class*='requirement']", "div[class*='requirement']",
            "div[class*='content']", "p[class*='content']",
            "p[class*='text']", "div[class*='text']",
            "div[class*='product-name']", "a[class*='product-name']",
        ])
        if not requirement:
            lines = [p.get_text(strip=True) for p in item.find_all(["p", "h2", "h3", "h4", "div", "span"])
                     if len(p.get_text(strip=True)) > 15]
            if lines:
                requirement = lines[0]

        requirement = re.sub(r"\s+", " ", requirement).strip()[:500]

        # ── 邮箱 ────────────────────────────────────────────
        email = ""
        email_el = item.select_one("a[href*='mailto:']")
        if email_el:
            email = email_el["href"].replace("mailto:", "").strip()
        if not email:
            match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
            if match:
                email = match.group(0)

        # ── 网站 ────────────────────────────────────────────
        website = ""
        link = item.find("a", href=re.compile(r"^(https?://|//)"))
        if link:
            href = link.get("href", "")
            if href.startswith("//"):
                href = "https:" + href
            website = href

        return {
            "company_name": company_name[:100],
            "website": website[:200],
            "country": country[:50],
            "industry": industry[:100] if industry else "",
            "requirement": requirement,
            "email": email[:100],
        }
    except Exception:
        return None


def extract_text(soup_item, selectors: list) -> str:
    for sel in selectors:
        el = soup_item.select_one(sel)
        if el:
            txt = el.get_text(strip=True)
            if txt:
                return txt
    return ""


def extract_country_from_text(text: str) -> str:
    pattern = re.compile(
        r"\b(India|Pakistan|Bangladesh|Vietnam|Indonesia|Thailand|Malaysia|Philippines|"
        r"Singapore|South Korea|Japan|Taiwan|China|Turkey|UAE|Saudi Arabia|Egypt|"
        r"Nigeria|South Africa|Kenya|Ethiopia|Ghana|USA|Canada|Mexico|Brazil|Argentina|"
        r"Chile|Colombia|Peru|UK|Germany|France|Italy|Spain|Netherlands|Poland|"
        r"Australia|New Zealand|Russia|Ukraine|Kazakhstan|Uzbekistan|Korea|Iran|Iraq)\b",
        re.I,
    )
    m = pattern.search(text)
    return m.group(1) if m else ""


def is_domestic(entry: dict) -> bool:
    """判断是否国内（中国/香港），是则跳过。"""
    country = (entry.get("country") or "").lower()
    if country in ("china", "cn", "hong kong", "hk"):
        return True
    name = entry.get("company_name", "")
    if re.search(r"[一-鿿]", name):
        return True
    return False
