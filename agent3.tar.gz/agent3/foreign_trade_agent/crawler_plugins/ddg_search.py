"""
DuckDuckGo 搜索插件。

通过 cloudscraper 访问 DuckDuckGo 的 HTML 版本（html.duckduckgo.com），
搜索海外公司官网和采购信息。不需要任何 API Key。

DuckDuckGo 对自动化请求相对友好，配合 cloudscraper 可绕过大多数反爬保护。
"""

import logging
import random
import re
from typing import Optional

import requests
import urllib3
from bs4 import BeautifulSoup

from crawler_plugins._common import (
    random_delay, extract_country_from_text, is_domestic, is_valid_email,
)

# 禁用 SSL 警告（DDG 的 SSL 策略变动频繁）
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

# 每天最多搜索次数
DAILY_LIMIT = 80

# 买家意图词——找行业里需要采购产品的公司，而非供应商
INDUSTRY_INTENTS = [
    "importer", "distributor", "wholesaler",
    "processor", "molder", "packaging manufacturer",
    "parts manufacturer", "industrial buyer",
    "applications", "uses",
]

# 轮换 User-Agent，降低被检测概率
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
]

# 搜索计数器
_search_count = 0


def _is_english(text: str) -> bool:
    """判断文本是否纯英文（不含中文字符）。"""
    for ch in text:
        cp = ord(ch)
        if cp >= 0x4E00 and cp <= 0x9FFF:  # 中日韩统一表意文字
            return False
        if cp >= 0x3000 and cp <= 0x303F:  # 中日韩符号和标点
            return False
    return True


def _random_ua() -> str:
    """随机返回一个 User-Agent。"""
    return random.choice(USER_AGENTS)


def search(keyword: str, country: str = "", industries: Optional[list[str]] = None) -> list[dict]:
    """通过 DuckDuckGo 搜索海外公司信息。

    核心思路：不搜"谁在买这个产品"，而是搜"谁是做这个行业的"。
    比如木浆 → 搜造纸厂、包装厂；保温杯 → 搜户外用品商、礼品公司。

    Args:
        keyword: 产品关键词（英文）。
        country: 目标国家（可选）。
        industries: 目标行业列表（来自 search_plan）。

    Returns:
        公司信息列表，每项含 company_name, website, country, industry, requirement, email。
    """
    global _search_count
    results: list[dict] = []

    search_queries = _build_search_queries(keyword, country, industries)

    for query in search_queries:
        if _search_count >= DAILY_LIMIT:
            logger.info(f"ddg_search: 已达每日限额 {DAILY_LIMIT}")
            break

        search_url = (
            f"https://html.duckduckgo.com/html/"
            f"?q={query.replace(' ', '+')}"
        )
        logger.info(f"ddg_search: [{_search_count + 1}/{DAILY_LIMIT}] {query[:80]}")

        try:
            resp = requests.get(
                search_url,
                timeout=30,
                verify=False,
                headers={
                    "User-Agent": _random_ua(),
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "en-US,en;q=0.5",
                    "Accept-Encoding": "gzip, deflate, br",
                    "Connection": "keep-alive",
                    "DNT": "1",
                    "Upgrade-Insecure-Requests": "1",
                },
            )
        except Exception as e:
            logger.warning(f"ddg_search: 请求失败: {e}")
            random_delay(5, 10)
            continue

        _search_count += 1

        if resp.status_code != 200:
            logger.warning(f"ddg_search: HTTP {resp.status_code}")
            continue

        # 解析结果
        items = _parse_results(resp.text)
        logger.info(f"ddg_search: 解析到 {len(items)} 条结果")

        for item in items:
            if len(results) >= 20:
                break
            if not item.get("website"):
                continue
            if is_domestic(item):
                continue
            if any(r.get("website") == item["website"] for r in results):
                continue
            results.append(item)

        if len(results) >= 20:
            break

        random_delay(3, 6)

    logger.info(f"ddg_search: 最终获取 {len(results)} 条海外公司信息")
    return results


def _build_search_queries(
    keyword: str, country: str = "",
    industries: Optional[list[str]] = None,
) -> list[str]:
    """构建搜索词列表。

    核心策略：
    - 优先用 AI 给的关键词直接搜（不动它）
    - 然后行业词 + 买家意图词补搜
    - 排除 supplier/manufacturer/factory/china 等中国供应商噪声
    - 跳过非英文的行业词（如中文行业名）
    """
    kw = keyword.strip()
    exclude = " -supplier -manufacturer -factory -china -alibaba -made-in-china"
    queries: list[str] = []

    # ── 策略 1：AI 给的词直接搜（最优先） ──
    queries.append(f"{kw}{exclude}")
    if country:
        queries.append(f"{kw} {country}{exclude}")

    # ── 策略 2：行业词 + 买家意图词补搜（只取英文行业词） ──
    if industries:
        for industry in industries:
            ind = industry.strip()
            if not ind:
                continue
            if not _is_english(ind):
                logger.debug(f"跳过非英文行业词: {ind}")
                continue
            # 每个行业取 2-3 个意图词
            for intent in INDUSTRY_INTENTS[:3]:
                queries.append(f"{ind} {intent}{exclude}")
                if country:
                    queries.append(f"{ind} {intent} {country}{exclude}")
    else:
        # 没有行业词时，用 AI 词 + 场景词补搜
        for scene in ["importer", "distributor"]:
            queries.append(f"{kw} {scene}{exclude}")

    # 去重（保留顺序）
    seen: set[str] = set()
    unique: list[str] = []
    for q in queries:
        ql = q.lower().strip()
        if ql not in seen:
            seen.add(ql)
            unique.append(q)
    return unique


def _parse_results(html: str) -> list[dict]:
    """解析 DuckDuckGo 搜索结果。"""
    soup = BeautifulSoup(html, "lxml")
    results = []

    # DuckDuckGo 结果容器
    result_divs = soup.select("div.result, div[class*='result__'], div[class*='web-result']")
    if not result_divs:
        result_divs = soup.find_all("div", class_=re.compile(r"result", re.I))

    for div in result_divs:
        try:
            item = _parse_single(div)
            if item:
                results.append(item)
        except Exception:
            continue

    return results


def _clean_company_name(link_text: str, url: str) -> str:
    """从搜索结果链接文本中提取干净的公司名。

    DuckDuckGo 返回的链接文本通常是网页 <title>，夹杂大量噪音：
    "PMMI, The Association for Packaging..." → "PMMI"
    "PackagingConnections | Packaging News, Trends..." → "PackagingConnections"
    "High-Performance Custom PP Granules - Azoligo" → "Azoligo"

    策略：按常见分隔符拆分，取最短的像公司名的部分。
    """
    from urllib.parse import urlparse

    text = link_text.strip()

    # 常见噪音词（文章标题、产品描述中经常出现，但不在公司名里）
    noise_words = [
        "news", "trends", "solutions", "article", "blog", "how to",
        "top 10", "best", "guide", "review", "high-performance",
        "high-quality", "custom", "trusted", "leading", "premium",
    ]

    # 按常见分隔符拆分
    separators = [" | ", " - ", " — ", ": ", " – ", ", ", " › ", " » ", " · "]
    parts = [text]
    for sep in separators:
        if sep in text:
            parts = [p.strip() for p in text.split(sep) if p.strip()]
            break

    if len(parts) == 1:
        # 没有分隔符，直接当公司名用（但要够短）
        if len(text) <= 60:
            return text[:100]

    # 有多个部分：优先取不含噪音词、最短的那个
    valid = [p for p in parts if len(p) >= 2]
    if not valid:
        valid = parts

    # 先找不含噪音词的
    clean = [p for p in valid if not any(nw in p.lower() for nw in noise_words)]
    if clean:
        # 取最短的（通常是公司名）
        return min(clean, key=len)[:100]

    # 都不干净，取最短的
    return min(valid, key=len)[:100]


def _parse_single(div) -> Optional[dict]:
    """从单个结果 div 中提取字段。"""
    # 标题链接
    title_link = div.select_one("a.result__a, a[class*='title'], h2 a, a[href^='http']")
    if not title_link:
        return None

    href = title_link.get("href", "")
    # DuckDuckGo 的链接是跳转链接，需要提取真实 URL
    if "uddg=" in href:
        from urllib.parse import parse_qs, urlparse
        parsed = urlparse(href)
        qs = parse_qs(parsed.query)
        href = qs.get("uddg", [href])[0]

    raw_link_text = title_link.get_text(strip=True)
    if not raw_link_text or len(raw_link_text) < 3:
        return None

    # 从链接文本中提取干净的公司名（不再直接当公司名用）
    company_name = _clean_company_name(raw_link_text, href)
    if not company_name or len(company_name) < 2:
        return None

    # 过滤非公司链接
    if _is_non_company(company_name, href):
        return None

    # 摘要
    snippet_el = div.select_one(
        "a.result__snippet, span.result__snippet, "
        "div[class*='snippet'], div[class*='summary']"
    )
    snippet = snippet_el.get_text(strip=True) if snippet_el else ""

    # 国家
    country = extract_country_from_text(snippet + " " + company_name)

    # 邮箱
    email = ""
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", snippet)
    if email_match:
        candidate = email_match.group(0)
        if is_valid_email(candidate):
            email = candidate

    # 行业
    industry = _detect_industry(snippet, company_name)

    return {
        "company_name": company_name[:100],
        "website": href[:200],
        "country": country[:50] if country else "",
        "industry": industry,
        "requirement": snippet[:300],
        "email": email[:100],
    }


def _detect_industry(snippet: str, name: str) -> str:
    """从文本中猜测行业。"""
    text = (snippet + " " + name).lower()
    keywords = {
        "Manufacturer": ["manufacturer", "factory", "producer", "maker", "oem"],
        "Supplier": ["supplier", "vendor", "wholesale", "distributor"],
        "Importer": ["importer", "import", "buyer", "purchasing"],
        "Trading": ["trading", "export", "international trade"],
    }
    for industry, words in keywords.items():
        for w in words:
            if w in text:
                return industry
    return ""


def _is_non_company(name: str, url: str) -> bool:
    """判断是否非目标公司。"""
    name_lower = name.lower()
    url_lower = url.lower()

    exclude_domains = [
        "wikipedia.org", "youtube.com", "facebook.com", "twitter.com",
        "instagram.com", "reddit.com", "pinterest.com", "amazon.com",
        "ebay.com", "aliexpress.com", "alibaba.com", "made-in-china.com",
        "globalsources.com", "indiamart.com", "news.", "blog.",
    ]
    for domain in exclude_domains:
        if domain in url_lower:
            return True

    exclude_titles = [
        "news", "article", "blog", "forum", "review", "video",
        "how to", "what is", "top 10", "best",
    ]
    for t in exclude_titles:
        if name_lower.startswith(t):
            return True

    return False


def reset_count():
    """重置搜索计数器。"""
    global _search_count
    _search_count = 0