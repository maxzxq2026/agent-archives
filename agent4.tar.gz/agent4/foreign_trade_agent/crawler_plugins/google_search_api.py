"""
Google Custom Search API 搜索插件 - V4 新增

通过 Google 官方 API 搜索，需配置 API Key 和 Search Engine ID。
"""

import logging
import re
from typing import Optional
from urllib.parse import urlparse

import requests

from crawler_plugins._common import extract_country_from_text, is_valid_email
from search_cache import get_cached, set_cache

logger = logging.getLogger(__name__)


def search(keyword: str, country: str = "",
           industries: Optional[list] = None) -> list[dict]:
    """通过 Google Custom Search API 搜索海外公司。

    Args:
        keyword: 搜索关键词（英文）。
        country: 目标国家（可选）。
        industries: 目标行业列表（保留接口兼容）。

    Returns:
        公司信息列表。
    """
    from config import get_search_config
    cfg = get_search_config().get("google", {})
    if not cfg.get("enabled", False):
        logger.info("google_search_api: 未启用")
        return []

    api_key = cfg.get("api_key", "")
    cx = cfg.get("cx", "")
    if not api_key or not cx:
        logger.warning("google_search_api: API Key 或 CX 未配置")
        return []

    query = keyword.strip()
    if country:
        query = f"{keyword} {country}"

    # 检查缓存
    cached = get_cached("google", query, country)
    if cached is not None:
        return cached

    # 检查配额（只检查，不记录）
    if not check_quota("google"):
        logger.warning(f"google_search_api: 今日额度已用完")
        return []

    url = "https://www.googleapis.com/customsearch/v1"
    params = {"key": api_key, "cx": cx, "q": query, "num": 10, "hl": "en"}

    logger.info(f"google_search_api: 搜索 '{query[:80]}'")

    try:
        resp = requests.get(url, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"google_search_api: 请求失败: {e}")
        return []

    items = data.get("items", [])
    logger.info(f"google_search_api: 返回 {len(items)} 条")

    results = []
    for item in items:
        parsed = _parse_item(item)
        if parsed:
            results.append(parsed)

    # 缓存结果
    set_cache("google", query, country, results)

    # 记录用量（此时已有实际结果数）
    record_search("google", query, results_count=len(items),
                  clean_count=len(results))

    return results


def _parse_item(item: dict) -> Optional[dict]:
    """解析单条 Google 搜索结果。"""
    link = item.get("link", "")
    title = item.get("title", "")
    snippet = item.get("snippet", "")

    if not link or not title:
        return None

    company_name = title[:100]

    country = extract_country_from_text(snippet + " " + title)

    email = ""
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", snippet)
    if email_match:
        candidate = email_match.group(0)
        if is_valid_email(candidate):
            email = candidate

    return {
        "company_name": company_name,
        "website": link[:500],
        "country": country[:50] if country else "",
        "industry": "",
        "requirement": snippet[:500],
        "email": email[:100],
        "source": "google_api",
    }