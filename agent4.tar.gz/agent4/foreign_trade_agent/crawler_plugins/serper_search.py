"""
Serper.dev SERP API 搜索插件。

通过 Serper.dev API 获取 Google 搜索结果。
POST https://google.serper.dev/search
认证方式：X-API-KEY Header

配置：
  - api_key: Serper.dev API Key
  - daily_limit: 每日搜索限制
"""

import logging
import re
from typing import Optional

import requests

from crawler_plugins._common import extract_country_from_text, is_valid_email
from search_cache import get_cached, set_cache

logger = logging.getLogger(__name__)


def search(keyword: str, country: str = "",
           industries: Optional[list] = None) -> list[dict]:
    """通过 Serper.dev API 搜索海外公司。

    Args:
        keyword: 搜索关键词（英文）。
        country: 目标国家（可选，传国家名即可）。
        industries: 目标行业列表（保留接口兼容）。

    Returns:
        公司信息列表，每项含 company_name, website, country, industry, requirement, email。
    """
    from config import check_quota, record_search

    # 读取配置
    try:
        from config import get_search_config
        cfg = get_search_config().get("serper", {})
    except Exception:
        cfg = {}

    api_key = cfg.get("api_key", "")
    if not api_key:
        logger.warning("serper_search: API Key 未配置")
        return []

    query = keyword.strip()
    if not query:
        return []

    # 检查缓存
    cached = get_cached("serper", query, country)
    if cached is not None:
        return cached

    # 检查配额
    if not check_quota("serper"):
        logger.warning("serper_search: 今日额度已用完")
        return []

    # 构建请求
    url = "https://google.serper.dev/search"
    headers = {
        "X-API-KEY": api_key,
        "Content-Type": "application/json",
    }
    payload = {"q": query, "num": 10}

    logger.info(f"serper_search: 搜索 '{query[:80]}'")

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"serper_search: 请求失败: {e}")
        return []

    # 解析结果
    organic = data.get("organic", [])
    logger.info(f"serper_search: 返回 {len(organic)} 条")

    results = []
    for item in organic:
        parsed = _parse_item(item)
        if parsed:
            results.append(parsed)

    # 缓存结果
    set_cache("serper", query, country, results)

    # 记录用量
    record_search("serper", query, results_count=len(organic),
                  clean_count=len(results))

    return results


def _parse_item(item: dict) -> Optional[dict]:
    """解析单条 Serper 搜索结果。"""
    link = item.get("link", "")
    title = item.get("title", "")
    snippet = item.get("snippet", "")

    if not link or not title:
        return None

    company_name = title[:100]
    country = extract_country_from_text(snippet + " " + title)

    email = ""
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", snippet)
    if email_match:
        candidate = email_match.group(0)
        if is_valid_email(candidate):
            email = candidate

    return {
        "company_name": company_name,
        "website": link[:500],
        "country": country[:50] if country else "",
        "industry": "",
        "requirement": snippet[:500],
        "email": email[:100],
        "source": "serper",
    }