"""
Bing Web Search API 搜索插件 - V4 新增

通过微软 Bing API 官方接口搜索，需配置 API Key。
"""

import logging
import re
from typing import Optional

import requests

from crawler_plugins._common import extract_country_from_text, is_valid_email
from search_cache import get_cached, set_cache

logger = logging.getLogger(__name__)


def search(keyword: str, country: str = "",
           industries: Optional[list] = None) -> list[dict]:
    """通过 Bing Web Search API 搜索海外公司。

    Args:
        keyword: 搜索关键词（英文）。
        country: 目标国家（可选）。
        industries: 目标行业列表（保留接口兼容）。

    Returns:
        公司信息列表。
    """
    from config import get_search_config
    cfg = get_search_config().get("bing", {})
    if not cfg.get("enabled", False):
        logger.info("bing_search_api: 未启用")
        return []

    api_key = cfg.get("api_key", "")
    endpoint = cfg.get("endpoint", "https://api.bing.microsoft.com/v7.0/search")
    if not api_key:
        logger.warning("bing_search_api: API Key 未配置")
        return []

    query = keyword.strip()
    if country:
        query = f"{keyword} {country}"

    # 检查缓存
    cached = get_cached("bing", query, country)
    if cached is not None:
        return cached

    # 检查配额（只检查，不记录）
    if not check_quota("bing"):
        logger.warning(f"bing_search_api: 今日额度已用完")
        return []

    params = {"q": query, "count": 20, "mkt": "en-US"}
    headers = {"Ocp-Apim-Subscription-Key": api_key}

    logger.info(f"bing_search_api: 搜索 '{query[:80]}'")

    try:
        resp = requests.get(endpoint, params=params, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"bing_search_api: 请求失败: {e}")
        return []

    web_pages = data.get("webPages", {})
    items = web_pages.get("value", [])
    logger.info(f"bing_search_api: 返回 {len(items)} 条")

    results = []
    for item in items:
        parsed = _parse_item(item)
        if parsed:
            results.append(parsed)

    # 缓存结果
    set_cache("bing", query, country, results)

    # 记录用量（此时已有实际结果数）
    record_search("bing", query, results_count=len(items),
                  clean_count=len(results))

    return results


def _parse_item(item: dict) -> Optional[dict]:
    """解析单条 Bing 搜索结果。"""
    url = item.get("url", "")
    name = item.get("name", "")
    snippet = item.get("snippet", "")

    if not url or not name:
        return None

    company_name = name[:100]
    country = extract_country_from_text(snippet + " " + name)

    email = ""
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", snippet)
    if email_match:
        candidate = email_match.group(0)
        if is_valid_email(candidate):
            email = candidate

    return {
        "company_name": company_name,
        "website": url[:500],
        "country": country[:50] if country else "",
        "industry": "",
        "requirement": snippet[:500],
        "email": email[:100],
        "source": "bing_api",
    }