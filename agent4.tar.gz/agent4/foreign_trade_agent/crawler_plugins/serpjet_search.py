"""
SerpJet SERP API 搜索插件。

通过 SerpJet API 获取 Google 搜索结果，不需要 Google API Key。
每月 1000 次免费额度，按 HTTP 200 计费（失败不扣费）。

配置：
  - api_key: sj_ 开头的 API Key
  - daily_limit: 每日搜索限制

文档：https://api.serpjet.io
"""

import logging
import re
from typing import Optional

import requests

from crawler_plugins._common import extract_country_from_text, is_valid_email
from search_cache import get_cached, set_cache

logger = logging.getLogger(__name__)

# 国家名称 → 两位代码映射（SerpJet 用 gl 参数）
_COUNTRY_CODE = {
    "vietnam": "vn", "thailand": "th", "indonesia": "id",
    "malaysia": "my", "philippines": "ph", "singapore": "sg",
    "myanmar": "mm", "cambodia": "kh", "laos": "la",
    "india": "in", "bangladesh": "bd", "pakistan": "pk",
    "china": "cn", "japan": "jp", "korea": "kr", "taiwan": "tw",
    "uae": "ae", "saudi": "sa", "qatar": "qa", "oman": "om",
    "turkey": "tr", "egypt": "eg", "iran": "ir", "iraq": "iq",
    "nigeria": "ng", "kenya": "ke", "south africa": "za",
    "ethiopia": "et", "ghana": "gh", "morocco": "ma",
    "germany": "de", "uk": "gb", "france": "fr", "italy": "it",
    "spain": "es", "netherlands": "nl", "poland": "pl",
    "russia": "ru", "ukraine": "ua",
    "usa": "us", "america": "us", "canada": "ca",
    "mexico": "mx", "brazil": "br", "argentina": "ar",
    "chile": "cl", "colombia": "co", "peru": "pe",
    "australia": "au", "new zealand": "nz",
}


def _get_country_code(country_name: str) -> str:
    """将国家名转为两位代码。"""
    if not country_name:
        return ""
    key = country_name.strip().lower()
    return _COUNTRY_CODE.get(key, "")


def search(keyword: str, country: str = "",
           industries: Optional[list] = None) -> list[dict]:
    """通过 SerpJet API 搜索海外公司。

    Args:
        keyword: 搜索关键词（英文）。
        country: 目标国家（可选，传国家名即可）。
        industries: 目标行业列表（保留接口兼容）。

    Returns:
        公司信息列表，每项含 company_name, website, country, industry, requirement, email。
    """
    from config import check_quota, record_search

    # 读取配置
    try:
        from config import get_search_config
        cfg = get_search_config().get("serpjet", {})
    except Exception:
        cfg = {}

    api_key = cfg.get("api_key", "")
    if not api_key:
        logger.warning("serpjet_search: API Key 未配置")
        return []

    query = keyword.strip()
    if not query:
        return []

    # 检查缓存
    cached = get_cached("serpjet", query, country)
    if cached is not None:
        return cached

    # 检查配额（只检查，不记录）
    if not check_quota("serpjet"):
        logger.warning(f"serpjet_search: 今日额度已用完")
        return []

    # 构建请求
    params = {
        "q": query,
        "engine": "google",
        "type": "search",
        "num": 10,
        "hl": "en",
    }

    # 国家代码
    code = _get_country_code(country)
    if code:
        params["gl"] = code

    headers = {
        "X-API-KEY": api_key,
    }

    url = "https://api.serpjet.io/v1/search"
    logger.info(f"serpjet_search: 搜索 '{query[:80]}'")

    try:
        # verify=False: SerpJet SSL 证书域名不匹配（api.serpjet.io ↔ *.jibaoproxy.com）
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        resp = requests.get(url, params=params, headers=headers,
                            timeout=30, verify=False)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"serpjet_search: 请求失败: {e}")
        return []

    # 解析结果
    organic = data.get("organic", [])
    logger.info(f"serpjet_search: 返回 {len(organic)} 条")

    results = []
    for item in organic:
        parsed = _parse_item(item)
        if parsed:
            results.append(parsed)

    # 缓存结果
    set_cache("serpjet", query, country, results)

    # 记录用量（此时已有实际结果数）
    record_search("serpjet", query, results_count=len(organic),
                  clean_count=len(results))

    return results


def _parse_item(item: dict) -> Optional[dict]:
    """解析单条 SerpJet 搜索结果。"""
    link = item.get("link", "")
    title = item.get("title", "")
    snippet = item.get("snippet", "")

    if not link or not title:
        return None

    company_name = title[:100]
    country = extract_country_from_text(snippet + " " + title)

    email = ""
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", snippet)
    if email_match:
        candidate = email_match.group(0)
        if is_valid_email(candidate):
            email = candidate

    return {
        "company_name": company_name,
        "website": link[:500],
        "country": country[:50] if country else "",
        "industry": "",
        "requirement": snippet[:500],
        "email": email[:100],
        "source": "serpjet",
    }