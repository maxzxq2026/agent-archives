"""
阿里巴巴国际站 RFQ（买家采购需求）爬虫插件。

搜索阿里巴巴 RFQ 专区，提取海外买家公开采购需求信息。
只爬静态 HTML 页面，不处理 JS 动态渲染。
"""

import logging
import random
import re
import time
from typing import Optional

from bs4 import BeautifulSoup

from crawler_plugins._common import (
    build_session, random_delay, safe_request,
    extract_text, extract_country_from_text, is_domestic,
)

logger = logging.getLogger(__name__)

# 每个源最多爬取数量
MAX_RESULTS = 50


def search(keyword: str, country: str = "") -> list[dict]:
    """搜索阿里巴巴国际站 RFQ 页面，提取海外买家采购需求。

    Args:
        keyword: 搜索关键词（英文）。
        country: 国家过滤（两位国家代码，如 "US"），可选。

    Returns:
        买家信息列表，每项含 company_name, website, country, industry, requirement, email。
        失败返回空列表。
    """
    results: list[dict] = []
    session = build_session()

    try:
        # 构建搜索 URL
        search_url = _build_url(keyword, country)
        logger.info(f"alibaba_rfq 开始搜索: {search_url}")

        resp = safe_request(search_url, session=session)
        if resp is None:
            logger.warning("alibaba_rfq: 请求失败，跳过")
            return results

        soup = BeautifulSoup(resp.text, "lxml")
        items = _extract_rfq_items(soup)

        logger.info(f"alibaba_rfq: 解析到 {len(items)} 条 RFQ 条目")

        for item in items:
            if len(results) >= MAX_RESULTS:
                break

            parsed = _parse_single_item(item)
            if parsed and parsed.get("company_name"):
                # 过滤掉国内买家
                if is_domestic(parsed):
                    continue
                results.append(parsed)
                random_delay(1, 2)  # 条目间短间隔

        logger.info(f"alibaba_rfq: 最终获取 {len(results)} 条海外买家信息")
        return results

    finally:
        session.close()


def _build_url(keyword: str, country: str = "") -> str:
    """构建 RFQ 搜索 URL。"""
    kw = keyword.strip().replace(" ", "+")
    url = f"https://www.alibaba.com/buyer-rfq?keyword={kw}"
    if country:
        # 注意：country 参数可能因网站实际参数而异
        url += f"&country={country}"
    return url


def _extract_rfq_items(soup: BeautifulSoup) -> list:
    """从搜索结果页 HTML 中提取所有 RFQ 条目容器。"""
    # 多种候选选择器，按优先级排序
    selectors = [
        "div[class*='rfq-item']",
        "div[class*='offer-card']",
        "div[class*='buyer-requirement']",
        "div[class*='list-item']",
        "div[data-qa*='rfq']",
        "div.rfq-item",
        "div.offer-card",
        # 兜底：常见的卡片结构
        "div[class*='card'] div[class*='content']",
    ]

    for selector in selectors:
        items = soup.select(selector)
        if items:
            return items

    # 最后的兜底策略
    items = soup.find_all("div", class_=re.compile(r"(rfq|offer|buyer|requirement|card)", re.I))
    if not items:
        items = soup.find_all("li", class_=re.compile(r"(rfq|offer|item)", re.I))
    return items


def _parse_single_item(item) -> Optional[dict]:
    """从单个 RFQ 条目 HTML 块中提取字段。"""
    try:
        text = item.get_text(separator=" ", strip=True)
        html = str(item)

        # ── 公司名称 ────────────────────────────────────────
        company_name = extract_text(item, [
            "a[class*='company']", "span[class*='company']",
            "a[class*='buyer']", "span[class*='buyer']",
            "a[class*='supplier']", "span[class*='supplier']",
            "a[class*='name']", "span[class*='name']",
            "a[class*='member']", "span[class*='member']",
            "a[class*='store']", "span[class*='store']",
        ])
        if not company_name:
            for a in item.find_all("a", href=True):
                txt = a.get_text(strip=True)
                if len(txt) > 4:
                    company_name = txt
                    break

        if not company_name:
            return None

        # ── 国家/地区 ────────────────────────────────────────
        country = extract_text(item, [
            "span[class*='country']", "span[class*='location']",
            "span[class*='region']", "span[class*='flag']",
            "i[class*='flag']", "img[class*='flag']",
        ])
        if not country:
            country = extract_country_from_text(text)

        # ── 行业/类别 ───────────────────────────────────────
        industry = extract_text(item, [
            "a[class*='category']", "span[class*='category']",
            "a[class*='industry']", "span[class*='industry']",
            "span[class*='breadcrumb']", "a[class*='breadcrumb']",
        ])

        # ── 采购需求描述 ────────────────────────────────────
        requirement = extract_text(item, [
            "p[class*='desc']", "div[class*='desc']",
            "p[class*='title']", "h2", "h3",
            "p[class*='requirement']", "div[class*='requirement']",
            "p[class*='detail']", "div[class*='detail']",
            "a[class*='title']",
        ])
        if not requirement:
            lines = [p.get_text(strip=True) for p in item.find_all(["p", "h2", "h3", "h4", "div"])
                     if len(p.get_text(strip=True)) > 15]
            if lines:
                requirement = lines[0]

        requirement = re.sub(r"\s+", " ", requirement).strip()[:500]

        # ── 邮箱 ────────────────────────────────────────────
        email = _extract_email(item, text)

        # ── 网站 ────────────────────────────────────────────
        website = _extract_website(item)

        return {
            "company_name": company_name[:100],
            "website": website[:200],
            "country": country[:50],
            "industry": industry[:100] if industry else "",
            "requirement": requirement,
            "email": email[:100],
        }
    except Exception:
        return None




def _extract_email(item, text: str) -> str:
    """从条目中提取邮箱。"""
    email_el = item.select_one("a[href*='mailto:']")
    if email_el:
        return email_el["href"].replace("mailto:", "").strip()
    match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
    return match.group(0) if match else ""


def _extract_website(item) -> str:
    """从条目中提取网站 URL。"""
    link = item.find("a", href=re.compile(r"^(https?://|//)"))
    if link:
        href = link.get("href", "")
        if href.startswith("//"):
            href = "https:" + href
        return href
    return ""


