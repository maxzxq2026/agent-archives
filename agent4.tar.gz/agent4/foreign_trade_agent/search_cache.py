"""
搜索缓存模块。

缓存搜索结果，避免同一关键词重复消耗 API 额度。
缓存 key: engine + query + country
缓存有效期: 7 天（自动过期）
"""

import hashlib
import json
import logging
import os
import time

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_FILE = os.path.join(BASE_DIR, "data", "search_cache.json")

# 缓存有效期（秒）
CACHE_TTL = 7 * 24 * 3600  # 7 天

# 单条结果最大缓存数
MAX_RESULTS_PER_KEY = 50


def _load_cache() -> dict:
    """加载缓存文件。"""
    if not os.path.isfile(CACHE_FILE):
        return {}
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def _save_cache(cache: dict) -> None:
    """保存缓存文件。"""
    os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


def _make_key(engine: str, query: str, country: str = "") -> str:
    """生成缓存 key。"""
    raw = f"{engine}|{query}|{country}"
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


def get_cached(engine: str, query: str, country: str = "") -> list:
    """获取缓存的搜索结果。

    Returns:
        缓存的结果列表，无缓存或已过期返回 None。
    """
    cache = _load_cache()
    key = _make_key(engine, query, country)
    entry = cache.get(key)
    if not entry:
        return None

    # 检查过期
    cached_time = entry.get("cached_at", 0)
    if time.time() - cached_time > CACHE_TTL:
        logger.info(f"缓存已过期: {engine} '{query[:60]}'")
        del cache[key]
        _save_cache(cache)
        return None

    results = entry.get("results", [])
    logger.info(f"缓存命中: {engine} '{query[:60]}' ({len(results)} 条)")
    return results


def set_cache(engine: str, query: str, country: str, results: list) -> None:
    """保存搜索结果到缓存。"""
    cache = _load_cache()
    key = _make_key(engine, query, country)
    cache[key] = {
        "engine": engine,
        "query": query,
        "country": country,
        "results": results[:MAX_RESULTS_PER_KEY],
        "cached_at": time.time(),
    }
    _save_cache(cache)
    logger.info(f"缓存已保存: {engine} '{query[:60]}' ({len(results)} 条)")


def clear_cache() -> int:
    """清空所有缓存。"""
    cache = _load_cache()
    count = len(cache)
    _save_cache({})
    logger.info(f"缓存已清空: 移除 {count} 条")
    return count


def get_cache_stats() -> dict:
    """获取缓存统计。"""
    cache = _load_cache()
    total = len(cache)
    expired = 0
    now = time.time()
    for entry in cache.values():
        if now - entry.get("cached_at", 0) > CACHE_TTL:
            expired += 1
    return {
        "total": total,
        "expired": expired,
        "valid": total - expired,
    }