# 翻译与 AI 聊天模块
# 封装大模型 API 调用（OpenAI 兼容接口），提供翻译和通用对话功能

import json
import logging
import os
import time
from typing import List, Optional

import requests

from config import API_CONFIG

logger = logging.getLogger(__name__)

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(BASE_DIR, "data", "api_log.txt")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

# ── 内部工具 ──────────────────────────────────────────────────


def _get_api_config() -> Optional[dict]:
    """获取 API 配置，优先从 api_config.json 实时读取。"""
    # 实时读取运行时配置，保存后立即生效
    _runtime = _load_api_config_runtime()
    if _runtime.get("base_url") and _runtime.get("api_key"):
        return {
            "base_url": _runtime["base_url"],
            "api_key": _runtime["api_key"],
            "model": _runtime.get("model", "gpt-4o"),
        }
    # 兜底：从 config.py 的静态配置读取
    for name, cfg in API_CONFIG.items():
        if cfg.get("base_url") and cfg.get("api_key"):
            return cfg
    return None


def _load_api_config_runtime() -> dict:
    """从 data/api_config.json 读取最新配置。"""
    import config as _cfg
    if not os.path.isfile(_cfg.API_CONFIG_JSON):
        return {}
    try:
        with open(_cfg.API_CONFIG_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def _write_log(model: str, duration: float, success: bool, detail: str = "") -> None:
    """将调用记录写入 data/api_log.txt（最多保留 1000 行，超出自动截断）。"""
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    status = "SUCCESS" if success else "FAIL"
    line = f"[{timestamp}] model={model} duration={duration:.2f}s status={status} {detail}\n"
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line)

        # 日志轮转：超过 1000 行时保留后 500 行
        if os.path.getsize(LOG_FILE) > 500 * 1024:  # 约 500KB
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) > 1000:
                with open(LOG_FILE, "w", encoding="utf-8") as f:
                    f.writelines(lines[-500:])
    except Exception as e:
        logger.warning(f"写入 API 日志失败: {e}")


def _call_api(
    messages: List[dict],
    system_prompt: str,
    temperature: float = 0.3,
    max_retries: int = 3,
    timeout: int = 120,
) -> Optional[str]:
    """通用 API 调用函数。

    Args:
        messages: 用户消息列表，如 [{"role": "user", "content": "..."}]。
        system_prompt: 系统提示词。
        temperature: 温度参数，默认 0.3。
        max_retries: 最大重试次数，默认 3。

    Returns:
        AI 回复文本，失败返回 None。
    """
    cfg = _get_api_config()
    if cfg is None:
        logger.warning("_call_api: 无可用 API 配置")
        _write_log("N/A", 0.0, False, detail="no_api_config")
        return None

    model = cfg.get("model", "gpt-4o")
    headers = {
        "Authorization": f"Bearer {cfg['api_key']}",
        "Content-Type": "application/json",
    }

    full_messages = [{"role": "system", "content": system_prompt}] + messages

    payload = {
        "model": model,
        "messages": full_messages,
        "temperature": temperature,
        "max_tokens": 4096,
    }

    base_url = cfg["base_url"].rstrip("/")
    api_url = f"{base_url}/chat/completions"

    last_error = None
    for attempt in range(1, max_retries + 1):
        start_time = time.time()
        try:
            resp = requests.post(
                api_url,
                headers=headers,
                json=payload,
                timeout=timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"].strip()

            duration = time.time() - start_time
            _write_log(model, duration, True, detail=f"attempt={attempt}")
            return content

        except Exception as e:
            duration = time.time() - start_time
            last_error = e
            logger.warning(
                f"_call_api 第 {attempt}/{max_retries} 次失败: {e}"
            )
            if attempt < max_retries:
                time.sleep(1)  # 重试前短暂等待

    # 所有重试均失败
    _write_log(model, 0.0, False, detail=f"last_error={last_error}")
    return None


# ── 公开接口 ──────────────────────────────────────────────────


def translate_to_english(chinese_text: str, context: str = "") -> Optional[str]:
    """将中文文本翻译为专业英文。

    Args:
        chinese_text: 待翻译的中文文本。
        context: 行业上下文，帮助模型选择正确的术语。
                 例如 "汽车制动系统"、"化工原料" 等。

    Returns:
        翻译后的英文文本，失败返回 None。
    """
    if not chinese_text or not chinese_text.strip():
        return ""

    if context:
        system_prompt = (
            "你是一个专业的外贸翻译助手。你的职责是将中文内容准确翻译为英文。\n"
            f"当前行业/上下文：{context}\n\n"
            "要求：\n"
            "1. 使用行业标准术语，确保专业性和准确性\n"
            "2. 只输出翻译结果，不要附加任何解释、备注或原文\n"
            "3. 不要修改原文的业务含义和信息\n"
            "4. 注意中英文语序差异，确保英文读起来自然通顺"
        )
    else:
        system_prompt = (
            "你是一个专业的外贸翻译助手。将中文内容准确翻译为英文。\n\n"
            "要求：\n"
            "1. 使用行业标准术语\n"
            "2. 只输出翻译结果，不要附加任何解释\n"
            "3. 不要修改原文的业务含义"
        )

    messages = [{"role": "user", "content": chinese_text}]
    return _call_api(messages, system_prompt, temperature=0.3)


def ai_chat(
    messages: List[dict],
    system_prompt: str = "你是一个有用的AI助手。",
    temperature: float = 0.7,
) -> Optional[str]:
    """通用 AI 对话函数，供其他模块调用。

    Args:
        messages: 消息列表，例如：
            [{"role": "user", "content": "你好"}]
            [{"role": "user", "content": "分析这段文本"}, {"role": "assistant", "content": "..."}, {"role": "user", "content": "继续"}]
        system_prompt: 系统提示词，用于设定 AI 角色和行为。
        temperature: 温度参数，控制创造性，默认 0.7。

    Returns:
        AI 回复文本，失败返回 None。
    """
    if not messages:
        return None

    return _call_api(messages, system_prompt, temperature=temperature)