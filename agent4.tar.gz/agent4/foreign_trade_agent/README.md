# 外贸智能助手 (Foreign Trade Agent)

基于 AI 的外贸客户开发与邮件营销工具。通过爬虫采集 B2B 平台上的潜在客户信息，经 AI 筛选匹配后，自动生成个性化开发信并完成批量发送。

---

## 环境安装

### 1. 确认 Python 版本

本项目依赖 Python 3.10 或以上版本。在终端中检查：

```bash
python3 --version
```

如未安装，请前往 [python.org](https://www.python.org/downloads/) 下载安装。

### 2. 安装依赖

在项目根目录下执行：

```bash
cd /path/to/foreign_trade_agent
pip install -r requirements.txt
```

安装的依赖包括：

| 包名 | 用途 |
|------|------|
| streamlit | Web 应用框架 |
| requests | HTTP 请求（爬虫） |
| beautifulsoup4 + lxml | HTML 解析 |
| pandas | 数据处理 |
| openpyxl | Excel 读写 |
| python-docx | Word 文档生成 |
| pdfplumber | PDF 解析 |

### 3. 启动应用

```bash
streamlit run app.py
```

启动后浏览器会自动打开 `http://localhost:8501`，即应用主界面。

---

## API 配置说明

编辑 `config.py` 文件中的 `API_CONFIG` 部分，填入你的 AI 服务信息：

```python
API_CONFIG = {
    "default": {
        "base_url": "https://api.openai.com/v1",   # API 地址
        "api_key": "sk-xxxxxxxxxxxxxxxxxxxxxxxx",   # API 密钥
        "model": "gpt-4o",                          # 模型名称
        "vision_supported": True,                   # 是否支持图片识别
    }
}
```

支持任意兼容 OpenAI 格式的 API 服务（如 Azure OpenAI、本地部署的 vLLM 等）。

### SMTP 邮件配置

如需发送邮件，同时配置 `SMTP_CONFIG`：

```python
SMTP_CONFIG = {
    "default": {
        "smtp_server": "smtp.example.com",  # SMTP 服务器地址
        "port": 465,                         # 端口（SSL 一般为 465）
        "use_ssl": True,                     # 是否使用 SSL
        "email": "your@email.com",           # 发件邮箱
        "password": "your-password",         # 邮箱密码或授权码
    }
}
```

---

## 爬虫使用说明

爬虫模块用于从外贸 B2B 平台采集潜在客户信息。使用前请注意：

1. **爬虫插件目录**：`crawler_plugins/` 下存放各平台专用爬虫脚本，按需启用。
2. **请求频率**：`config.py` 中的 `CRAWLER_CONFIG` 控制爬取间隔（`min_delay`/`max_delay`）和每日上限（`daily_limit`），请勿调得过低，避免对目标服务器造成压力。
3. **数据存储**：爬取结果会落在 `data/` 目录下，后续供筛选和匹配模块使用。
4. **合规性**：请确保使用爬虫遵守目标网站的 `robots.txt` 及服务条款，仅采集公开信息。

---

## 免责声明

使用本工具前，请仔细阅读以下条款：

1. **工具不含跨境上网服务**  
   本软件本身不提供任何 VPN、代理或跨境网络访问功能。用户如需访问境外网站，应自行通过合法合规的渠道上网。

2. **批量邮件存在风险**  
   本工具提供的批量邮件发送功能仅用于辅助外贸业务沟通。用户应遵守所在国家/地区及目标国家/地区的反垃圾邮件法规（如 CAN-SPAM Act、GDPR 等）。滥用批量邮件可能导致邮箱被封禁、域名被拉黑或承担法律责任。

3. **AI 生成内容需人工复核**  
   本工具借助 AI 生成客户开发信、产品描述等文本内容。AI 生成内容可能存在事实错误、语气不当或合规风险，请在发送前由人工进行审核和修改，确保内容准确、得体、合法。

4. **爬虫采集合规性**  
   用户应自行确保爬虫使用行为符合相关法律法规及目标网站的条款，本工具不对因爬虫使用引发的任何纠纷或处罚承担责任。

---

## 项目结构

```
foreign_trade_agent/
├── config.py              # 全局配置（API、SMTP、爬虫、筛选、邮件）
├── crawler_plugins/       # 各平台爬虫插件
├── data/                  # 爬虫运行时数据
├── mail_template/         # 邮件模板
├── product_data/          # 产品数据
├── requirements.txt       # Python 依赖
└── README.md              # 本文件
```
