"""
买家画像生成器（Buyer Intelligence Engine v1.0）

核心功能：
1. 理解产品（判断类型、应用领域、下游行业）
2. 生成买家画像（谁需要、什么类型、什么场景）
3. 生成搜索策略（搜索词、排除词、判断规则）

工作方式：
- 输入：产品信息（来自 Excel 或手动录入）
- 输出：buyer_strategy.json（完整的搜索+判断策略）
- 依赖：AI 动态生成，不依赖行业数据库
"""

import json
import logging
import os
import re
from typing import Any, Optional

from translator import ai_chat

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")


def generate_strategy(product_data: dict, supply_capability: dict = None,
                       customer_profile: dict = None, block_rules: dict = None,
                       signal_library: list = None,
                       target_regions: list = None) -> Optional[dict]:
    """生成完整的采购信号搜索策略。

    Args:
        product_data: 产品信息（来自 Sheet 1）
        supply_capability: 供应能力（来自 Sheet 2）
        customer_profile: 目标客户画像（来自 Sheet 3）
        signal_library: 采购信号库（来自 Sheet 4）
        block_rules: 排除规则（来自 Sheet 5）
        target_regions: 目标区域列表（来自设置页，如 ["Indonesia", "Philippines"]）

    Returns:
        完整的 buyer_strategy JSON，失败返回 None。
    """
    # 构建产品描述
    product_desc = _build_product_description(product_data)

    # 构建供应能力文本
    supply_text = ""
    if supply_capability:
        parts = ["【供应能力】"]
        for k, v in supply_capability.items():
            if v:
                parts.append(f"  {k}: {v}")
        supply_text = "\n".join(parts)

    # 构建客户画像文本
    profile_text = ""
    if customer_profile:
        parts = ["【目标客户画像】"]
        for k, v in customer_profile.items():
            if v:
                parts.append(f"  {k}: {v}")
        profile_text = "\n".join(parts)

    # 构建采购信号文本
    signal_text = ""
    if signal_library:
        parts = ["【用户提供的采购信号】"]
        for s in signal_library:
            row = f"  信号: {s.get('signal_type', '')} | 搜索词: {s.get('search_query', '')} | 行业: {s.get('target_industry', '')} | 优先级: {s.get('priority', '')}"
            parts.append(row)
        signal_text = "\n".join(parts)

    # 构建排除规则文本
    block_text = ""
    if block_rules:
        parts = ["【排除规则】"]
        for k, v in block_rules.items():
            if v:
                parts.append(f"  {k}: {v}")
        block_text = "\n".join(parts)

    # 构建目标区域提示文本
    if target_regions:
        _region_str = " / ".join(target_regions)
        _region_hint = f"优先使用目标国家名（{_region_str}），但不强制，允许少量全球行业词"
        _region_user_hint = f"搜索词优先使用目标国家名 {' / '.join(target_regions)}，但不强制；允许 20% 的全球行业词"
    else:
        _region_hint = "不限制国家，搜索全球范围"
        _region_user_hint = "不限制国家，搜索全球范围"

    # 构建 prompt
    system_prompt = (
        "你是一个工业过滤产品的B2B海外销售机会分析专家。你的任务是帮助中国工业过滤企业\n"
        "寻找潜在海外客户，不是寻找同行供应商。\n\n"
        "【核心原则】\n"
        "1. 你的任务是寻找海外采购方/渠道商，不是同行供应商\n"
        "2. 禁止以 filter manufacturer / air filter company / filtration supplier 为核心方向搜索\n"
        "3. 搜索方向必须围绕：产品 → 应用设备 → 消耗场景 → 采购方\n"
        "   不要直接搜行业（如 automotive factory），要搜设备/工程商（如 spray booth manufacturer）\n\n"
        "【关键搜索逻辑】\n"
        "不是搜\"谁需要过滤产品\"，而是搜\"谁消耗过滤产品的设备/工程商\"。\n"
        "例：\n"
        "  ❌ automotive factory（工厂本身不直接采购过滤材料）\n"
        "  ✅ automotive spray booth manufacturer（喷漆房厂家才采购漆雾过滤棉）\n"
        "  ❌ pharmaceutical company（药厂不直接采购过滤材料）\n"
        "  ✅ cleanroom contractor（洁净室工程公司才采购HEPA过滤器）\n\n"
        "【优先寻找的采购方类型】\n"
        "- 涂装/喷涂设备供应商（喷漆房、喷涂线、涂装设备制造商）\n"
        "- 洁净室工程公司（EPC承包商、洁净室系统集成商）\n"
        "- HVAC工程公司（通风系统、空调系统、工业除尘系统集成商）\n"
        "- 汽车制造/零部件企业的MRO采购部门\n"
        "- 过滤耗材渠道商（经销商、进口商、代理商、MRO供应商）\n"
        "- 制药/电子/食品等行业的工厂工程部\n\n"
        "【降低搜索权重的方向】\n"
        "- 过滤器制造商同行（可以保留但不作为主要方向）\n"
        "- 空气过滤厂家\n"
        "- 滤材生产商\n\n"
        "【行业权重（按优先级）】\n"
        "第一优先：汽车制造（涂装线、喷涂车间、喷漆房设备商）\n"
        "第二优先：制药医疗（洁净室工程、HVAC工程）\n"
        "第三优先：电子半导体（洁净室工程、通风工程）\n"
        "其他：工业除尘、HVAC、食品饮料\n\n"
        "【搜索词类型——设备供应链关键词】\n"
        "采购/供应链信号（40%）：搜供应商注册、RFQ、procurement manager、MRO维护采购\n"
        "  例：\"automotive spray booth supplier\" \"paint booth filter replacement\"\n"
        "  例：\"cleanroom HVAC procurement\" \"industrial MRO filter supply\"\n"
        "工程服务商/设备商（30%）：搜喷漆房厂家、涂装线设备商、洁净室工程公司、HVAC集成商\n"
        "  例：\"automotive paint booth manufacturer\" \"cleanroom EPC contractor\"\n"
        "  例：\"spray booth system integrator\" \"pharmaceutical HVAC engineering\"\n"
        "终端工厂（20%）：搜生产企业、工厂官网\n"
        "  例：\"automotive assembly plant\" \"pharmaceutical manufacturing facility\"\n"
        "项目新闻/展会（10%）：搜扩建、新厂、行业展会（少量）\n\n"
        "【搜索词示例——汽车方向】\n"
        "  ✅ automotive spray booth manufacturer\n"
        "  ✅ automotive paint line supplier\n"
        "  ✅ vehicle coating system integrator\n"
        "  ✅ automotive painting equipment supplier\n"
        "  ✅ paint shop ventilation system\n"
        "  ❌ automotive factory（太泛，容易搜到新闻）\n\n"
        "【搜索词示例——医药/洁净室方向】\n"
        "  ✅ pharmaceutical cleanroom contractor\n"
        "  ✅ GMP cleanroom engineering company\n"
        "  ✅ pharmaceutical HVAC system integrator\n"
        "  ✅ cleanroom equipment supplier\n"
        "  ❌ pharmaceutical company（药厂不直接采购）\n\n"
        "要求：\n"
        "1. {_region_hint}\n"
        "2. 禁止以 filter manufacturer / air filter company 为核心词\n"
        "3. 只输出合法 JSON，不要 markdown 代码块标记，不要解释文字"
    )

    user_prompt = f"""## 产品信息
{product_desc}

## 供应能力
{supply_text}

## 目标客户画像
{profile_text}

## 采购信号库
{signal_text}

## 排除规则
{block_text}

请生成以下 JSON 结构（严格遵循格式，不要加任何解释）：
{{
  "product_type": "raw_material / finished_product / industrial_equipment / component / consumer_product",
  "buyer_logic": "一句话描述这个产品的采购触发逻辑（什么情况下客户会考虑换供应商或新增采购）",

  "buyer_analysis": {{
    "who_needs_this_product": ["哪些行业和场景需要这个产品"],
    "buyer_types": ["买家类型1（如：汽车涂装线采购）", "买家类型2（如：制药厂洁净室工程）", "买家类型3（如：工业过滤耗材经销商）"],
    "buyer_industries": ["汽车制造", "制药医疗", "电子半导体"],
    "purchase_triggers": ["工厂扩建", "新建喷涂线", "洁净室建设", "环保升级", "耗材更换"],
    "avoid_types": ["过滤器制造商", "滤材生产商", "空气过滤同行厂家"]
  }},

  "search_strategy": {{
    "signal_keywords": ["RFQ", "tender", "supplier registration", "procurement manager", "expansion", "new plant", "production line"],
    "negative_keywords": ["filter manufacturer", "air filter company", "filtration supplier", "china", "alibaba"],
    "search_queries": [
      "国家+行业+采购场景 1",
      "国家+行业+采购场景 2",
      "国家+产品+应用场景 3"
    ]
  }},

  "company_filter": {{
    "preferred_company_types": ["终端生产企业", "工程公司", "经销商"],
    "avoid_company_types": ["过滤器制造同行", "大型跨国企业", "供应链固化的老牌企业"],
    "website_signals": {{
      "positive": ["采购商、工程公司、终端工厂的特征词"],
      "negative": ["同行厂家、产品目录、行业新闻的特征词"]
    }}
  }}
}}

要求：
- buyer_types 至少 3 个
- buyer_industries 按优先级：汽车制造 > 制药医疗 > 电子半导体
- purchase_triggers 至少 4 个
- 【强制】search_queries 必须输出 20-25 个搜索词，按以下场景分配：
  - 采购/供应链信号（40%）：8-10 个词，侧重 supplier registration、procurement、MRO、RFQ
    例: "automotive spray booth supplier" "cleanroom HVAC procurement" "paint booth filter replacement"
  - 工程服务商/设备商（30%）：6-8 个词，侧重设备制造商、工程公司、系统集成商
    例: "automotive paint booth manufacturer" "pharmaceutical cleanroom contractor" "spray booth system integrator"
  - 终端工厂（20%）：4-5 个词，侧重 manufacturer、factory、plant
    例: "automotive assembly plant" "pharmaceutical manufacturing facility"
  - 项目新闻/展会（10%）：2-3 个词，少量
- 禁止以 filter manufacturer、air filter company、filtration supplier 为核心词
- {_region_user_hint}
- 搜索词用英文，体现设备/供应链场景，如 "spray booth" "paint booth" "cleanroom contractor" "HVAC engineering"
- 搜索词用英文，体现采购场景和公司类型，如 "contractor" "supplier" "manufacturer" "integrator"
"""

    result = ai_chat(
        messages=[{"role": "user", "content": user_prompt}],
        system_prompt=system_prompt,
        temperature=0.3,
    )

    if result is None:
        logger.error("generate_strategy: AI 调用失败")
        return None

    # 解析 JSON
    try:
        json_str = result.strip()
        if "```" in json_str:
            m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
            if m:
                json_str = m.group(1)
            else:
                json_str = json_str.replace("```json", "").replace("```", "").strip()
        strategy = json.loads(json_str)
    except json.JSONDecodeError:
        logger.error(f"generate_strategy: AI 返回非 JSON, raw={result[:200]}")
        return None

    # 补充产品信息
    strategy["product_info"] = {
        "product_name": product_data.get("product_name", ""),
        "english_name": product_data.get("english_name", ""),
        "category": product_data.get("category", ""),
        "application": product_data.get("application", ""),
    }

    logger.info(
        f"generate_strategy: 已生成买家策略"
        f"\n  产品: {strategy['product_info']['product_name']}"
        f"\n  类型: {strategy.get('product_type', 'N/A')}"
        f"\n  搜索词: {len(strategy.get('search_strategy', {}).get('search_queries', []))} 个"
    )
    return strategy


def save_strategy(product_id: str, strategy: dict) -> str:
    """保存买家策略到 product_data/ 目录。"""
    path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(strategy, f, ensure_ascii=False, indent=2)
    logger.info(f"save_strategy: 已保存 {path}")
    return path


def load_strategy(product_id: str) -> Optional[dict]:
    """加载已生成的买家策略。"""
    path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def get_search_queries(strategy: dict) -> list[str]:
    """从策略中提取搜索词列表。"""
    return strategy.get("search_strategy", {}).get("search_queries", [])


def get_buyer_industries(strategy: dict) -> list[str]:
    """从策略中提取目标行业。"""
    return strategy.get("buyer_analysis", {}).get("buyer_industries", [])


def get_negative_keywords(strategy: dict) -> list[str]:
    """从策略中提取排除关键词。"""
    return strategy.get("search_strategy", {}).get("negative_keywords", [])


def get_company_filter_rules(strategy: dict) -> dict:
    """从策略中提取公司过滤规则。"""
    return strategy.get("company_filter", {})


def _build_product_description(product_data: dict) -> str:
    """构建产品描述文本。"""
    fields = {
        "产品名称": product_data.get("product_name", ""),
        "英文名称": product_data.get("english_name", ""),
        "产品类别": product_data.get("category", ""),
        "型号/牌号": product_data.get("model", ""),
        "HS Code": product_data.get("hs_code", ""),
        "主要材料": product_data.get("material", ""),
        "应用领域": product_data.get("application", ""),
        "产品描述": product_data.get("description", ""),
        "主要参数": product_data.get("specifications", ""),
        "认证": product_data.get("certification", ""),
        "优势": product_data.get("advantage", ""),
    }
    lines = [f"{k}: {v}" for k, v in fields.items() if v]
    return "\n".join(lines)


def _build_sales_context(sales_info: dict, customer_history: list,
                          block_rules: dict) -> str:
    """构建销售背景文本。"""
    parts = []

    if sales_info:
        parts.append("【销售定位】")
        for k, v in sales_info.items():
            if v:
                parts.append(f"  {k}: {v}")

    if customer_history:
        parts.append("\n【已有客户经验】")
        for c in customer_history:
            parts.append(f"  国家: {c.get('country', '')} | 行业: {c.get('industry', '')} | 产品: {c.get('product', '')} | 原因: {c.get('reason', '')} | 类型: {c.get('customer_type', '')}")

    if block_rules:
        parts.append("\n【禁止规则】")
        for k, v in block_rules.items():
            if v:
                parts.append(f"  {k}: {v}")

    return "\n".join(parts) if parts else "暂无销售背景信息"