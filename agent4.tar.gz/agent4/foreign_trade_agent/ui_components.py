# ui_components.py
import streamlit as st


def inject_enterprise_css():
    st.markdown(
        """
        <style>
        /* =============== 整体企业配色 =============== */
        .stApp {
            background: url("http://127.0.0.1:8765/bg-main.jpg") center center / cover no-repeat !important;
            color: #262626;
        }
        html, body {
            background: url("http://127.0.0.1:8765/bg-main.jpg") center center / cover no-repeat fixed !important;
            color: #262626;
            font-size: 14px;
        }

        /* =============== 页面标题栏（暖白磨砂玻璃风） =============== */
        .page-header {
            background: rgba(255,255,255,0.7) !important;
            border: 1px solid rgba(200,190,175,0.3) !important;
            border-radius: 12px;
            padding: 16px 20px;
            margin: 6px 0 16px 0;
            box-shadow: 0 2px 12px rgba(180,150,100,0.08);
            backdrop-filter: blur(8px);
            border-left: 3px solid #c4956a !important;
        }

        .page-header-top {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .breadcrumb {
            font-size: 12px;
            color: #a09080;
            letter-spacing: .2px;
        }

        .page-title {
            font-size: 20px;
            font-weight: 600;
            color: #3d3228;
            line-height: 1.2;
        }

        .page-subtitle {
            margin-top: 6px;
            font-size: 13px;
            color: #8c7a6a;
            line-height: 1.35;
        }

        /* =============== 侧边栏 =============== */
        section[data-testid="stSidebar"] {
            background:
                linear-gradient(180deg, rgba(30,35,42,0.40) 0%, rgba(30,35,42,0.30) 100%),
                url("http://127.0.0.1:8765/bg-sidebar.jpg") center center / cover no-repeat !important;
            border-right: 1px solid rgba(255,255,255,0.06);
        }

        /* 品牌区域 */
        section[data-testid="stSidebar"] .sidebar-brand {
            padding: 28px 20px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            margin: 0 14px 12px;
        }

        section[data-testid="stSidebar"] .brand-title {
            font-size: 18px;
            font-weight: 500;
            color: #f0ece6;
            letter-spacing: 4px;
            line-height: 1.5;
        }

        section[data-testid="stSidebar"] .brand-sub {
            font-size: 11px;
            color: rgba(255,255,255,0.35);
            letter-spacing: 3px;
            margin-top: 6px;
        }

        /* 导航按键 */
        section[data-testid="stSidebar"] .stButton button {
            background: transparent !important;
            border: none !important;
            border-radius: 6px !important;
            padding: 13px 20px !important;
            height: auto !important;
            font-size: 20px !important;
            font-weight: 450 !important;
            color: rgba(255,255,255,0.65) !important;
            text-align: left !important;
            width: 100% !important;
            justify-content: flex-start !important;
            transition: all 0.2s ease !important;
            letter-spacing: 2px;
            margin-bottom: 1px !important;
        }

        section[data-testid="stSidebar"] .stButton button:hover {
            background: rgba(255,255,255,0.06) !important;
            color: rgba(255,255,255,0.9) !important;
        }

        /* 当前页面（激活态） */
        section[data-testid="stSidebar"] .stButton button[kind="primary"] {
            background: rgba(255,255,255,0.08) !important;
            color: #ffffff !important;
            font-weight: 550 !important;
            border-left: 3px solid rgba(255,255,255,0.25) !important;
            border-radius: 0 6px 6px 0 !important;
        }

        section[data-testid="stSidebar"] .stButton button[kind="primary"]:hover {
            background: rgba(255,255,255,0.12) !important;
        }

        /* 侧边栏分隔线 */
        section[data-testid="stSidebar"] hr {
            border: none !important;
            border-top: 1px solid rgba(255,255,255,0.06) !important;
            margin: 16px 14px !important;
        }

        /* =============== 按钮色板（暖金主题） =============== */
        .stButton > button {
            border-radius: 8px !important;
        }
        /* 主按钮：暖金 */
        .stButton > button[kind="primary"] {
            background: #c4956a !important;
            color: #ffffff !important;
            border: 1px solid #c4956a !important;
            font-weight: 500 !important;
        }
        .stButton > button[kind="primary"]:hover {
            background: #b8875a !important;
            border-color: #b8875a !important;
        }

        /* 次要按钮：暖灰描边 */
        .stButton > button[kind="secondary"] {
            background: rgba(255,255,255,0.8) !important;
            color: #6b5d4e !important;
            border: 1px solid rgba(200,190,175,0.5) !important;
        }
        .stButton > button[kind="secondary"]:hover {
            background: rgba(255,255,255,0.95) !important;
            border-color: rgba(200,190,175,0.8) !important;
        }

        /* 分隔线 */
        hr, .stHorizontalBlock hr {
            border: none !important;
            border-top: 1px solid rgba(200,190,175,0.3) !important;
            margin: 20px 0 !important;
        }

        /* =============== 卡片容器（暖白磨砂玻璃） =============== */
        div[data-testid="stVerticalBlockBorder"] {
            background: rgba(255,255,255,0.75) !important;
            border: 1px solid rgba(200,190,175,0.3) !important;
            border-radius: 12px;
            padding: 16px 16px 8px 16px;
            box-shadow: 0 2px 12px rgba(180,150,100,0.08);
            backdrop-filter: blur(6px);
        }

        /* =============== 提示框（暖色调） =============== */
        div[data-testid="stAlert"] {
            border-radius: 8px;
            border-left: 4px solid;
            padding: 10px 14px !important;
        }
        div[data-testid="stInfo"] {
            background: rgba(245,235,220,0.6) !important;
            border-color: #c4956a !important;
        }
        div[data-testid="stSuccess"] {
            background: rgba(235,245,225,0.6) !important;
            border-color: #8db580 !important;
        }
        div[data-testid="stWarning"] {
            background: rgba(250,240,215,0.6) !important;
            border-color: #d4a853 !important;
        }
        div[data-testid="stError"] {
            background: rgba(245,225,220,0.6) !important;
            border-color: #c47a6a !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_page_header(title: str, breadcrumb: str = "", subtitle: str = ""):
    breadcrumb_html = f'<div class="breadcrumb">{breadcrumb}</div>' if breadcrumb else ""
    subtitle_html = f'<div class="page-subtitle">{subtitle}</div>' if subtitle else ""

    st.markdown(
        f"""
        <div class="page-header">
            <div class="page-header-top">
                {breadcrumb_html}
                <div class="page-title">{title}</div>
            </div>
            {subtitle_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def open_toolbar():
    return st.container(border=True)


def open_card():
    return st.container(border=True)