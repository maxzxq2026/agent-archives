# 外贸获客助手 v1.0 — 架构与获客逻辑

## 一、整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                      Streamlit Web 层                        │
│  app.py (页面路由 + 交互逻辑) + ui_components.py (CSS 样式)  │
│                                                             │
│  产品页     线索页     客户页     邮件页     设置页     导出页  │
│  (上传/录入) (搜索/匹配) (列表/筛选) (生成/发送) (API/SMTP)  │
└──────────────┬──────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│                      业务逻辑层                               │
│                                                             │
│  product_manager.py  ─── 产品管理（上传、录入、查重、覆盖）   │
│  crawler.py          ─── 爬虫调度（搜索、去重、扫邮箱、过滤）  │
│  matcher.py          ─── AI 匹配打分（可选，不再作为拦截条件）│
│  mail_generator.py   ─── 开发信生成                          │
│  mail_sender.py      ─── 邮件发送（默认 DRY_RUN）            │
│  filter.py           ─── 规则过滤（国家、MX解析）             │
│  translator.py       ─── AI 翻译 + 通用对话                  │
└──────────────┬──────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│                      数据采集层                               │
│                                                             │
│  crawler_plugins/                                            │
│  ├── alibaba_rfq.py      (❌ RFQ 页面已废弃)                 │
│  ├── made_in_china.py    (❌ 页面结构已变)                    │
│  ├── globalsources.py    (❌ Cloudflare 拦截)                 │
│  ├── ddg_search.py       (✅ 主力 — DuckDuckGo 行业搜索)      │
│  └── contact_scanner.py  (✅ 官网邮箱扫描)                    │
└──────────────┬──────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│                      数据持久层                               │
│                                                             │
│  data/                                                      │
│  ├── customers.json     (客户数据，三段式原子写入 + .bak)    │
│  ├── products.json      (产品档案)                          │
│  ├── api_config.json    (API 配置)                           │
│  └── api_log.txt        (API 调用日志，自动轮转)             │
│  product_data/                                              │
│  └── {id}_search_plan.json (搜索策略，AI 生成)               │
└─────────────────────────────────────────────────────────────┘
```

## 二、获客逻辑（当前版本）

### 核心思路：搜行业，不搜买家

```
不搜 "谁在买这个产品"
而搜 "谁是做这个行业的"

成品（水杯、台灯）   → 搜行业里的渠道商、批发商、礼品公司
半成品（木浆、钢材） → 搜行业里的生产商、造纸厂、压铸厂
```

### 完整流程

```
产品录入 → AI 生成搜索策略（含关键词 + 目标行业 + 目标国家）
              │
              ▼
        线索页点击搜索
              │
              ▼
    ┌─── 爬虫调度 ────────────────────────┐
    │                                     │
    │  1. DuckDuckGo 搜索                  │
    │     └─ 搜索词: "行业名 + manufacturer"│
    │        "行业名 + supplier"            │
    │        "产品名 + 行业名"              │
    │                                     │
    │  2. 合并去重（按公司官网）            │
    │                                     │
    │  3. contact_scanner 扫邮箱           │
    │     └─ 访问官网 /contact /about 等    │
    │        提取 mailto: 和正文邮箱       │
    │        （10 线程并行，约 1 分钟）     │
    │                                     │
    │  4. filter 规则过滤                   │
    │     └─ 排除中国/印度公司             │
    │        排除无官网公司                │
    │        MX 解析检查域名有效性         │
    │                                     │
    │  5. 保存到 customers.json           │
    │     └─ 三段式原子写入（.bak → .tmp） │
    │                                      │
    └──────────────────────────────────────┘
              │
              ▼
        客户列表
              │
              ▼
        选择客户 → 生成开发信 → 发送邮件
```

### 搜索词生成逻辑（基于行业）

```
AI 生成的 search_plan：
  keywords:        ["wood pulp", "kraft pulp", "bleached pulp"]
  target_industries: ["Paper & Pulp", "Packaging", "Printing"]
  target_countries:  ["US", "DE", "UK", "JP", "KR"]

搜索时拼成：
  "Paper & Pulp manufacturer"
  "Paper & Pulp supplier"
  "wood pulp Paper & Pulp manufacturer"
  "Packaging manufacturer"
  "Packaging supplier"
  "wood pulp Packaging manufacturer"
  ...

结果：找到造纸厂、包装厂的官网，而非 B2B 平台上的"买家"
```

### 日限额控制

```
DuckDuckGo 搜索：每天最多 80 次
每次搜索返回：最多 20 条结果
contact_scanner：10 线程并行，单次 15 秒超时
```

## 三、数据流

```
用户上传/录入产品
    │
    ▼
products.json ──→ AI 生成搜索策略 ──→ product_data/{id}_search_plan.json
                                              │
                                              ▼
                                    爬虫读取搜索策略
                                    ┌─ keywords
                                    └─ target_industries  ← 现在用这个搜
                                              │
                                              ▼
                                    DuckDuckGo 搜索 → 公司官网
                                              │
                                              ▼
                                    contact_scanner 扫邮箱
                                              │
                                              ▼
                                    filter 规则过滤
                                              │
                                              ▼
                                    customers.json（增量累积，不重复覆盖）
                                              │
                                              ▼
                                    邮件页 → 选客户 → 生成开发信 → 发送
```

## 四、当前可用模块状态

| 模块 | 状态 | 说明 |
|------|------|------|
| 产品管理 | ✅ 可用 | 上传Excel、手动录入、查重、覆盖、删除 |
| 搜索策略生成 | ✅ 可用 | AI 生成关键词 + 行业 + 国家 |
| DuckDuckGo 搜索 | ✅ 可用 | 主力搜索渠道，cloudscraper 绕过反爬 |
| 官网邮箱扫描 | ✅ 可用 | 10 线程并行，1 分钟扫完 |
| 规则过滤 | ✅ 可用 | 排除中国/印度公司，MX 解析 |
| 开发信生成 | ✅ 可用 | AI 生成 |
| 邮件发送 | ✅ 可用 | 默认 DRY_RUN，防止误发 |
| Alibaba RFQ | ❌ 废弃 | RFQ 页面已 404 |
| Made-in-China | ❌ 废弃 | 页面结构已变 |
| Global Sources | ❌ 废弃 | Cloudflare 拦截 |
| AI 匹配打分 | ⏸️ 可选 | 保留但不作为拦截条件 |