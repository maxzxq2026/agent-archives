# Cinriwa 产品数据库

共 19 个产品，按类别分组。

---

## 一、初效过滤产品（Primary Filtration）

### 1. 漆雾过滤棉（Paint Stop Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Paint Arrestor Filter / Paint Stop Filter |
| 产品类别 | 初效过滤棉 |
| 过滤效率 | G2-G4 |
| 材质 | 渐变密度玻璃纤维单丝 |
| 结构 | 无外框，蓬松卷材 |
| 耐温 | 180℃ |
| 测试标准 | EN779 / ANSI/ASHRAE 52.1 |
| 主要特点 | 高捕尘率、长寿命、可压缩、储油雾 |
| 目标买家 | 汽车涂装线、喷漆房、家具喷涂厂 |
| **采购触发** | 新建喷涂线、工厂扩产、老旧过滤系统替换、环保标准升级、定期耗材采购 |
| **采购关键词方向** | paint booth project, automotive factory expansion, spray booth maintenance |

### 2. 高温玻璃纤维过滤棉（High Temperature Glassfiber Felt）

| 项目 | 内容 |
|------|------|
| 英文名称 | High Temperature Glassfiber Felt |
| 产品类别 | 高温过滤棉 |
| 过滤效率 | G级 |
| 材质 | 长玻璃纤维无纺布 |
| 结构 | 无外框，热烫处理出风面 |
| 耐温 | 250℃ |
| 阻燃等级 | A级不燃 |
| 主要特点 | 不燃、不熔滴、不积碳、不收缩不变形、耐化学腐蚀 |
| 目标买家 | 高温烘箱、高温干燥设备、陶瓷/玻璃制造 |
| **采购触发** | 高温设备维护更换、新建生产线、耐温标准升级 |
| **采购关键词方向** | high temperature oven filter, industrial drying equipment, ceramic kiln filtration |

### 3. 干式喷漆过滤纸（Dry Paint Filter Paper）

| 项目 | 内容 |
|------|------|
| 英文名称 | Dry Paint Filter Paper (Andreae) |
| 产品类别 | 干式过滤纸 |
| 过滤效率 | G4 |
| 材质 | 牛皮纸+内绳 |
| 结构 | 风琴式折叠 |
| 测试标准 | EN779 |
| 主要特点 | 瑞士Andreae品牌授权、容尘量高(10-22kg/㎡)、惯性捕集 |
| 目标买家 | 汽车涂装线、干式喷漆房 |
| **采购触发** | 干式喷涂线新建、湿改干转换、耗材更换 |
| **采购关键词方向** | dry paint booth filter, automotive painting line conversion |

### 4. 合成纤维过滤棉（Synthetic Filter Cotton）

| 项目 | 内容 |
|------|------|
| 英文名称 | Synthetic Filter Cotton |
| 产品类别 | 初/中效过滤棉 |
| 过滤效率 | G2-G4, F5-F7 |
| 材质 | 100%合成纤维+固体胶+网布 |
| 结构 | 卷材，喷胶/浸胶处理 |
| 耐温 | 120℃ |
| 测试标准 | EN779 / ANSI/ASHRAE 52.1 |
| 主要特点 | 渐变密度、抗拉强度高、低阻力、不含硅酮 |
| 目标买家 | HVAC系统、空调通风、工业通风 |
| **采购触发** | 商业建筑新建、HVAC系统改造、定期更换 |
| **采购关键词方向** | HVAC ventilation project, commercial building HVAC, industrial ventilation system |

### 5. 一次性板式过滤器（Disposable Panel Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Disposable Panel Filter |
| 产品类别 | 初效板式过滤器 |
| 过滤效率 | G4 / Merv 8 |
| 材质 | 无纺布棉+合成纤维 |
| 外框 | 防水纸板框 |
| 耐温 | 80℃ |
| 测试标准 | EN779 |
| 主要特点 | 轻便便宜、通用性好、一次性使用、大容尘量 |
| 目标买家 | 通用HVAC、商业建筑通风、工厂通风 |
| **采购触发** | 批量备货、商业建筑维护合同、通风系统改造 |
| **采购关键词方向** | HVAC filter distributor, commercial building maintenance, ventilation filter wholesale |

### 6. 初效板式过滤器（Pre Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Pre Filter (Panel Filter) |
| 产品类别 | 初效板式过滤器 |
| 过滤效率 | G3-G4 |
| 材质 | 阻燃合成纤维 |
| 外框 | 镀锌/铝合金/不锈钢框 |
| 测试标准 | EN779 |
| 主要特点 | 可清洗重复使用、平板/折叠/龙骨多种结构 |
| 目标买家 | 工业通风、空调系统预过滤 |
| **采购触发** | 新建工厂通风系统、空调系统改造 |
| **采购关键词方向** | industrial ventilation project, HVAC pre filter, factory air conditioning |

### 7. 空调过滤网（Air Conditioning Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Air Conditioning Filter (Washable) |
| 产品类别 | 可清洗过滤网 |
| 过滤效率 | G2-G3 |
| 材质 | 聚酰胺单丝编织合成纤维 |
| 外框 | 金属铝框 |
| 测试标准 | EN779 |
| 主要特点 | 可重复使用、可清洗、高强度耐磨、低阻力、强容尘 |
| 目标买家 | 商业空调、中央空调系统 |
| **采购触发** | 商业建筑空调维护、替换计划 |
| **采购关键词方向** | central AC filter replacement, commercial building AC maintenance |

### 8. 活性炭过滤器（Activated Carbon Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Activated Carbon Filter |
| 产品类别 | 活性炭过滤 |
| 过滤效率 | G4 |
| 材质 | 活性炭棉 |
| 外框 | 金属/纸板框 |
| 耐温 | 50℃ |
| 测试标准 | EN779 |
| 主要特点 | 吸附异味毒气、大比表面积、高吸附性能、除VOC |
| 目标买家 | 制药厂、化工厂、食品加工厂、实验室 |
| **采购触发** | 异味控制要求、VOC排放标准升级、新建化工厂 |
| **采购关键词方向** | odor control filter, VOC abatement system, chemical plant ventilation |

### 9. 金属网过滤器（Metal Mesh Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Metal Mesh Filter |
| 产品类别 | 金属网初效 |
| 过滤效率 | G2 |
| 材质 | 精密铝网 |
| 外框 | 铝框 |
| 主要特点 | 高容尘、耐高温、降低火灾风险、易散热延长风机寿命 |
| 目标买家 | 高温环境、厨房排烟、发动机进气 |
| **采购触发** | 高温设备配套、厨房排烟系统改造 |
| **采购关键词方向** | high temperature air intake filter, kitchen exhaust filtration |

---

## 二、中效过滤产品（Medium Filtration）

### 10. 多袋式熔喷袋式过滤器（Multibags Melt-blown Pocket Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Multibags Melt-blown Pocket Filter |
| 产品类别 | 中效袋式过滤器 |
| 过滤效率 | F5-F9 |
| 材质 | 熔喷/硬质合成纤维 |
| 外框 | 镀锌钢/铝合金框 |
| 耐温 | 80℃ |
| 测试标准 | EN779 |
| 主要特点 | 4/6/8袋可选、低阻力、高效率、效率稳定 |
| 目标买家 | 商业建筑HVAC、制药厂洁净室、电子厂 |
| **采购触发** | 洁净室新建、HVAC系统升级、GMP认证改造 |
| **采购关键词方向** | cleanroom HVAC project, pharmaceutical plant HVAC, commercial building air handling |

### 11. V型紧凑式过滤器（V Bank Compact Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | V Bank Compact Filter |
| 产品类别 | 中高效紧凑式 |
| 过滤效率 | F6-F9 |
| 材质 | 微型折叠超细玻璃纤维纸 |
| 外框 | ABS塑料框 |
| 耐温 | 80℃ |
| 测试标准 | EN779 |
| 主要特点 | 结构紧凑、过滤面积大、高容尘、高风量、低压降 |
| 目标买家 | 洁净室、制药厂、电子厂、数据中心 |
| **采购触发** | 数据中心新建、洁净室改造、空间受限项目 |
| **采购关键词方向** | data center HVAC filter, compact filter cleanroom, pharmaceutical cleanroom project |

### 12. 箱式过滤器（Cassette Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Cassette Filter |
| 产品类别 | 箱式过滤器 |
| 过滤效率 | M6-F9 |
| 材质 | 深层折叠滤料 |
| 结构 | 单法兰/无法兰结构 |
| 测试标准 | EN779 |
| 主要特点 | 高容尘、低压降、高结构稳定性 |
| 目标买家 | 内燃机配套、燃气发电机组、工业设备制造商 |
| **采购触发** | 燃气发电项目、工业设备配套订单 |
| **采购关键词方向** | gas generator air intake filter, industrial engine filtration |

---

## 三、高效过滤产品（HEPA/ULPA）

### 13. 油雾过滤器（Oil Mist Filter - OMF）

| 项目 | 内容 |
|------|------|
| 英文名称 | Oil Mist Filter (OMF) |
| 产品类别 | 油雾专用过滤器 |
| 过滤效率 | G4→F9→H13 三级过滤 |
| 材质 | 玻纤吸油棉+合成纤维+H13 HEPA |
| 结构 | 立式带把手结构 |
| 测试标准 | EN1822 |
| 主要特点 | 三级过滤、可匹配Nederman标准、观察压降判断更换周期 |
| 目标买家 | 机械加工车间、CNC加工中心、金属切削 |
| **采购触发** | 车间环保改造、油雾排放标准升级、新建CNC车间 |
| **采购关键词方向** | oil mist collector project, CNC workshop ventilation, metalworking mist filtration |

### 14. 有隔板高效过滤器（Separator HEPA Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Separator HEPA Filter |
| 产品类别 | 高效过滤器 HEPA |
| 过滤效率 | H10, H13, H14 |
| 材质 | 超细玻璃纤维纸 |
| 外框 | MDF/镀锌/不锈钢框+铝隔板 |
| 耐温 | 80℃ |
| 测试标准 | EN1822 |
| 主要特点 | 铝隔板分隔、逐台测试、效率95%~99.995% MPPS |
| 目标买家 | 制药厂洁净室、医院手术室、半导体工厂 |
| **采购触发** | 新建手术室、制药厂GMP认证、半导体工厂扩建 |
| **采购关键词方向** | hospital operating room HEPA, pharmaceutical cleanroom certification, semiconductor fab expansion |

### 15. 无隔板高效过滤器（Mini-pleat HEPA Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Mini-pleat HEPA Filter |
| 产品类别 | 高效/超高效过滤器 |
| 过滤效率 | H10-H14, U15 |
| 材质 | 超细玻璃纤维纸 |
| 外框 | 铝型材/MDF框+热熔胶分隔 |
| 耐温 | 80℃ |
| 测试标准 | EN1822 |
| 主要特点 | 无隔板设计、体积小、双面护网、效率可达99.9995% |
| 目标买家 | 洁净室、半导体、制药、生物安全 |
| **采购触发** | 半导体厂新建、生物安全实验室建设、洁净室改造 |
| **采购关键词方向** | semiconductor cleanroom filter, bio-safety lab HEPA, cleanroom certification project |

### 16. 液槽密封高效过滤器（Gel-sealed HEPA Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Gel-sealed HEPA Filter |
| 产品类别 | 液槽密封高效 |
| 过滤效率 | H14 (99.99%) |
| 材质 | 超细玻璃纤维纸 |
| 外框 | 液槽凝胶密封框 |
| 测试标准 | EN1822 |
| 主要特点 | 聚氨酯凝胶密封、无泄漏、不挥发无毒、适合FFU和生物洁净 |
| 目标买家 | 生物制药、FFU系统、生物安全实验室 |
| **采购触发** | 生物制药厂新建、FFU系统改造、生物安全等级升级 |
| **采购关键词方向** | FFU HEPA filter, bio-pharmaceutical cleanroom, gel-seal filter project |

### 17. 耐高温紧凑式过滤器（High Temperature Compact Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | High Temperature Compact Filter |
| 产品类别 | 耐高温过滤器 |
| 过滤效率 | F6, F8, H13 |
| 材质 | 超细玻璃纤维纸 |
| 外框 | 镀锌钢/304不锈钢+波纹铝隔板 |
| 耐温 | 250-300℃ |
| 测试标准 | EN779/EN1822 |
| 主要特点 | 耐高温250-300℃、单/双/无法兰可选、高温烘箱专用 |
| 目标买家 | 高温烘箱、涂装烘干线、陶瓷/玻璃制造 |
| **采购触发** | 高温烘箱新建、涂装烘干线扩建、高温环境过滤改造 |
| **采购关键词方向** | high temperature oven HEPA, paint drying oven filtration, ceramic kiln exhaust filter |

---

## 四、工业除尘产品（Industrial Dust Collection）

### 18. 除尘滤袋（Dust Filter Bag）

| 项目 | 内容 |
|------|------|
| 英文名称 | Dust Filter Bag |
| 产品类别 | 工业除尘滤袋 |
| 材质 | 多种材质可选：PPS/Nomex/P84/Glass/Polyester/PP/Acrylic |
| 结构 | 针刺毡滤料，多种圈口/袋底型式 |
| 耐温 | 90-260℃ |
| 测试标准 | 行业标准 |
| 主要特点 | 9种材质可选、耐温90-260℃、耐酸碱耐磨、PTFE浸渍处理 |
| 目标买家 | 水泥厂、沥青搅拌站、生物质电站、化工厂 |
| **采购触发** | 新建除尘项目、环保排放标准升级、滤袋更换周期 |
| **采购关键词方向** | cement plant baghouse filter, biomass power plant dust collection, industrial bag filter replacement |

### 19. 滤筒（Cartridge Filter）

| 项目 | 内容 |
|------|------|
| 英文名称 | Cartridge Filter / Dust Cartridge |
| 产品类别 | 除尘滤筒 |
| 材质 | 无纺布/木浆纸/燃气轮机滤纸 |
| 结构 | 端盖+内外护网 |
| 测试标准 | 行业标准 |
| 主要特点 | 60+型号、多种安装方式、圆柱/锥形/法兰顶/旋装等 |
| 目标买家 | 工业除尘系统、焊烟净化、燃气轮机进气 |
| **采购触发** | 除尘系统改造、焊烟净化项目、燃气轮机维护 |
| **采购关键词方向** | dust collector cartridge filter, welding fume extraction, gas turbine intake filter |

---

## 产品线总结

| 产品组 | 核心产品 | 主要目标行业 | 海外买家类型 |
|--------|----------|-------------|-------------|
| 初效过滤 | 漆雾过滤棉、过滤棉、板式过滤器 | 汽车涂装、HVAC、通风 | 经销商、喷涂线供应商 |
| 中效过滤 | 袋式过滤器、V型过滤器 | 制药、电子、商业建筑 | 工程公司、洁净室承包商 |
| 高效过滤 | HEPA过滤器、液槽密封 | 半导体、制药、生物安全 | 制药工程公司、半导体设备商 |
| 工业除尘 | 除尘滤袋、滤筒 | 水泥、化工、电站 | 除尘系统集成商、EPC |