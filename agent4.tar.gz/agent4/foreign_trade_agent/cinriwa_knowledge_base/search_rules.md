# Cinriwa 搜索策略规则

## 搜索方向（按优先级）

### 方向A：经销商/贸易商渠道（P1）
寻找工业过滤产品的经销商和贸易商，建立渠道合作。

**搜索词示例：**
- industrial filter distributor + [国家名]
- air filtration products supplier + [国家名]
- HVAC filter wholesaler + [国家名]
- filtration media importer + [国家名]

### 方向B：汽车涂装/喷涂线（P1）
寻找汽车喷涂线的耗材采购方。

**搜索词示例：**
- paint booth filter supplier + [国家名]
- automotive painting line consumables + [国家名]
- spray booth filtration media + [国家名]
- automotive paint arrestor distributor + [国家名]

### 方向C：工业除尘/环保（P2）
寻找工业除尘项目采购方。

**搜索词示例：**
- dust collector filter bag + [国家名]
- industrial baghouse filter + [国家名]
- cement plant dust filtration + [国家名]
- air pollution control equipment + [国家名]

### 方向D：洁净室/制药（P3）
寻找洁净室和制药行业的过滤器采购方。

**搜索词示例：**
- clean room filter supplier + [国家名]
- pharmaceutical HEPA filter + [国家名]
- hospital HVAC contractor + [国家名]
- cleanroom engineering company + [国家名]

### 方向E：HVAC/通风（P3）
寻找 HVAC 通风系统过滤耗材采购方。

**搜索词示例：**
- HVAC filter manufacturer + [国家名]
- air conditioning filter distributor + [国家名]
- commercial ventilation supplier + [国家名]
- building ventilation filter + [国家名]

---

## 搜索词评分规则

### 关键词价值等级

| 等级 | 加分 | 说明 | 示例 |
|------|------|------|------|
| 高价值词 | +30 | 采购/项目信号 | project, factory, plant, production line, expansion, manufacturer, supplier, distributor, importer, contractor, maintenance, replacement, tender, RFQ |
| 普通价值词 | +15 | 行业/产品相关 | automotive, pharmaceutical, semiconductor, HVAC, industrial, paint, booth, coating, filtration, dust, collector, HEPA, cleanroom, ventilation |
| 基础词 | +5 | 通用描述 | filter, air, media, system, equipment, parts, material |
| 扣分词 | **-20** | 泛词/垃圾词 | company, companies, limited, ltd, corp, inc, group, cheap, free, pdf, manual, definition, wiki, job, career, news, blog, article, review, home, residential |

### 计算示例

| 搜索词 | 计算 | 总分 | 结果 |
|--------|------|------|------|
| Vietnam automotive paint booth supplier | Vietname+10, automotive+15, paint+15, booth+15, supplier+30 | 85 | ✅ 通过 |
| Vietnam automotive factory expansion | Vietnam+10, automotive+15, factory+30, expansion+30 | 85 | ✅ 通过 |
| Thailand cleanroom HEPA filter project | Thailand+10, cleanroom+15, HEPA+15, filter+5, project+30 | 75 | ✅ 通过 |
| air filter company Vietnam | filter+5, air+5, company-20, Vietnam+10 | 0 | ❌ 淘汰 |
| best air filter supplier | best(无), air+5, filter+5, supplier+30 | 40 | ❌ 淘汰 |
| filter media distributor Thailand | filter+5, media+5, distributor+30, Thailand+10 | 50 | ❌ 淘汰 |
| cement plant dust collection project | cement(无), plant+30, dust+15, collection(无), project+30 | 75 | ✅ 通过 |

### 及格线：60分
低于 60 分的搜索词跳过，不消耗 API 额度。

---

## 搜索意图分类

| 类别 | 优先级 | 说明 | 示例 |
|------|--------|------|------|
| A类：采购意图 | ⭐⭐⭐ 最高 | 明确采购/项目信号 | Vietnam automotive factory expansion, Thailand cleanroom construction project |
| B类：产业链寻找 | ⭐⭐ 中等 | 找行业参与者 | Vietnam automotive parts manufacturer, Thailand pharmaceutical company |
| C类：行业调查 | ⭐ 低 | 市场信息类 | Vietnam air filtration market size, HVAC industry Vietnam |

**策略：**
- A类：优先调用 API，占总搜索量的 70%
- B类：补充搜索，占 30%
- C类：不调用 API，用已有数据库或手动调研

---

## 排除规则

### 不要搜的领域
- 家用/消费级空气净化器（consumer, home, residential）
- 口罩/个人防护（mask, respirator）
- 水处理（water filter — 不是工业空气过滤）
- 标准品零售（amazon, ebay, shop）

### 不要搜的网站类型
- 新闻/博客
- 招聘网站
- 电商平台（alibaba, made-in-china, indiamart）
- 论坛/社区
- 学术论文/研究

---

## 搜索词生成策略

### 70/30 原则
- 70% 使用已验证有效的方向（经销商、汽车涂装）
- 30% 探索新方向

### 格式要求
- 每个搜索词必须包含国家名
- 使用英文
- 优先使用"项目词 + 行业词 + 产品词 + 国家"格式
- 信号型搜索词（RFQ/tender）不超过 30%
- 避免泛词：company, supplier, manufacturer 单独出现时扣分
- 关键词必须能回答"为什么这个搜索词值得消耗 API 额度"