"""
公司分析器（Company Analyzer v1.0）

核心功能：
1. 读取公司信息（名称、网站、摘要）
2. 访问公司官网首页，让 AI 判断公司类型
3. 综合判断：这个公司是不是潜在买家？评分多少？

与旧 filter.py 的区别：
- filter.py 做规则过滤（国家、MX 解析）
- company_analyzer.py 做 AI 理解（这个公司做什么的、会不会买我们的产品）
"""

import json
import logging
import re
from typing import Optional

import requests

from translator import ai_chat

logger = logging.getLogger(__name__)


def analyze_company(company: dict, strategy: dict) -> dict:
    """分析单个公司是否值得开发。

    三道闸门：
    1. 页面类型判断 → 是公司官网/产品页，还是文章/博客？
    2. 产品匹配判断 → 这家公司消耗我们的产品吗？
    3. 采购信号判断 → 有没有采购需求？

    Args:
        company: 公司信息（含 company_name, website, requirement 等）
        strategy: 买家策略（来自 buyer_profile_generator）

    Returns:
        分析结果：
        {
            "is_buyer": True/False,
            "confidence": 0-100,
            "reason": "判断理由",
            "buyer_type": "买家类型",
            "company_type": "公司类型",
            "grade": "A/B/C/D",
            "page_type": "company_homepage / blog_article / directory / unknown",
        }
    """
    company_name = company.get("company_name", "")
    website = company.get("website", "")
    snippet = company.get("requirement", "")

    # ── 第一关：URL 前置过滤 ──
    # 明显不是公司页面的 URL 直接降级，不浪费 AI 调用
    url_check = _check_url_type(website)
    if url_check == "blog_article":
        return _grade_result(company_name, "D", "非公司页面：博客/文章", "页面类型: 博客或文章，不是公司官网")
    if url_check == "directory":
        return _grade_result(company_name, "D", "非公司页面：目录页", "页面类型: 目录或聚合页面")
    if url_check == "association":
        return _grade_result(company_name, "D", "行业协会", "页面类型: 行业协会，非采购企业")
    if url_check == "news":
        return _grade_result(company_name, "C", "新闻页面", "页面类型: 新闻，需要人工确认公司信息")

    # 没有官网的，凭摘要信息简单判断
    if not website:
        return _analyze_by_snippet(company_name, snippet, strategy)

    # 有官网的，尝试获取首页内容让 AI 判断
    homepage_content = _fetch_homepage(website)

    if homepage_content:
        return _analyze_with_ai(company_name, website, homepage_content, snippet, strategy)
    else:
        # 抓不到首页内容，改为 AI 分析 URL 和摘要
        return _analyze_by_url(company_name, website, snippet, strategy)


def _check_url_type(url: str) -> str:
    """通过 URL 路径判断页面类型。

    Returns:
        "company_homepage", "blog_article", "directory", "association", "news", "unknown"
    """
    if not url:
        return "unknown"

    url_lower = url.lower()

    # 博客/文章/指南
    blog_patterns = [
        "/blog/", "/blogs/", "/article/", "/articles/",
        "/news/", "/guide/", "/guides/", "/how-to/",
        "/tutorial/", "/faq/", "/questions/", "/wiki/",
        "/knowledge/", "/resource/", "/resources/",
        "/insights/", "/insight/", "/learn/", "/learning/",
    ]
    for p in blog_patterns:
        if p in url_lower:
            return "blog_article"

    # 目录/聚合
    directory_patterns = [
        "/directory", "/list/", "/top-", "/best-",
        "/companies/", "/suppliers/", "/vendors/",
    ]
    for p in directory_patterns:
        if p in url_lower:
            return "directory"

    # 第三方组织架构/人事页面
    org_patterns = ["theorg.com/org/", "linkedin.com/in/", "linkedin.com/company/"]
    for p in org_patterns:
        if p in url_lower:
            return "directory"

    # 行业协会
    assoc_patterns = [
        "association", "associations", "institute", "federation",
        "chamber", "council", "society",
    ]
    for p in assoc_patterns:
        if f"/{p}/" in url_lower or f"-{p}" in url_lower or url_lower.startswith(p):
            return "association"

    return "unknown"


def _fetch_homepage(url: str) -> Optional[str]:
    """获取公司官网首页的文本内容。"""
    try:
        # 尝试获取首页
        resp = requests.get(
            url,
            timeout=10,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html",
            },
        )
        if resp.status_code != 200:
            # 尝试获取根域名
            from urllib.parse import urlparse
            parsed = urlparse(url)
            base = f"{parsed.scheme}://{parsed.netloc}"
            resp = requests.get(base, timeout=10, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            })
            if resp.status_code != 200:
                return None

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "lxml")

        # 移除 script、style、nav、footer
        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()

        # 获取正文文本
        text = soup.get_text(separator=" ", strip=True)
        # 清理多余空格，截取前 2000 字符
        text = re.sub(r"\s+", " ", text)[:2000]
        return text if len(text) > 100 else None

    except Exception as e:
        logger.debug(f"获取首页失败 {url}: {e}")
        return None


def _analyze_with_ai(company_name: str, website: str, homepage: str,
                      snippet: str, strategy: dict) -> dict:
    """三道闸门分析：页面类型 → 产品匹配 → 采购信号。"""
    product_info = strategy.get("product_info", {})
    product_name = product_info.get("product_name", "")
    buyer_analysis = strategy.get("buyer_analysis", {})
    buyer_types = buyer_analysis.get("buyer_types", [])
    avoid_types = buyer_analysis.get("avoid_types", [])
    purchase_triggers = buyer_analysis.get("purchase_triggers", [])
    negative_keywords = strategy.get("search_strategy", {}).get("negative_keywords", [])

    system_prompt = (
        "你是一个工业过滤产品的B2B海外销售机会分析专家。你的任务是帮助中国工业过滤企业\n"
        "判断一家海外公司是否值得开发，以及如何切入。\n\n"
        "【评分标准（总分100分）】\n\n"
        "1. 企业真实性（30分）——这家公司是不是真实存在的企业\n"
        "   - 有真实公司官网且内容完整: +30\n"
        "   - 有官网但信息有限: +20\n"
        "   - 有公司名称和业务描述但无官网: +10\n"
        "   - 无法判断是否为真实企业: 0\n\n"
        "2. 产品匹配（30分）——这家公司是否需要我们的过滤产品\n"
        "   - 直接使用过滤产品（如汽车涂装、制药洁净室、HVAC系统）: +30\n"
        "   - 工程配套/系统集成（如洁净室工程公司、喷涂设备商）: +25\n"
        "   - 渠道商/经销商/进口商/MRO供应商: +20\n"
        "   - 相关制造业（如电子厂、食品厂、化工厂）: +15\n"
        "   - 完全不相关: 0\n\n"
        "3. 供应链开放度（20分）——中国供应商切入的难易程度\n"
        "   高开放度（+20）：\n"
        "   - 网站有 supplier registration / vendor registration 入口\n"
        "   - 有 partner with us / become a distributor 页面\n"
        "   - 中小型私营企业\n"
        "   - 采购页面显示 sourcing / procurement 需求\n"
        "   中开放度（+12）：\n"
        "   - 普通制造企业，无明确供应商入口但无封闭信号\n"
        "   低开放度（+5）：\n"
        "   - 大型企业但无明确供应链封闭信号\n"
        "   封闭（locked，+0）：\n"
        "   - 跨国企业、大型集团\n"
        "   - 明确有 existing suppliers / long-term partnership\n"
        "   - 全球集采（global sourcing headquarters）\n\n"
        "4. 采购信号（20分）——是否有采购需求或合作机会\n"
        "   - RFQ / tender / supplier registration / procurement: +20\n"
        "   - expansion / new plant / new factory / project: +15\n"
        "   - production line / maintenance / MRO / replacement: +10\n"
        "   - 普通潜在客户，无明确信号: +5\n"
        "   - 无任何信号: 0\n\n"
        "【客户类型优先级——额外加减分】\n"
        "在以上评分基础上，根据客户类型额外加减分：\n\n"
        "A级客户类型（额外+10分）：\n"
        "  - 汽车喷漆房/涂装线设备商（automotive spray booth / paint line manufacturer）\n"
        "  - 洁净室工程公司（cleanroom contractor / EPC）\n"
        "  - HVAC工程公司/系统集成商（HVAC engineering / system integrator）\n\n"
        "B级客户类型（不加分）：\n"
        "  - 工业耗材经销商/进口商（industrial MRO distributor / importer）\n"
        "  - 过滤产品组装商（filter assembler / fabricator）\n\n"
        "C级客户类型（额外-10分）：\n"
        "  - 过滤材料制造商（filter manufacturer，同行降权）\n"
        "  - 展会/媒体/目录网站（exhibition / media / directory）\n\n"
        "【四道闸门】\n"
        "第一道 - 页面类型：不是公司页面（博客/新闻/目录/协会）→ 直接 D 级\n"
        "第二道 - 产品匹配：这家公司消耗或配套我们的产品吗？\n"
        "第三道 - 供应链开放度：适合中国供应商切入吗？\n"
        "第四道 - 采购信号：有没有采购需求或合作可能？\n\n"
        "【强制规则】\n"
        "- 如果公司类型是过滤器制造商同行 → 总分减30，但**不要删除**，保留为 C 级候选\n"
        "- 如果页面类型是 blog_article / news_article / directory / association → 直接 D 级\n"
        "- 如果 supply_chain_fit == locked 或公司是大型跨国企业 → 最高 C 级\n"
        "- 同行不是排除对象，他们也可能有OEM/采购需求\n"
        "- 如果公司位于中国大陆（地址含中国城市/Suzhou/Shanghai/Beijing、电话+86、\n"
        "  域名.cn、页面含中文内容等信号）→ 直接 D 级排除（非海外客户）\n\n"
        "只输出合法的 JSON，不要包含 markdown 代码块标记。"
    )

    user_prompt = f"""## 我们的产品
{product_name}

## 目标买家类型
{', '.join(buyer_types) if buyer_types else '无'}

## 要避免的类型
{', '.join(avoid_types) if avoid_types else '无'}

## 采购触发条件
{', '.join(purchase_triggers) if purchase_triggers else '无'}

## 排除关键词
{', '.join(negative_keywords) if negative_keywords else '无'}

## 公司名称
{company_name}

## 公司网站
{website}

## 页面内容
{homepage[:1500]}

## 搜索摘要
{snippet[:300] if snippet else '无'}

请按评分标准分析，输出以下 JSON：
{{
  "page_type": "company_homepage / product_page / blog_article / news_article / directory / association / unknown",
  "page_type_reason": "为什么判断是这个页面类型",

  "match_level": "high / medium / low / none",
  "match_reason": "为什么匹配或不匹配",

  "signals_found": [
    "发现的信号1",
    "发现的信号2"
  ],
  "signal_level": "level1 / level2 / level3 / none",

  "supply_chain_fit": "high / medium / low / locked",
  "supply_chain_reason": "为什么认为这家公司供应链开放度如何",

  "company_scale": "small / medium / large / multinational",

  "grade": "A / B / C / D",
  "grade_reason": "为什么是这个等级",

  "authenticity_score": 0-30,
  "product_match_score": 0-30,
  "supply_chain_openness_score": 0-20,
  "purchase_signal_score": 0-20,
  "total_score": 0-100,

  "is_potential_buyer": true / false,
  "confidence": 0-100,
  "company_type": "公司类型描述",
  "buyer_type_match": "匹配的买家类型",
  "industry": "所属行业",
  "customer_type": "end_user / engineering_company / distributor / filter_manufacturer",
  "purchase_reason": "采购原因",
  "matched_products": ["匹配的产品1", "匹配的产品2"],
  "sales_rationale": "为什么这家公司需要 Cinriwa 的产品——给出具体的产品匹配和消耗场景，如：该公司建设汽车喷漆系统，需持续采购 Paint Stop Filter、HVAC Pre-filter、Activated Carbon Filter，是 Cinriwa 漆雾过滤产品的潜在替代供应商。",
  "reason": "综合判断理由"
}}

等级标准（按总分，注意同行扣30分后降级）：
A = total_score >= 70（真实企业 + 高匹配 + 开放供应链）
B = total_score >= 50
C = total_score >= 25
D = total_score < 25 或页面类型不对

注意：如果 customer_type 是 filter_manufacturer（同行），即使分数高也强制降级为 C。"""

    try:
        result = ai_chat(
            messages=[{"role": "user", "content": user_prompt}],
            system_prompt=system_prompt,
            temperature=0.2,
        )
        if result is None:
            return _default_result(company_name, "AI 调用失败")

        # 解析 JSON
        json_str = result.strip()
        if "```" in json_str:
            m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
            if m:
                json_str = m.group(1)
            else:
                json_str = json_str.replace("```json", "").replace("```", "").strip()

        data = json.loads(json_str)
        grade = data.get("grade", "D")
        is_buyer = grade in ("A", "B", "C")

        # 如果供应链锁定或大型跨国企业，强制降级
        supply_chain_fit = data.get("supply_chain_fit", "")
        company_scale = data.get("company_scale", "")
        if grade in ("A", "B") and (supply_chain_fit == "locked" or company_scale == "multinational"):
            logger.info(f"  供应链降级: {company_name} {grade}→C (大企业/供应链锁定)")
            grade = "C"

        confidence_map = {"A": 85, "B": 65, "C": 40, "D": 10}
        return {
            "is_buyer": is_buyer,
            "confidence": confidence_map.get(grade, 10),
            "reason": data.get("grade_reason", data.get("reason", "")),
            "buyer_type": data.get("buyer_type_match", ""),
            "company_type": data.get("company_type", ""),
            "grade": grade,
            "page_type": data.get("page_type", "unknown"),
        }

    except Exception as e:
        logger.warning(f"AI 分析异常 {company_name}: {e}")
        return _default_result(company_name, "分析异常")


def _analyze_by_url(company_name: str, website: str, snippet: str, strategy: dict) -> dict:
    """无法获取首页时，仅凭 URL 和摘要做判断。"""
    url_check = _check_url_type(website)
    if url_check in ("blog_article", "directory", "association"):
        return _grade_result(company_name, "D", f"非公司页面: {url_check}", f"URL 类型: {url_check}")

    if not snippet:
        return _grade_result(company_name, "D", "无法获取页面内容", "无首页内容且无摘要")

    # 有摘要，让 AI 做基本判断
    product_info = strategy.get("product_info", {})
    product_name = product_info.get("product_name", "")
    negative_keywords = strategy.get("search_strategy", {}).get("negative_keywords", [])

    for kw in negative_keywords:
        if kw.lower() in snippet.lower():
            return _grade_result(company_name, "D", f"摘要含排除词: {kw}", "")

    if not product_name:
        return _grade_result(company_name, "C", "仅有摘要，无法确认", "无产品信息，保守判断为 C")

    # 调用 AI 做简要判断
    system_prompt = (
        "根据公司名称和搜索摘要，快速判断这家公司是否可能采购我们的产品。\n"
        "只输出 JSON，不要解释。"
    )
    user_prompt = f"""产品: {product_name}
公司: {company_name}
网站: {website}
摘要: {snippet[:300]}

请判断：
{{
  "is_matching": true/false,
  "reason": "理由",
  "grade": "C / D"
}}"""

    try:
        result = ai_chat(messages=[{"role": "user", "content": user_prompt}], system_prompt=system_prompt, temperature=0.2)
        if result:
            json_str = result.strip()
            if "```" in json_str:
                m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
                if m:
                    json_str = m.group(1)
            data = json.loads(json_str)
            grade = data.get("grade", "D")
            return _grade_result(company_name, grade, data.get("reason", "无法获取首页内容"), "基于摘要的初步判断")
    except Exception:
        pass

    return _grade_result(company_name, "C", "无法获取首页内容，保守判断", "建议人工确认")


def _analyze_by_snippet(company_name: str, snippet: str, strategy: dict) -> dict:
    """没有官网时，仅凭搜索摘要做简单判断。"""
    if not snippet:
        return _grade_result(company_name, "D", "信息不足", "无搜索摘要，无法判断")

    # 简单关键词匹配
    negative_keywords = strategy.get("search_strategy", {}).get("negative_keywords", [])
    snippet_lower = snippet.lower()

    for kw in negative_keywords:
        if kw.lower() in snippet_lower:
            return _grade_result(company_name, "D", f"摘要含排除词: {kw}", "")

    # 无法判断，给 C 级（潜在客户，需人工确认）
    return {
        "is_buyer": None,
        "confidence": 30,
        "reason": "仅有搜索摘要，无法确认，建议人工查看",
        "buyer_type": "",
        "company_type": "",
        "grade": "C",
        "page_type": "unknown",
    }


def _grade_result(company_name: str, grade: str, reason: str, detail: str) -> dict:
    """返回分级结果。"""
    confidence_map = {"A": 85, "B": 65, "C": 40, "D": 10}
    is_buyer_map = {"A": True, "B": True, "C": None, "D": False}
    return {
        "is_buyer": is_buyer_map.get(grade, False),
        "confidence": confidence_map.get(grade, 10),
        "reason": reason,
        "buyer_type": "",
        "company_type": "",
        "grade": grade,
        "page_type": "unknown",
    }


def _default_result(company_name: str, reason: str) -> dict:
    """返回默认分析结果（D 级）。"""
    return {
        "is_buyer": None,
        "confidence": 0,
        "reason": reason,
        "buyer_type": "",
        "company_type": "",
        "grade": "D",
        "page_type": "unknown",
    }


# ── AI 快速筛选（轻量级，用于第一轮过滤） ────────────────────


def quick_classify(company: dict, product_name: str) -> str:
    """快速判断一家公司是否值得深度分析。

    职责（v3）：
    - 只判断"是不是一个真实存在的组织/公司"
    - 不判断"是不是客户"——客户判断交给 company_analyzer
    - 输出 B/C/D 三个等级

    Args:
        company: 公司信息
        product_name: 产品名称（不再使用，保留兼容）

    Returns:
        "B" = 真实公司/组织，值得深度分析
        "C" = 可能是公司，保留为后备
        "D" = 明显不是公司，排除
    """
    name = company.get("company_name", "")
    snippet = company.get("requirement", "")
    website = company.get("website", "")

    # ── 第0关：完全没有信息 → D ──
    if not name and not snippet and not website:
        return "D"

    # ── 第1关：URL 硬过滤（明显不是公司页面）→ D ──
    url_lower = website.lower() if website else ""

    # 博客/文章/招聘 → D
    skip_patterns = ["/blog/", "/blogs/", "/article/", "/articles/",
                     "/news/", "/job", "/career", "/event/", "/forum/",
                     "/faq", "/wiki", "/how-to", "/tutorial"]
    for p in skip_patterns:
        if p in url_lower:
            return "D"

    # 电商/聚合/招标平台 → D
    skip_domains = ["aliexpress", "alibaba", "made-in-china", "amazon",
                    "ebay", "indiamart", "amazonaws", "wikipedia",
                    "indeed.com", "linkedin.com", "facebook.com",
                    "yellowpages", "youtube.com", "twitter.com",
                    "tendersontime", "tenders.net", "tendernews",
                    "globaltenders", "tendersinfo", "tender247",
                    "constructiontenders", "tenderservice"]
    for d in skip_domains:
        if d in url_lower:
            return "D"

    # 域名本身是博客/新闻平台 → D
    try:
        from urllib.parse import urlparse
        parsed = urlparse(website)
        domain = parsed.netloc.lower()
        if domain.startswith("www."):
            domain = domain[4:]
        # 域名以 blog 开头或 blog. 开头 → 博客平台
        if domain.startswith("blog") or domain.startswith("blogger"):
            return "D"
    except Exception:
        pass

    # ── 第2关：判断"是不是一个真实组织" ──
    # 只检查两个核心信号：
    #   信号A：有官方网站（非平台域名）
    #   信号B：有业务内容描述（公司名或摘要体现了这是一个有业务的组织）
    #
    # 两个信号都满足 → B（真实公司）
    # 满足一个 → C（可能是公司）
    # 都不满足 → D（无法判断）
    signal_a = False
    signal_b = False

    # 信号A：有官方网站
    if website:
        from urllib.parse import urlparse
        try:
            parsed = urlparse(website)
            domain = parsed.netloc.lower()
            if domain.startswith("www."):
                domain = domain[4:]
            # 域名至少有两段且不是已知平台
            platform_domains = ["indeed.com", "linkedin.com", "facebook.com",
                                "twitter.com", "youtube.com", "wikipedia.org",
                                "amazon.com", "ebay.com"]
            is_platform = any(domain == d or domain.endswith("." + d)
                              for d in platform_domains)
            if "." in domain and not is_platform:
                signal_a = True
        except Exception:
            pass

    # 信号B：有业务内容描述
    # 公司名不是通用占位词 + 摘要/名称体现了业务内容
    _generic_names = {"contact", "home", "products", "services", "about",
                      "page not found", "404", "sign in", "login",
                      "register", "job listings", "careers", "blog"}
    has_meaningful_name = False
    if name and len(name.strip()) > 2:
        n = name.strip().lower()
        if n not in _generic_names:
            has_meaningful_name = True

    has_content = bool(snippet and len(snippet.strip()) > 10)

    if has_meaningful_name or has_content:
        signal_b = True

    # ── 判定 ──
    if signal_a and signal_b:
        return "B"  # 有网站 + 有业务内容 = 真实公司
    elif signal_a or signal_b:
        return "C"  # 只有一样，可能是公司
    else:
        return "D"