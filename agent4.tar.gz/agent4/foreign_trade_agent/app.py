# Streamlit 应用入口
# 外贸获客助手 v1.0 — 6 个页面的完整可视化界面

import json
import logging
import os
import shutil
import tempfile
import threading
import time
import zipfile
from http.server import HTTPServer, SimpleHTTPRequestHandler
from typing import Optional

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

# ── 配置 Streamlit 日志 ──────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

# ── 启动本地图片服务器 ──────────────────────────────────────
_img_server_started = False
def _start_img_server():
    global _img_server_started
    if _img_server_started:
        return
    _img_server_started = True
    try:
        _img_dir = os.path.dirname(os.path.abspath(__file__))
        class _ImgHandler(SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=_img_dir, **kwargs)
            def log_message(self, format, *args):
                pass
        server = HTTPServer(("127.0.0.1", 8765), _ImgHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
    except Exception as e:
        pass

_start_img_server()

# ── 页面配置（必须在任何 st 命令之前） ──────────────────────
st.set_page_config(
    page_title="外贸获客助手 v1.0",
    page_icon="🌐",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ── 导入业务模块 ─────────────────────────────────────────────
from config import API_CONFIG, CRAWLER_CONFIG, FILTER_CONFIG, MAIL_CONFIG, save_api_config, API_CONFIG_JSON
from config import get_search_config, save_search_config, get_search_mode, set_search_mode, get_usage_stats, get_target_regions, set_target_regions  # V4
from product_manager import (
    load_excel as pm_load_excel,
    save_product as pm_save_product,
    generate_search_plan as pm_generate_search_plan,
    switch_product as pm_switch_product,
    list_products as pm_list_products,
    delete_product as pm_delete_product,
    find_duplicates as pm_find_duplicates,
)
from crawler import run as crawler_run, get_customers, _atomic_save_customers, delete_customer
from matcher import match_all
from mail_generator import generate_all
from buyer_profile_generator import generate_strategy, save_strategy, load_strategy
from company_analyzer import analyze_company

from ui_components import inject_enterprise_css, render_page_header

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
PRODUCTS_JSON = os.path.join(DATA_DIR, "products.json")
CUSTOMERS_JSON = os.path.join(DATA_DIR, "customers.json")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PRODUCT_DATA_DIR, exist_ok=True)

# 注入企业级 UI 样式
inject_enterprise_css()


# ═══════════════════════════════════════════════════════════════
# 工具函数
# ═══════════════════════════════════════════════════════════════

def safe_runner(func, *args, **kwargs):
    """安全执行函数，捕获异常返回友好提示。"""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        st.error(f"操作执行失败: {str(e)[:200]}")
        return None


def load_customers_from_disk() -> list:
    """从磁盘读取客户列表。"""
    if not os.path.exists(CUSTOMERS_JSON):
        return []
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("customers", [])
    except Exception:
        return []


def load_search_plan_from_disk(product_id: str = "") -> Optional[dict]:
    """从磁盘读取搜索策略。优先 search_plan，其次 buyer_strategy。"""
    if product_id:
        # search_plan 优先
        path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_search_plan.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        # buyer_strategy 兜底
        bs_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json")
        if os.path.exists(bs_path):
            with open(bs_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    # 未指定 ID：找最新文件
    if not os.path.isdir(PRODUCT_DATA_DIR):
        return None
    all_files = os.listdir(PRODUCT_DATA_DIR)
    # 收集 search_plan 和 buyer_strategy 文件
    candidates = []
    for fname in all_files:
        if fname.endswith("_search_plan.json") or fname.endswith("_buyer_strategy.json"):
            candidates.append(fname)
    if not candidates:
        return None
    candidates.sort(key=lambda f: os.path.getmtime(os.path.join(PRODUCT_DATA_DIR, f)), reverse=True)
    with open(os.path.join(PRODUCT_DATA_DIR, candidates[0]), "r", encoding="utf-8") as f:
        return json.load(f)


def get_products_summary() -> list:
    """获取产品摘要列表，带缓存。"""
    if "products_summary" not in st.session_state:
        st.session_state.products_summary = safe_runner(pm_list_products) or []
    return st.session_state.products_summary


def refresh_products():
    """刷新产品列表缓存。"""
    st.session_state.products_summary = safe_runner(pm_list_products) or []


def copy_button(text: str, label: str = "复制到剪贴板", key: str = "copy"):
    """生成一个真正的复制到剪贴板按钮（使用 JavaScript）。"""
    import json as _json
    safe_text = _json.dumps(text)
    components.html(
        f"""
        <button onclick="navigator.clipboard.writeText({safe_text}); this.innerText='✅ 已复制'; this.style.color='#22c55e'"
                style="background:#1a1a2e; border:1px solid #6366f1; color:#e2e8f0; padding:6px 16px; border-radius:6px; cursor:pointer; font-size:14px;">
            {label}
        </button>
        """,
        height=40,
    )


# ═══════════════════════════════════════════════════════════════
# 侧边栏导航
# ═══════════════════════════════════════════════════════════════

PAGES = {
    "产品": "product",
    "线索": "crawler",
    "客户": "customers",
    "邮件": "email",
    "设置": "settings",
    "导出": "export",
    "看板": "dashboard",
}

# 侧边栏品牌
st.sidebar.markdown(
    '<div class="sidebar-brand"><div class="brand-title">外贸获客助手</div><div class="brand-sub">AI · 智能拓客</div></div>',
    unsafe_allow_html=True,
)

if "page" not in st.session_state:
    st.session_state.page = "product"

# 按键式导航，响应更快
for label, page_id in PAGES.items():
    is_active = st.session_state.page == page_id
    btn_type = "primary" if is_active else "secondary"
    if st.sidebar.button(label, key=f"nav_{page_id}", use_container_width=True, type=btn_type):
        st.session_state.page = page_id
        st.rerun()

st.sidebar.markdown("---")

# 免责声明放侧边栏底部
st.sidebar.markdown(
    '<p style="color:rgba(255,255,255,0.35); font-size:10px; text-align:center; line-height:1.5; padding:8px 12px;">'
    '工具不含跨境上网服务<br>批量邮件存在风险，发送前请复核'
    '</p>',
    unsafe_allow_html=True,
)


# ═══════════════════════════════════════════════════════════════
# 页面路由
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
# 页面 1: 产品管理
# ─────────────────────────────────────────────────────────────

if st.session_state.page == "product":
    # 处理待执行的删除操作（在渲染 UI 之前执行，避免 tab 跳转）
    _pending_del = st.session_state.pop("pending_delete", None)
    if _pending_del:
        _del_name = ""
        for _p in get_products_summary():
            if _p["product_id"] == _pending_del:
                _del_name = _p["product_name"]
                break
        if safe_runner(pm_delete_product, _pending_del):
            st.session_state.pop("products_summary", None)
            st.info(f"已删除: {_del_name or _pending_del}")

    render_page_header(
        title="产品",
        breadcrumb="产品",
        subtitle="管理产品档案、生成搜索策略",
    )

    # ── 自定义 tab 导航（替代 st.tabs，避免 rerun 后复位） ──
    _tab_labels = ["上传", "录入", "档案"]
    if "product_tab" not in st.session_state:
        st.session_state.product_tab = "上传"

    _tab_cols = st.columns(3, gap="small")
    for _i, _label in enumerate(_tab_labels):
        with _tab_cols[_i]:
            _is_active = st.session_state.product_tab == _label
            if st.button(
                _label,
                key=f"ptab_{_label}",
                use_container_width=True,
                type="primary" if _is_active else "secondary",
            ):
                st.session_state.product_tab = _label
                st.rerun()

    # ── Tab 1: 上传 Excel ────────────────────────────────────
    if st.session_state.product_tab == "上传":
        # 下载模板按钮
        _template_path = os.path.join(PRODUCT_DATA_DIR, "产品导入模板.xlsx")
        if os.path.exists(_template_path):
            with open(_template_path, "rb") as _f:
                st.download_button(
                    "下载导入模板",
                    data=_f,
                    file_name="产品导入模板.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )

        st.markdown("上传填写好的模板文件（.xlsx），AI 将自动分析产品并生成买家搜索策略")

        # ── 数据来源选择 ──
        _data_source = st.radio(
            "选择数据来源",
            ["上传 Excel 文件", "使用已有知识库"],
            horizontal=True,
            key="data_source",
        )

        if _data_source == "使用已有知识库":
            # 检测可用的知识库
            _kb_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cinriwa_knowledge_base")
            _has_kb = os.path.isdir(_kb_dir) and os.path.isfile(os.path.join(_kb_dir, "company_profile.md"))

            if not _has_kb:
                st.warning("未找到知识库文件，请先上传 Excel 或检查 cinriwa_knowledge_base/ 目录")
            else:
                st.markdown("**已加载知识库：Cinriwa（工业空气过滤产品）**")
                st.markdown(f"包含: 企业档案、19个产品详情、7个应用领域、买家画像、搜索规则")

                if st.button("生成搜索策略", type="primary", key="btn_kb_strategy"):
                    # 从知识库构建产品数据
                    product_data = {
                        "product_name": "工业过滤材料",
                        "english_name": "Industrial Air Filtration Products",
                        "category": "工业空气过滤",
                        "application": "汽车涂装、制药洁净室、电子半导体、工业除尘、HVAC通风",
                        "description": "Cinriwa 专业生产工业空气过滤净化产品，覆盖初效(G1-G4)到高效(H10-U15)全等级，包含漆雾过滤棉、HEPA过滤器、除尘滤袋等19个产品线，已通过ISO9001认证，服务于宝马、奥迪、沃尔沃等合资车企及制药企业。",
                        "material": "玻璃纤维、合成纤维、熔喷材料、超细玻璃纤维纸、针刺毡",
                        "advantage": "产品线覆盖全(G1→U15)、已通过合资车企供应链验证、具备定制生产能力、中英双语资料完整",
                        "certification": "ISO9001:2012",
                        "model": "Paint Stop Filter / HEPA Filter / Dust Filter Bag / Cartridge Filter",
                    }
                    supply_capability = {
                        "产能规模": "中型制造企业",
                        "交付能力": "标准产品现货，定制产品 2-4 周",
                        "目标市场": "东南亚、中东、非洲、拉美",
                        "已有客户类型": "汽车整车厂(宝马/奥迪/沃尔沃)、制药企业(以岭/同仁堂)、工业客户(中石油)",
                    }
                    customer_profile = {
                        "目标买家类型": "工业过滤耗材经销商、汽车涂装线供应商、洁净室工程公司、除尘系统集成商",
                        "目标行业": "汽车制造、制药医疗、电子半导体、工业除尘、HVAC",
                        "目标区域": "、".join(get_target_regions()),
                    }

                    with st.spinner("AI 正在根据知识库生成买家搜索策略..."):
                        from buyer_profile_generator import generate_strategy, save_strategy
                        strategy = safe_runner(
                            generate_strategy, product_data,
                            supply_capability, customer_profile,
                            target_regions=get_target_regions(),
                        )
                        if strategy:
                            pid = "cinriwa"
                            save_strategy(pid, strategy)
                            st.success(f"买家策略已生成！产品 ID: {pid}")
                            with st.expander("AI 买家分析结果", expanded=True):
                                col1, col2 = st.columns(2)
                                with col1:
                                    st.markdown(f"**产品类型**: {strategy.get('product_type', 'N/A')}")
                                    ba = strategy.get("buyer_analysis", {})
                                    st.markdown(f"**目标买家**: {'、'.join(ba.get('buyer_types', []))}")
                                    st.markdown(f"**目标行业**: {'、'.join(ba.get('buyer_industries', []))}")
                                with col2:
                                    sq = strategy.get("search_strategy", {})
                                    st.markdown(f"**搜索词 ({len(sq.get('search_queries', []))} 个)**")
                                    for q in sq.get("search_queries", [])[:8]:
                                        st.markdown(f"- {q}")
                                    if len(sq.get("search_queries", [])) > 8:
                                        st.markdown(f"... 还有 {len(sq.get('search_queries', [])) - 8} 个")
                        else:
                            st.error("策略生成失败，请检查 AI 配置")

        # ── Excel 上传（原有逻辑） ──
        uploaded_file = st.file_uploader(
            "选择 Excel 文件",
            type=["xlsx"],
            label_visibility="collapsed",
            key="excel_uploader",
        )

        if uploaded_file is not None:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                tmp.write(uploaded_file.getvalue())
                tmp_path = tmp.name

            with st.spinner("正在读取 Excel..."):
                result = safe_runner(pm_load_excel, tmp_path)

            os.unlink(tmp_path)

            if result and result.get("products"):
                st.markdown(f"读取到 {result['total']} 条产品记录")
                st.dataframe(
                    pd.DataFrame(result["products"]),
                    use_container_width=True,
                    hide_index=True,
                )

                # 查重
                product_names = [p.get("product_name", "") for p in result["products"]]
                duplicates = pm_find_duplicates(product_names)

                dup_mode = "overwrite"  # 默认
                if duplicates:
                    dup_list = "、".join(duplicates.keys())
                    st.markdown(
                        f"发现 {len(duplicates)} 个产品已存在: {dup_list}"
                    )
                    dup_mode = st.radio(
                        "处理方式",
                        ["save_all", "skip", "overwrite"],
                        format_func=lambda x: {
                            "save_all": "都保存（新增一份）",
                            "skip": "跳过重复（保留已有）",
                            "overwrite": "覆盖更新（用新信息替换）",
                        }[x],
                        horizontal=True,
                        index=2,
                        key="excel_dup_mode",
                    )

                if st.button("保存到产品库", type="primary", key="btn_save_excel"):
                    pid = safe_runner(pm_save_product, result, dup_mode)
                    if pid:
                        if duplicates and dup_mode == "skip":
                            st.info("已跳过重复产品，未新增")
                        else:
                            st.success(f"已保存，产品 ID: {pid}")
                        refresh_products()

                        # 生成买家策略（如有产品数据）
                        if result.get("products"):
                            first_product = result["products"][0]
                            with st.spinner("AI 正在分析产品，生成买家搜索策略..."):
                                strategy = safe_runner(
                                    generate_strategy,
                                    first_product,
                                    result.get("supply_capability"),
                                    result.get("customer_profile"),
                                    result.get("block_rules"),
                                    result.get("signal_library"),
                                    target_regions=get_target_regions(),
                                )
                                if strategy:
                                    save_strategy(pid, strategy)
                                    st.success("买家策略已生成！")
                                    # 显示买家分析摘要
                                    with st.expander("AI 买家分析结果", expanded=True):
                                        col1, col2 = st.columns(2)
                                        with col1:
                                            st.markdown(f"**产品类型**: {strategy.get('product_type', 'N/A')}")
                                            st.markdown(f"**买家逻辑**: {strategy.get('buyer_logic', 'N/A')}")
                                            ba = strategy.get("buyer_analysis", {})
                                            st.markdown(f"**目标买家**: {'、'.join(ba.get('buyer_types', []))}")
                                            st.markdown(f"**目标行业**: {'、'.join(ba.get('buyer_industries', []))}")
                                        with col2:
                                            st.markdown(f"**避免类型**: {'、'.join(ba.get('avoid_types', []))}")
                                            sq = strategy.get("search_strategy", {})
                                            st.markdown(f"**搜索词 ({len(sq.get('search_queries', []))} 个)**")
                                            for q in sq.get("search_queries", [])[:5]:
                                                st.markdown(f"- {q}")
                                else:
                                    st.warning("买家策略生成失败，请检查 API 配置")
            else:
                st.warning("未读取到产品数据，请检查 Excel 格式")

    # ── Tab 2: 手动输入 ──────────────────────────────────────
    elif st.session_state.product_tab == "录入":
        st.markdown("手动输入产品信息")

        col1, col2 = st.columns(2)
        with col1:
            manual_name = st.text_input("产品名称 *", key="manual_name")
            manual_spec = st.text_input("规格", key="manual_spec")
            manual_material = st.text_input("材质", key="manual_material")
            manual_cert = st.text_input("认证（如 ISO/CE）", key="manual_cert")
        with col2:
            manual_moq = st.text_input("MOQ", key="manual_moq")
            manual_capacity = st.text_input("产能/月", key="manual_capacity")
            manual_advantage = st.text_area("工厂优势", key="manual_advantage", height=100)

        # 如果产品名已存在的处理策略（默认覆盖）
        dup_mode_manual = st.radio(
            "如果产品名已存在",
            ["overwrite", "skip", "save_all"],
            format_func=lambda x: {
                "overwrite": "覆盖更新",
                "skip": "跳过",
                "save_all": "另存一份",
            }[x],
            horizontal=True,
            index=0,
            key="manual_dup_mode",
        )

        if st.button("保存产品", type="primary", key="btn_save_manual"):
            if not manual_name.strip():
                st.warning("请输入产品名称")
            else:
                product_data = {
                    "product_name": manual_name.strip(),
                    "specifications": manual_spec.strip(),
                    "material": manual_material.strip(),
                    "certification": manual_cert.strip(),
                    "moq": manual_moq.strip(),
                    "monthly_capacity": manual_capacity.strip(),
                    "factory_advantage": manual_advantage.strip(),
                }
                pid = safe_runner(pm_save_product, product_data, dup_mode_manual)
                if pid:
                    if dup_mode_manual == "skip":
                        st.info("已跳过重复产品")
                    else:
                        st.success(f"产品处理完成，ID: {pid}")
                    refresh_products()

    # ── Tab 3: 产品档案 ──────────────────────────────────────
    elif st.session_state.product_tab == "档案":
        products = get_products_summary()

        if not products:
            st.info("暂无产品档案，请先上传或手动输入")
        else:
            product_options = {f"{p['product_id']} — {p['product_name']}": p for p in products}
            default_key = None
            for key, p in product_options.items():
                if p.get("is_active"):
                    default_key = key
                    break
            if default_key is None:
                default_key = list(product_options.keys())[0]

            selected_product = st.selectbox(
                "选择产品",
                list(product_options.keys()),
                index=list(product_options.keys()).index(default_key) if default_key in product_options else 0,
                key="product_selector",
            )

            if selected_product:
                prod = product_options[selected_product]
                pid = prod["product_id"]
                has_plan = prod.get("has_search_plan", False)

                col1, col2, col3 = st.columns([1, 2, 1])
                with col1:
                    if st.button("切换到此产品", type="primary", key="btn_switch"):
                        safe_runner(pm_switch_product, pid)
                        refresh_products()
                        st.success(f"已切换到 {pid}")
                        st.rerun()

                with col2:
                    if st.button("生成搜索策略", type="primary", key="btn_gen_plan"):
                        with st.spinner("正在调用 AI 生成搜索策略..."):
                            plan = safe_runner(pm_generate_search_plan, pid)
                        if plan:
                            st.success("搜索策略已生成")
                            st.session_state[f"plan_{pid}"] = plan
                            st.rerun()
                        elif plan is None:
                            st.warning("生成失败，请检查 API 配置")

                with col3:
                    if st.button("删除产品", type="secondary", key="btn_del_product"):
                        st.session_state.pending_delete = pid
                        st.rerun()

                # 显示 search_plan
                plan_display = st.session_state.get(f"plan_{pid}") or load_search_plan_from_disk(pid)
                if plan_display:
                    with st.expander("搜索策略详情", expanded=True):
                        col1, col2 = st.columns(2)
                        with col1:
                            st.markdown("**关键词**")
                            st.write("、".join(plan_display.get("keywords", [])))
                            st.markdown("**目标行业**")
                            st.write("、".join(plan_display.get("target_industries", [])))
                        with col2:
                            st.markdown("**目标国家**")
                            st.write("、".join(plan_display.get("target_countries", [])))
                            st.markdown("**HS 编码**")
                            st.write("、".join(plan_display.get("hs_codes", [])))
                            st.markdown("**竞争对手**")
                            st.write("、".join(plan_display.get("competitors", [])))


# ─────────────────────────────────────────────────────────────
# 页面 2: 爬虫控制
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "crawler":
    render_page_header(
        title="线索",
        breadcrumb="线索",
        subtitle="配置采集流程，匹配目标客户",
    )

    # 显示当前搜索策略（优先显示 buyer_strategy）
    plan = load_search_plan_from_disk()
    buyer_strategy = None
    if plan:
        # 判断是否是 buyer_strategy（有 product_info 字段）
        if "product_info" in plan:
            buyer_strategy = plan
        else:
            pid = plan.get("product_id", "")
            if pid:
                buyer_strategy = load_strategy(pid)

    if buyer_strategy:
        with st.expander("买家策略（AI 生成）", expanded=True):
            col1, col2 = st.columns(2)
            with col1:
                pi = buyer_strategy.get("product_info", {})
                st.markdown(f"**产品**: {pi.get('product_name', '')}")
                st.markdown(f"**类型**: {buyer_strategy.get('product_type', '')}")
                st.markdown(f"**买家逻辑**: {buyer_strategy.get('buyer_logic', '')}")
                ba = buyer_strategy.get("buyer_analysis", {})
                st.markdown(f"**目标买家**: {'、'.join(ba.get('buyer_types', []))}")
            with col2:
                st.markdown(f"**目标行业**: {'、'.join(ba.get('buyer_industries', []))}")
                sq = buyer_strategy.get("search_strategy", {})
                st.markdown(f"**搜索词 ({len(sq.get('search_queries', []))} 个)**")
                for q in sq.get("search_queries", [])[:5]:
                    st.markdown(f"- {q}")
    elif plan:
        with st.expander("当前搜索策略", expanded=True):
            cols = st.columns(4)
            cols[0].markdown(f"**产品**  \n{plan.get('product_name', 'N/A')}")
            cols[1].markdown(f"**关键词**  \n{'、'.join(plan.get('keywords', []))}")
            cols[2].markdown(f"**目标行业**  \n{'、'.join(plan.get('target_industries', []))}")

            country_map = {c: f"{c}" for c in plan.get("target_countries", [])}
            cols[3].markdown(f"**目标国家**  \n{'、'.join(country_map.keys())}")
    else:
        st.info("暂无搜索策略，请先在「产品管理」页面生成")

    st.markdown("---")

    # 爬虫控制区域
    dry_run_crawl = st.checkbox(
        "DRY_RUN：跳过真实爬取（不勾选才会抓取真实客户）",
        value=False,
        key="dry_run_crawl",
        help="勾选后不访问 B2B 网站，仅用于验证流程；不勾选才会真实爬取",
    )

    # 搜索词预览 + 人工确认
    if buyer_strategy:
        sq = buyer_strategy.get("search_strategy", {}).get("search_queries", [])
        if sq:
            with st.expander("搜索词预览（共 {len(sq)} 个）"):
                for q in sq[:12]:
                    st.text(q)
                if len(sq) > 12:
                    st.text(f"... 还有 {len(sq) - 12} 个")

    col_start, col_status = st.columns([1, 2])

    with col_start:
        # 搜索前确认
        confirmed = st.checkbox("确认执行搜索", value=False, key="search_confirm",
                                help="勾选后才会真正消耗 API 额度")
        if st.button("开始搜索", type="primary", key="btn_start_crawl", use_container_width=True,
                      disabled=not confirmed):
            if not plan:
                st.warning("请先生成搜索策略")
            else:
                if dry_run_crawl:
                    st.info("测试模式：跳过爬取，不访问外网站点")
                else:
                    # 用 status 替代 spinner，浏览器不会超时
                    status = st.status("正在搜索客户信息...", expanded=True)
                    status.update(label="正在搜索各大平台...", state="running")

                    # 清除旧缓存，确保读取最新数据
                    st.session_state.pop("customers_cache", None)
                    success = safe_runner(crawler_run, plan.get("product_id", ""))

                    if success:
                        status.update(
                            label="搜索完成，客户数据已更新",
                            state="complete",
                        )
                    else:
                        status.update(
                            label="搜索完成，未找到新客户",
                            state="error",
                        )

                    # 清除缓存，刷新页面数据
                    st.session_state.pop("customers_cache", None)
                    st.rerun()

    with col_status:
        customers = load_customers_from_disk()
        total = len(customers)
        with_email = sum(1 for c in customers if c.get("email"))
        high_score = sum(1 for c in customers if (c.get("buyer_score") or 0) >= 70)

        cols = st.columns(3)
        cols[0].metric("数据库客户数", total)
        cols[1].metric("有邮箱", with_email)
        cols[2].metric("高分买家(≥70)", high_score)

    # 最近搜索结果
    if customers:
        st.markdown("---")
        st.markdown("**最近搜索结果**")
        df = pd.DataFrame(customers)
        display_cols = [c for c in ["company_name", "country", "email", "priority", "score"] if c in df.columns]
        if display_cols:
            st.dataframe(df[display_cols].head(10), use_container_width=True, hide_index=True)


# ─────────────────────────────────────────────────────────────
# 页面 3: 客户列表
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "customers":
    render_page_header(
        title="客户",
        breadcrumb="客户",
        subtitle="查看客户档案、评分与跟进状态",
    )

    customers = load_customers_from_disk()

    if not customers:
        st.info("暂无客户数据，请先在「线索」页面执行搜索")
    else:
        # 买家评分阈值
        threshold = st.slider(
            "买家评分阈值",
            min_value=0, max_value=100, value=0, step=5,
            key="threshold_slider",
        )
        filtered = [c for c in customers if (c.get("buyer_score") or 0) >= threshold]

        st.caption(f"共 {len(customers)} 条客户，评分 ≥ {threshold} 的 {len(filtered)} 条")

        if not filtered:
            st.info(f"暂无评分 ≥ {threshold} 的客户")
        else:
            # 表格
            df_display = []
            for c in filtered:
                df_display.append({
                    "公司名称": c.get("company_name", "")[:40],
                    "国家": c.get("country", ""),
                    "评分": c.get("buyer_score", "-"),
                    "买家类型": c.get("buyer_type", "")[:20],
                    "邮箱": c.get("email", ""),
                    "官网": c.get("website", "")[:40],
                })
            st.dataframe(pd.DataFrame(df_display), use_container_width=True, hide_index=True)

            # 每行一个卡片
            for c in filtered:
                cid = c.get("customer_id", "")
                with st.container():
                    cols = st.columns([5, 1])
                    with cols[0]:
                        g = c.get("candidate_grade", "?")
                        st.markdown(
                            f"[{g}] **{c.get('company_name', '')}**  "
                            f"`{c.get('country', '')}`  "
                            f"评分: {c.get('buyer_score', '-')}  "
                            f"类型: {c.get('buyer_type', 'N/A')}  "
                            f"📧 {c.get('email', '无邮箱')}  "
                            f"🌐 {c.get('website', '无官网')}"
                        )
                    with cols[1]:
                        if st.button("详情", key=f"det_{cid}"):
                            st.session_state[f"exp_{cid}"] = not st.session_state.get(f"exp_{cid}", False)
                            st.rerun()
                        if st.button("删除", key=f"del_{cid}"):
                            if delete_customer(cid):
                                st.rerun()

                    if st.session_state.get(f"exp_{cid}", False):
                        st.markdown(f"> **邮箱**: {c.get('email', '无')}  "
                                    f"**评分**: {c.get('buyer_score', '-')}/100  "
                                    f"**类型**: {c.get('buyer_type', 'N/A')}  "
                                    f"**理由**: {c.get('buyer_reason', '无')}")
                        st.markdown(f"> **采购需求**: {c.get('requirement', '无')}")
                        if c.get("ai_analysis"):
                            aa = c["ai_analysis"]
                            st.markdown(f"> **AI判断**: {'✅ 买家' if aa.get('is_buyer') else '❌ 非买家' if aa.get('is_buyer') is False else '❓ 不确定'}")
                        st.markdown("---")


# ─────────────────────────────────────────────────────────────
# 页面 4: 开发信
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "email":
    render_page_header(
        title="邮件",
        breadcrumb="邮件",
        subtitle="生成开发信，批量触达目标客户",
    )

    customers = load_customers_from_disk()

    if not customers:
        st.info("暂无客户数据")
    else:
        # 只显示达标的客户
        qualified = [c for c in customers if c.get("match_status") == "达标"]
        if not qualified:
            st.info("暂无达标客户，请先在「爬虫控制」执行匹配")
            matched_any = [c for c in customers if "score" in c]
            if matched_any:
                if st.button("线索评分", type="primary"):
                    with st.spinner("正在 AI 匹配..."):
                        safe_runner(match_all)
                    st.rerun()
            if st.button("生成开发信", type="primary"):
                with st.spinner("正在生成开发信..."):
                    safe_runner(generate_all)
                st.rerun()
        else:
            # 邮件安全开关
            dry_run_mail = st.checkbox(
                "DRY_RUN_MAIL：不发送真实邮件（默认开启，防止误发）",
                value=True,
                key="dry_run_mail",
                help="开启后点击「发送邮件」只模拟，不连接 SMTP",
            )

            # 选择客户
            options = {f"{c.get('company_name', '')} — {c.get('country', '')}": c for c in qualified}
            selected_email = st.selectbox("选择客户", list(options.keys()), key="email_customer_select")

            if selected_email:
                c = options[selected_email]

                # 如果还没有开发信，先生成
                if "mail_short" not in c or "mail_detailed" not in c:
                    st.info("该客户尚未生成开发信")
                    if st.button("生成开发信", type="primary", key="btn_gen_email"):
                        with st.spinner("正在生成..."):
                            safe_runner(generate_all)
                        st.success("开发信已生成")
                        st.rerun()
                else:
                    # Tab 切换简短版/详细版
                    tab_short, tab_detailed = st.tabs(["简短版", "详细版"])

                    with tab_short:
                        content_short = st.text_area(
                            "简短版开发信（可编辑）",
                            value=c.get("mail_short", ""),
                            height=300,
                            key="mail_short_edit",
                        )
                        col1, col2, col3 = st.columns([1, 1, 1])
                        with col1:
                            copy_button(content_short)
                        with col2:
                            if st.button("标记已处理", key="mark_short"):
                                # 防御性检查：如果 c 没有任何标识字段，提前报错
                                if not c.get("customer_id") and not c.get("website") and not c.get("email"):
                                    st.error("⚠️ 该客户缺少唯一标识（customer_id/website/email），无法更新")
                                    st.stop()
                                
                                # 更新客户状态（按 customer_id 定位，避免同名错改）
                                customers_all = load_customers_from_disk()
                                
                                # 确定查找 ID（优先 customer_id，降级到 website/email）
                                target_cid = c.get("customer_id")
                                if not target_cid:
                                    # 降级方案：用 website 或 email 作为备选 ID
                                    # 注意：不用 company_name，因为同名公司太多，容易误改
                                    target_cid = c.get("website") or c.get("email")
                                
                                # 遍历查找并更新
                                for cc in customers_all:
                                    cc_cid = cc.get("customer_id")
                                    if not cc_cid:
                                        # 老客户可能没有 customer_id，现场补一个
                                        cc_cid = cc.get("website") or cc.get("email")
                                    
                                    if cc_cid == target_cid and target_cid:
                                        cc["mail_status"] = "已处理"
                                        cc["mail_short"] = content_short
                                        break
                                
                                _atomic_save_customers(
                                    customers=customers_all,
                                    meta={"total": len(customers_all)},
                                    customers_json_path=CUSTOMERS_JSON,
                                )
                                st.success("已标记为已处理")
                                st.session_state.pop("customers_cache", None)
                                st.rerun()

                        with col3:
                            if st.button("发送邮件", key="send_short"):
                                if dry_run_mail:
                                    st.success("测试模式：已模拟发送（未发送真实邮件）")
                                else:
                                    from mail_sender import send_email
                                    from config import SMTP_CONFIG
                                    cfg = SMTP_CONFIG.get("default", {})
                                    if not cfg.get("smtp_server"):
                                        st.warning("请先在「设置」中配置 SMTP")
                                    elif not c.get("email"):
                                        st.warning("该客户没有邮箱地址")
                                    else:
                                        lines = content_short.strip().split("\n", 1)
                                        subject = lines[0].replace("Subject:", "").strip() if lines[0].startswith("Subject:") else f"Partnership with {c.get('company_name', '')}"
                                        body = lines[1] if len(lines) > 1 else content_short
                                        success = send_email(
                                            to_email=c["email"],
                                            subject=subject,
                                            body=body,
                                        )
                                        if success:
                                            st.success(f"✅ 已发送到 {c['email']}")
                                        else:
                                            st.error("发送失败，请检查 SMTP 配置")

                    with tab_detailed:
                        content_detailed = st.text_area(
                            "详细版开发信（可编辑）",
                            value=c.get("mail_detailed", ""),
                            height=400,
                            key="mail_detailed_edit",
                        )
                        col1, col2, col3 = st.columns([1, 1, 1])
                        with col1:
                            copy_button(content_detailed)
                        with col2:
                            if st.button("标记已处理", key="mark_detailed"):
                                # 防御性检查：如果 c 没有任何标识字段，提前报错
                                if not c.get("customer_id") and not c.get("website") and not c.get("email"):
                                    st.error("⚠️ 该客户缺少唯一标识（customer_id/website/email），无法更新")
                                    st.stop()
                                
                                # 更新客户状态（按 customer_id 定位，避免同名错改）
                                customers_all = load_customers_from_disk()
                                
                                # 确定查找 ID（优先 customer_id，降级到 website/email）
                                target_cid = c.get("customer_id")
                                if not target_cid:
                                    # 降级方案：用 website 或 email 作为备选 ID
                                    # 注意：不用 company_name，因为同名公司太多，容易误改
                                    target_cid = c.get("website") or c.get("email")
                                
                                # 遍历查找并更新
                                for cc in customers_all:
                                    cc_cid = cc.get("customer_id")
                                    if not cc_cid:
                                        # 老客户可能没有 customer_id，现场补一个
                                        cc_cid = cc.get("website") or cc.get("email")
                                    
                                    if cc_cid == target_cid and target_cid:
                                        cc["mail_status"] = "已处理"
                                        cc["mail_detailed"] = content_detailed
                                        break
                                
                                _atomic_save_customers(
                                    customers=customers_all,
                                    meta={"total": len(customers_all)},
                                    customers_json_path=CUSTOMERS_JSON,
                                )
                                st.success("已标记为已处理")
                                st.session_state.pop("customers_cache", None)
                                st.rerun()

                        with col3:
                            if st.button("发送邮件", key="send_detailed"):
                                if dry_run_mail:
                                    st.success("测试模式：已模拟发送（未发送真实邮件）")
                                else:
                                    from mail_sender import send_email
                                    from config import SMTP_CONFIG
                                    cfg = SMTP_CONFIG.get("default", {})
                                    if not cfg.get("smtp_server"):
                                        st.warning("请先在「设置」中配置 SMTP")
                                    elif not c.get("email"):
                                        st.warning("该客户没有邮箱地址")
                                    else:
                                        lines = content_detailed.strip().split("\n", 1)
                                        subject = lines[0].replace("Subject:", "").strip() if lines[0].startswith("Subject:") else f"Partnership with {c.get('company_name', '')}"
                                        body = lines[1] if len(lines) > 1 else content_detailed
                                        success = send_email(
                                            to_email=c["email"],
                                            subject=subject,
                                            body=body,
                                        )
                                        if success:
                                            st.success(f"✅ 已发送到 {c['email']}")
                                        else:
                                            st.error("发送失败，请检查 SMTP 配置")


# ─────────────────────────────────────────────────────────────
# 页面 5: 设置
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "settings":
    render_page_header(
        title="设置",
        breadcrumb="设置",
        subtitle="配置 AI 服务、邮件发送与运行参数",
    )

    tab_api, tab_smtp, tab_about = st.tabs(["API", "SMTP", "关于"])

    with tab_api:
        st.markdown("配置 AI 服务连接信息，用于生成搜索策略、客户匹配打分、开发信等。")

        # 从 api_config.json 实时读取，确保页面切换后仍显示已保存的值
        import json as _json
        _cfg_path = API_CONFIG_JSON
        _saved = {}
        if os.path.isfile(_cfg_path):
            try:
                with open(_cfg_path, "r", encoding="utf-8") as _f:
                    _saved = _json.load(_f)
            except Exception:
                pass

        base_url = _saved.get("base_url", "")
        api_key = _saved.get("api_key", "")
        model = _saved.get("model", "")

        # 初始化 session_state
        if "api_models" not in st.session_state:
            st.session_state.api_models = None
        if "api_tested" not in st.session_state:
            st.session_state.api_tested = False

        # ── API 地址 + 测试按钮（同一行） ──
        col_url, col_btn = st.columns([3, 1])
        with col_url:
            new_base_url = st.text_input(
                "API 地址",
                value=base_url,
                placeholder="https://api.openai.com/v1",
                help="兼容 OpenAI 格式的 API 地址",
            )
        with col_btn:
            st.markdown("### ")  # 与输入框标签对齐
            test_clicked = st.button("测试连接", type="primary", use_container_width=True)

        new_api_key = st.text_input(
            "API 密钥",
            value=api_key if api_key else "",
            type="password",
            placeholder="sk-...",
            help="你的 API 密钥",
        )

        # ── 测试连接逻辑 ──
        if test_clicked:
            if not new_base_url.strip() or not new_api_key.strip():
                st.error("请先填写 API 地址和密钥")
            else:
                with st.spinner("正在测试连接，获取模型列表..."):
                    try:
                        import requests as _req
                        _resp = _req.get(
                            new_base_url.rstrip("/") + "/models",
                            headers={"Authorization": f"Bearer {new_api_key.strip()}"},
                            timeout=15,
                        )
                        if _resp.status_code == 200:
                            _data = _resp.json()
                            _models = sorted(
                                set(
                                    m["id"]
                                    for m in (_data.get("data") or [])
                                    if isinstance(m, dict) and m.get("id")
                                )
                            )
                            if _models:
                                st.session_state.api_models = _models
                                st.session_state.api_tested = True
                                st.success(
                                    f"✅ 连接成功！检测到 {len(_models)} 个模型"
                                )
                            else:
                                st.warning("连接成功但未检测到模型，请手动输入模型名称")
                        else:
                            st.error(
                                f"连接失败: HTTP {_resp.status_code} — {_resp.text[:200]}"
                            )
                    except Exception as e:
                        st.error(f"连接失败: {str(e)[:200]}")

        # ── 模型选择（连接成功后有模型列表则用下拉框，否则用文本输入框） ──
        _models_list = st.session_state.api_models
        if _models_list:
            _idx = 0
            if model in _models_list:
                _idx = list(_models_list).index(model)
            selected_model = st.selectbox(
                "选择模型",
                _models_list,
                index=_idx,
                help="从 API 返回的可用模型中选择",
            )
        else:
            selected_model = st.text_input(
                "模型名称",
                value=model,
                placeholder="gpt-4o / qwen-plus / deepseek-chat",
                help="未测试连接时手动输入模型名称",
            )

        # ── 保存 ──
        st.markdown("---")
        if st.button("保存配置", type="primary", use_container_width=True):
            if not new_base_url.strip() or not new_api_key.strip():
                st.error("API 地址和密钥不能为空")
            else:
                save_api_config(
                    new_base_url.strip(),
                    new_api_key.strip(),
                    selected_model.strip(),
                )
                st.success("✅ 配置已保存")
                st.info(
                    "提示：部分模块（如爬虫、匹配）在下次操作时自动使用新配置，"
                    "无需重启应用。"
                )

        # 显示当前配置状态
        st.markdown("---")
        st.markdown("**当前状态**")
        if base_url and api_key:
            _masked = api_key[:6] + "****" + api_key[-4:] if len(api_key) > 12 else "****"
            st.markdown(f"- ✅ API 地址: `{base_url}`")
            st.markdown(f"- ✅ API 密钥: `{_masked}`")
            st.markdown(f"- ✅ 模型: `{model or '未设置'}`")
        else:
            st.warning("⚠️ API 配置未完成，请填写后保存")

        # ── 搜索引擎配置 ──
        st.markdown("---")
        st.markdown("### 搜索引擎配置")

        _scfg = get_search_config()
        _serpjet = _scfg.get("serpjet", {})
        _serper = _scfg.get("serper", {})
        _google = _scfg.get("google", {})
        _bing = _scfg.get("bing", {})

        # SERP 搜索 API（优先）
        st.markdown("**SERP 搜索 API**")
        col_s1, col_s2 = st.columns(2)
        with col_s1:
            _sj_enabled = st.checkbox("启用 SerpJet", value=_serpjet.get("enabled", True), key="sj_enabled")
            _sj_key = st.text_input("SerpJet API Key", value=_serpjet.get("api_key", ""),
                                    type="password", key="sj_key",
                                    help="sj_ 开头的 API Key，每月 1000 次免费额度")
        with col_s2:
            _sj_limit = st.number_input("每日限制", min_value=1, max_value=1000,
                                        value=_serpjet.get("daily_limit", 100), key="sj_limit")

        # Serper.dev API
        st.markdown("**Serper.dev API**")
        col_sp1, col_sp2 = st.columns(2)
        with col_sp1:
            _sp_enabled = st.checkbox("启用 Serper", value=_serper.get("enabled", False), key="sp_enabled")
            _sp_key = st.text_input("Serper API Key", value=_serper.get("api_key", ""),
                                    type="password", key="sp_key",
                                    help="https://serper.dev 注册获取 API Key")
        with col_sp2:
            _sp_limit = st.number_input("每日限制", min_value=1, max_value=1000,
                                        value=_serper.get("daily_limit", 100), key="sp_limit")

        st.markdown("**官方搜索 API**")
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("Google Custom Search API")
            _g_enabled = st.checkbox("启用 Google", value=_google.get("enabled", False), key="g_enabled")
            _g_key = st.text_input("Google API Key", value=_google.get("api_key", ""),
                                   type="password", key="g_key")
            _g_cx = st.text_input("Search Engine ID (CX)", value=_google.get("cx", ""), key="g_cx")
            _g_limit = st.number_input("每日限制", min_value=1, max_value=1000,
                                       value=_google.get("daily_limit", 80), key="g_limit")

        with col2:
            st.markdown("Bing Web Search API")
            _b_enabled = st.checkbox("启用 Bing", value=_bing.get("enabled", False), key="b_enabled")
            _b_key = st.text_input("Bing API Key", value=_bing.get("api_key", ""),
                                   type="password", key="b_key")
            _b_limit = st.number_input("每日限制", min_value=1, max_value=1000,
                                       value=_bing.get("daily_limit", 30), key="b_limit")

        _mode = st.selectbox(
            "搜索模式",
            ["serpjet_first", "serper_first", "google_first", "bing_first", "dual"],
            index=["serpjet_first", "serper_first", "google_first", "bing_first", "dual"].index(get_search_mode()),
            format_func=lambda x: {
                "serpjet_first": "SerpJet 优先",
                "serper_first": "Serper 优先",
                "google_first": "Google 优先",
                "bing_first": "Bing 优先",
                "dual": "全部启用（自动切换）",
            }[x],
        )

        st.markdown("**目标区域**")
        _regions = st.text_input(
            "只搜索以下国家（逗号分隔，留空不限制）",
            value=", ".join(get_target_regions()),
            key="target_regions",
            help="例如：Vietnam, Thailand, Malaysia",
        )

        if st.button("保存搜索引擎配置", use_container_width=True):
            save_search_config(
                serpjet={"enabled": _sj_enabled, "api_key": _sj_key, "daily_limit": _sj_limit},
                serper={"enabled": _sp_enabled, "api_key": _sp_key, "daily_limit": _sp_limit},
                google={"enabled": _g_enabled, "api_key": _g_key, "cx": _g_cx, "daily_limit": _g_limit},
                bing={"enabled": _b_enabled, "api_key": _b_key, "daily_limit": _b_limit},
            )
            set_search_mode(_mode)
            # 保存目标区域
            _parsed = [r.strip() for r in _regions.split(",") if r.strip()]
            set_target_regions(_parsed)
            st.success("搜索引擎配置已保存")

        # ── 用量统计 ──
        st.markdown("---")
        st.markdown("### 今日用量")

        _usage = get_usage_stats()
        _cols = st.columns(5)
        _cols[0].metric("SerpJet", f"{_usage['serpjet']['used']} / {_usage['serpjet']['limit']}")
        _cols[1].metric("Serper", f"{_usage['serper']['used']} / {_usage['serper']['limit']}")
        _cols[2].metric("Google", f"{_usage['google']['used']} / {_usage['google']['limit']}")
        _cols[3].metric("Bing", f"{_usage['bing']['used']} / {_usage['bing']['limit']}")
        _cols[4].metric("日志条数", _usage["total_logs"])

    with tab_smtp:
        st.markdown("配置 SMTP 邮件发送服务，用于直接发送开发信。")

        # 读取已保存的 SMTP 配置
        import json as _js
        _smtp_path = os.path.join(os.path.dirname(API_CONFIG_JSON), "smtp_config.json")
        _saved_smtp = {}
        if os.path.isfile(_smtp_path):
            try:
                with open(_smtp_path, "r", encoding="utf-8") as _f:
                    _saved_smtp = _js.load(_f)
            except Exception:
                pass

        with st.form("smtp_config_form", clear_on_submit=False):
            col1, col2 = st.columns(2)
            with col1:
                smtp_server = st.text_input("SMTP 服务器", value=_saved_smtp.get("smtp_server", ""), placeholder="smtp.example.com")
                smtp_port = st.number_input("端口", value=_saved_smtp.get("port", 465), min_value=1, max_value=65535, step=1)
                smtp_ssl = st.checkbox("使用 SSL", value=_saved_smtp.get("use_ssl", True))
            with col2:
                smtp_email = st.text_input("发件邮箱", value=_saved_smtp.get("email", ""), placeholder="your@email.com")
                smtp_password = st.text_input("邮箱密码/授权码", value=_saved_smtp.get("password", ""), type="password")

            if st.form_submit_button("保存 SMTP 配置", type="primary", use_container_width=True):
                from config import save_smtp_config
                save_smtp_config(smtp_server, int(smtp_port), smtp_ssl, smtp_email, smtp_password)
                st.success("✅ SMTP 配置已保存")

        # 显示当前状态
        if _saved_smtp.get("smtp_server") and _saved_smtp.get("email"):
            pw = "****" if _saved_smtp.get("password") else "未设置"
            st.markdown(f"- ✅ SMTP: `{_saved_smtp['smtp_server']}:{_saved_smtp.get('port', 465)}`")
            st.markdown(f"- ✅ 邮箱: `{_saved_smtp['email']}`")
        else:
            st.warning("⚠️ SMTP 配置未完成，发送邮件功能不可用")

    with tab_about:
        st.markdown("### 外贸获客助手 v1.0")
        st.markdown("基于 AI 的外贸客户开发与邮件营销工具。")
        st.markdown("")
        st.markdown("**技术栈**: Streamlit + requests + BeautifulSoup + pandas")
        st.markdown("**数据目录**: `data/`")
        st.markdown("**依赖**: 见 `requirements.txt`")


# ─────────────────────────────────────────────────────────────
# 页面 6: 数据导出
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "export":
    render_page_header(
        title="导出",
        breadcrumb="导出",
        subtitle="导出客户数据与迁移包",
    )

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### 导出 Excel")
        st.markdown("导出全部客户数据，包含公司信息、匹配分、开发信、发送状态")

        customers = load_customers_from_disk()
        if not customers:
            st.info("暂无客户数据可导出")
        else:
            if st.button("导出 Excel", type="primary", use_container_width=True, key="btn_export_excel"):
                try:
                    df = pd.DataFrame(customers)
                    # 展开嵌套字段
                    for col in ["mail_short", "mail_detailed", "match_reason", "filter_reason"]:
                        if col in df.columns:
                            df[col] = df[col].astype(str)

                    export_path = os.path.join(DATA_DIR, "customers_export.xlsx")
                    df.to_excel(export_path, index=False, engine="openpyxl")
                    st.success(f"✅ 已导出: {export_path}")

                    with open(export_path, "rb") as f:
                        st.download_button(
                            "下载 Excel",
                            data=f,
                            file_name="customers_export.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            use_container_width=True,
                        )
                except Exception as e:
                    st.error(f"导出失败: {str(e)[:200]}")

    with col2:
        st.markdown("### 全量迁移包")
        st.markdown("打包 data/ 和 product_data/ 目录为 zip 文件")

        if st.button("导出迁移包", type="primary", use_container_width=True, key="btn_export_zip"):
            try:
                zip_path = os.path.join(DATA_DIR, "backup_export.zip")
                with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                    for folder in ["data", "product_data"]:
                        folder_path = os.path.join(BASE_DIR, folder)
                        if os.path.isdir(folder_path):
                            for root, _, files in os.walk(folder_path):
                                for fn in files:
                                    if fn.endswith(".zip"):
                                        continue
                                    file_path = os.path.join(root, fn)
                                    arcname = os.path.relpath(file_path, BASE_DIR)
                                    zf.write(file_path, arcname)
                st.success(f"✅ 已打包: {zip_path} ({os.path.getsize(zip_path)/1024:.1f} KB)")

                with open(zip_path, "rb") as f:
                    st.download_button(
                        "下载迁移包",
                        data=f,
                        file_name="backup_export.zip",
                        mime="application/zip",
                        use_container_width=True,
                    )
            except Exception as e:
                st.error(f"打包失败: {str(e)[:200]}")

    # 显示导出文件列表
    st.markdown("---")
    st.markdown("### 数据目录")

    if os.path.isdir(DATA_DIR):
        files = [f for f in os.listdir(DATA_DIR) if os.path.isfile(os.path.join(DATA_DIR, f)) and not f.startswith(".")]
        if files:
            for f in sorted(files, key=lambda x: os.path.getmtime(os.path.join(DATA_DIR, x)), reverse=True):
                fpath = os.path.join(DATA_DIR, f)
                size = os.path.getsize(fpath)
                mtime = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(fpath)))
                st.text(f"  {mtime}  {size:>8,} B  {f}")


# ─────────────────────────────────────────────────────────────
# 页面 6: 统计看板
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "dashboard":
    render_page_header(
        title="看板",
        breadcrumb="看板",
        subtitle="采集、评分、触达与客户增长核心指标",
    )

    customers = load_customers_from_disk()
    total = len(customers)
    qualified = sum(1 for c in customers if c.get("match_status") == "达标")
    emailed = sum(1 for c in customers if c.get("mail_status") == "已处理" or ("mail_short" in c and c.get("mail_short")))
    high_priority = sum(1 for c in customers if c.get("priority") == "高")

    # 四个指标卡片
    cols = st.columns(4)
    with cols[0]:
        st.metric("累计客户数", total)
    with cols[1]:
        st.metric("达标客户", qualified)
    with cols[2]:
        st.metric("已生成邮件", emailed)
    with cols[3]:
        rate = f"{emailed/max(qualified, 1)*100:.0f}%" if qualified else "-"
        st.metric("邮件覆盖率", rate)

    st.markdown("---")

    if customers:
        col_chart1, col_chart2 = st.columns(2)

        # 柱状图：国家分布
        with col_chart1:
            st.markdown("**客户按国家分布**")
            country_counts = {}
            for c in customers:
                country = c.get("country", "未知")
                country_counts[country] = country_counts.get(country, 0) + 1

            if country_counts:
                df_country = pd.DataFrame(
                    sorted(country_counts.items(), key=lambda x: x[1], reverse=True),
                    columns=["国家", "客户数"],
                )
                st.bar_chart(df_country.set_index("国家"), height=300)

        # 饼图：匹配分数分布
        with col_chart2:
            st.markdown("**匹配分数分布**")
            scored = [c.get("score", 0) for c in customers if "score" in c]
            if scored:
                bins = {"0-3分": 0, "4-6分": 0, "7-8分": 0, "9-10分": 0}
                for s in scored:
                    s = int(s)
                    if s <= 3:
                        bins["0-3分"] += 1
                    elif s <= 6:
                        bins["4-6分"] += 1
                    elif s <= 8:
                        bins["7-8分"] += 1
                    else:
                        bins["9-10分"] += 1

                df_score = pd.DataFrame(
                    list(bins.items()),
                    columns=["分数段", "客户数"],
                )
                st.bar_chart(df_score.set_index("分数段"), height=300, color="#ff9f43")

        # 优先级分布
        st.markdown("**⭐ 优先级分布**")
        priority_counts = {}
        for c in customers:
            pri = c.get("priority", "未分类")
            priority_counts[pri] = priority_counts.get(pri, 0) + 1
        if priority_counts:
            df_pri = pd.DataFrame(
                sorted(priority_counts.items(), key=lambda x: {"高": 0, "中": 1, "低": 2}.get(x[0], 9)),
                columns=["优先级", "客户数"],
            )
            st.bar_chart(df_pri.set_index("优先级"), height=200)
    else:
        st.info("暂无数据，请先在「爬虫控制」页面执行搜索")


