"""
买家画像生成器（Buyer Intelligence Engine v1.0）

核心功能：
1. 理解产品（判断类型、应用领域、下游行业）
2. 生成买家画像（谁需要、什么类型、什么场景）
3. 生成搜索策略（搜索词、排除词、判断规则）

工作方式：
- 输入：产品信息（来自 Excel 或手动录入）
- 输出：buyer_strategy.json（完整的搜索+判断策略）
- 依赖：AI 动态生成，不依赖行业数据库
"""

import json
import logging
import os
import re
from typing import Any, Optional

from translator import ai_chat

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")


def generate_strategy(product_data: dict, supply_capability: dict = None,
                       customer_profile: dict = None, block_rules: dict = None,
                       signal_library: list = None) -> Optional[dict]:
    """生成完整的采购信号搜索策略。

    Args:
        product_data: 产品信息（来自 Sheet 1）
        supply_capability: 供应能力（来自 Sheet 2）
        customer_profile: 目标客户画像（来自 Sheet 3）
        signal_library: 采购信号库（来自 Sheet 4）
        block_rules: 排除规则（来自 Sheet 5）

    Returns:
        完整的 buyer_strategy JSON，失败返回 None。
    """
    # 构建产品描述
    product_desc = _build_product_description(product_data)

    # 构建供应能力文本
    supply_text = ""
    if supply_capability:
        parts = ["【供应能力】"]
        for k, v in supply_capability.items():
            if v:
                parts.append(f"  {k}: {v}")
        supply_text = "\n".join(parts)

    # 构建客户画像文本
    profile_text = ""
    if customer_profile:
        parts = ["【目标客户画像】"]
        for k, v in customer_profile.items():
            if v:
                parts.append(f"  {k}: {v}")
        profile_text = "\n".join(parts)

    # 构建采购信号文本
    signal_text = ""
    if signal_library:
        parts = ["【用户提供的采购信号】"]
        for s in signal_library:
            row = f"  信号: {s.get('signal_type', '')} | 搜索词: {s.get('search_query', '')} | 行业: {s.get('target_industry', '')} | 优先级: {s.get('priority', '')}"
            parts.append(row)
        signal_text = "\n".join(parts)

    # 构建排除规则文本
    block_text = ""
    if block_rules:
        parts = ["【排除规则】"]
        for k, v in block_rules.items():
            if v:
                parts.append(f"  {k}: {v}")
        block_text = "\n".join(parts)

    # 构建 prompt
    system_prompt = (
        "你是一个采购信号分析专家 + 供应商能力匹配专家。你的任务不是找'谁可能买这个产品'，\n"
        "而是找'谁当前存在采购需求，并且愿意/适合从中国中小供应商采购'。\n\n"
        "核心逻辑：\n"
        "1. 大型跨国企业供应链已固化，中国小供应商极难切入，要避开\n"
        "2. 优先找发展中地区中小型企业——它们供应链未锁定，正在寻找成本优势供应商\n"
        "3. 搜索词必须带国家名，不要搜全球范围\n\n"
        "【供应商能力画像】公司规模：小型 | 优势：中国制造成本、定制能力、小批量供应\n"
        "不适合客户：大型跨国企业 | 适合客户：发展中国家中小型环保设备企业\n\n"
        "【区域优先级】按以下比例分配搜索词数量：\n"
        "东南亚 40%（越南/泰国/印尼/马来西亚/菲律宾）→ 搜污水处理、环保设备、压滤机厂\n"
        "中东 25%（沙特/阿联酋/阿曼/埃及）→ 搜水处理工程公司、EPC承包商\n"
        "非洲 20%（南非/肯尼亚/尼日利亚/摩洛哥）→ 搜矿业过滤、水处理、食品加工\n"
        "拉美 10%（巴西/墨西哥/智利）→ 搜当地环保公司\n"
        "欧美 5%（德国/美国）→ 只搜经销商/贸易商，不搜终端用户\n\n"
        "【搜索词类型】\n"
        "企业型（70%）：直接搜行业公司，如\"filter press manufacturer\" Thailand\n"
        "信号型（30%）：搜采购信号，如\"RFQ\" filter cloth Vietnam\n"
        "注意：信号型搜索词容易搜出招标聚合网站，数量不要太多\n\n"
        "【采购信号三层（仅用于AI分析阶段，不是搜索词）】\n"
        "一级：RFQ/tender/supplier registration/vendor qualification/sourcing request\n"
        "二级：招聘采购经理、扩建工厂、新增生产线、新产品发布\n"
        "三级：寻找替代供应商、供应商多元化、降低采购成本\n\n"
        "要求：\n"
        "1. 每个搜索词必须带国家名\n"
        "2. 区分原材料和成品——原材料找加工厂，成品找渠道商\n"
        "3. 只输出合法 JSON，不要 markdown 代码块标记，不要解释文字"
    )

    user_prompt = f"""## 产品信息
{product_desc}

## 供应能力
{supply_text}

## 目标客户画像
{profile_text}

## 采购信号库
{signal_text}

## 排除规则
{block_text}

请生成以下 JSON 结构（严格遵循格式，不要加任何解释）：
{{
  "product_type": "raw_material / finished_product / industrial_equipment / component / consumer_product",
  "buyer_logic": "一句话描述这个产品的采购触发逻辑（什么情况下客户会考虑换供应商或新增采购）",

  "buyer_analysis": {{
    "who_needs_this_product": ["谁需要这个产品"],
    "buyer_types": ["买家类型1", "买家类型2"],
    "buyer_industries": ["买家行业1", "买家行业2"],
    "purchase_triggers": ["什么事件会触发采购（如扩产/新品/换供应商）"],
    "avoid_types": ["不要找的类型"]
  }},

  "search_strategy": {{
    "signal_keywords": ["RFQ", "tender", "supplier registration", "procurement manager", "alternative supplier", "dual sourcing"],
    "negative_keywords": ["supplier", "manufacturer", "factory", "china", "alibaba"],
    "search_queries": [
      "国家+行业+公司类型的组合1",
      "国家+行业+公司类型的组合2",
      "国家+产品+信号词的组合3"
    ]
  }},

  "company_filter": {{
    "preferred_company_types": ["优先找的公司类型——中小企业、成长型企业"],
    "avoid_company_types": ["避免找的公司类型——大型跨国企业、供应链固化的老牌企业"],
    "website_signals": {{
      "positive": ["网站上出现哪些词说明这确实是目标客户"],
      "negative": ["网站上出现哪些词说明这不是我们要找的"]
    }}
  }}
}}

要求：
- buyer_types 至少 3 个
- buyer_industries 至少 3 个
- purchase_triggers 至少 3 个
- signal_keywords 至少 6 个
- 【强制】search_queries 必须输出 20-25 个搜索词！按区域优先级分配数量：
  - 东南亚（40%）：8-10 个词
  - 中东（25%）：5-6 个词
  - 非洲（20%）：4-5 个词
  - 拉美（10%）：2-3 个词
  - 欧美（5%）：1-2 个词（只搜经销商/贸易商）
- 所有搜索词必须带国家名，格式："行业词" 国家
- 搜索词用英文，带引号的精确词 + 不带引号的描述词组合
- product_type 必须准确判断
"""

    result = ai_chat(
        messages=[{"role": "user", "content": user_prompt}],
        system_prompt=system_prompt,
        temperature=0.3,
    )

    if result is None:
        logger.error("generate_strategy: AI 调用失败")
        return None

    # 解析 JSON
    try:
        json_str = result.strip()
        if "```" in json_str:
            m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
            if m:
                json_str = m.group(1)
            else:
                json_str = json_str.replace("```json", "").replace("```", "").strip()
        strategy = json.loads(json_str)
    except json.JSONDecodeError:
        logger.error(f"generate_strategy: AI 返回非 JSON, raw={result[:200]}")
        return None

    # 补充产品信息
    strategy["product_info"] = {
        "product_name": product_data.get("product_name", ""),
        "english_name": product_data.get("english_name", ""),
        "category": product_data.get("category", ""),
        "application": product_data.get("application", ""),
    }

    logger.info(
        f"generate_strategy: 已生成买家策略"
        f"\n  产品: {strategy['product_info']['product_name']}"
        f"\n  类型: {strategy.get('product_type', 'N/A')}"
        f"\n  搜索词: {len(strategy.get('search_strategy', {}).get('search_queries', []))} 个"
    )
    return strategy


def save_strategy(product_id: str, strategy: dict) -> str:
    """保存买家策略到 product_data/ 目录。"""
    path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(strategy, f, ensure_ascii=False, indent=2)
    logger.info(f"save_strategy: 已保存 {path}")
    return path


def load_strategy(product_id: str) -> Optional[dict]:
    """加载已生成的买家策略。"""
    path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def get_search_queries(strategy: dict) -> list[str]:
    """从策略中提取搜索词列表。"""
    return strategy.get("search_strategy", {}).get("search_queries", [])


def get_buyer_industries(strategy: dict) -> list[str]:
    """从策略中提取目标行业。"""
    return strategy.get("buyer_analysis", {}).get("buyer_industries", [])


def get_negative_keywords(strategy: dict) -> list[str]:
    """从策略中提取排除关键词。"""
    return strategy.get("search_strategy", {}).get("negative_keywords", [])


def get_company_filter_rules(strategy: dict) -> dict:
    """从策略中提取公司过滤规则。"""
    return strategy.get("company_filter", {})


def _build_product_description(product_data: dict) -> str:
    """构建产品描述文本。"""
    fields = {
        "产品名称": product_data.get("product_name", ""),
        "英文名称": product_data.get("english_name", ""),
        "产品类别": product_data.get("category", ""),
        "型号/牌号": product_data.get("model", ""),
        "HS Code": product_data.get("hs_code", ""),
        "主要材料": product_data.get("material", ""),
        "应用领域": product_data.get("application", ""),
        "产品描述": product_data.get("description", ""),
        "主要参数": product_data.get("specifications", ""),
        "认证": product_data.get("certification", ""),
        "优势": product_data.get("advantage", ""),
    }
    lines = [f"{k}: {v}" for k, v in fields.items() if v]
    return "\n".join(lines)


def _build_sales_context(sales_info: dict, customer_history: list,
                          block_rules: dict) -> str:
    """构建销售背景文本。"""
    parts = []

    if sales_info:
        parts.append("【销售定位】")
        for k, v in sales_info.items():
            if v:
                parts.append(f"  {k}: {v}")

    if customer_history:
        parts.append("\n【已有客户经验】")
        for c in customer_history:
            parts.append(f"  国家: {c.get('country', '')} | 行业: {c.get('industry', '')} | 产品: {c.get('product', '')} | 原因: {c.get('reason', '')} | 类型: {c.get('customer_type', '')}")

    if block_rules:
        parts.append("\n【禁止规则】")
        for k, v in block_rules.items():
            if v:
                parts.append(f"  {k}: {v}")

    return "\n".join(parts) if parts else "暂无销售背景信息"