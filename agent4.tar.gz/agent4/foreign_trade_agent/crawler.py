# 爬虫调度入口
# 读取 search_plan → 调用各平台爬虫 → 去重 → 补邮箱 → 过滤 → 输出 customers.json

import hashlib
import json
import logging
import os
import shutil
import time
from typing import Any, Dict, List, Optional

from config import CRAWLER_CONFIG, get_search_config, get_search_mode, record_search

from crawler_plugins import alibaba_rfq
from crawler_plugins import google_search_api, bing_search_api, serpjet_search, serper_search
from crawler_plugins.contact_scanner import scan as scan_contact
from crawler_plugins._common import random_delay
from company_analyzer import analyze_company, quick_classify
from cleaner import clean

logger = logging.getLogger(__name__)

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
CUSTOMERS_JSON = os.path.join(DATA_DIR, "customers.json")

os.makedirs(DATA_DIR, exist_ok=True)


def run(product_id: str = "") -> bool:
    """执行 V4 搜索流程：Harness → Google/Bing API → 清洗 → AI分析 → 输出。

    Args:
        product_id: 产品 ID，为空时自动查找最新策略。

    Returns:
        True 表示成功（至少有一条有效客户），False 表示失败。
    """
    start_time = time.time()

    # ── 1. 加载策略 ──
    strategy = _load_strategy(product_id)
    if strategy is None:
        logger.error("run: 未找到 buyer_strategy")
        return False

    product_info = strategy.get("product_info", {})
    product_name = product_info.get("product_name", "未知产品")
    search_queries = strategy.get("search_strategy", {}).get("search_queries", [])

    if not search_queries:
        logger.error("run: 策略中无搜索词")
        return False

    # 随机抽取最多 12 个搜索词
    if len(search_queries) > 12:
        import random
        random.shuffle(search_queries)
        search_queries = search_queries[:12]

    # ── 搜索词质量评分过滤 ──
    product_name_lower = (strategy.get("product_info", {}).get("product_name", "") or "").lower()
    before_filter = len(search_queries)
    search_queries = [q for q in search_queries if _query_score(q) >= 60]

    # 评分后如果词太少，从 buyer_strategy 补几个
    if len(search_queries) < 3 and before_filter > 0:
        # 放宽标准再选一次
        search_queries = [q for q in strategy.get("search_strategy", {}).get("search_queries", [])
                         if _query_score(q) >= 40][:12]
        import random
        random.shuffle(search_queries)
        search_queries = search_queries[:12]

    logger.info(f"搜索词评分过滤: {before_filter} → {len(search_queries)} 个")

    # ── 目标区域过滤 ──
    from config import get_target_regions
    target_regions = get_target_regions()
    if target_regions:
        before_region = len(search_queries)
        region_lower = [r.lower() for r in target_regions]
        search_queries = [q for q in search_queries
                          if any(r in q.lower() for r in region_lower)]
        if search_queries:
            logger.info(f"目标区域过滤: {before_region} → {len(search_queries)} 个 ({', '.join(target_regions)})")
        else:
            logger.warning(f"目标区域过滤后无搜索词，跳过区域限制")

    target_industries = strategy.get("buyer_analysis", {}).get("buyer_industries", [])
    target_countries = strategy.get("target_countries", [])

    logger.info(
        f"=== 开始搜索 ==="
        f"\n  产品: {product_name}"
        f"\n  搜索词: {len(search_queries)} 个"
    )

    # ── 2. 执行搜索 ──
    search_cfg = get_search_config()
    serpjet_ok = search_cfg.get("serpjet", {}).get("enabled", False) and \
                 bool(search_cfg.get("serpjet", {}).get("api_key"))
    serper_ok = search_cfg.get("serper", {}).get("enabled", False) and \
                bool(search_cfg.get("serper", {}).get("api_key"))
    google_ok = search_cfg.get("google", {}).get("enabled", False) and \
                bool(search_cfg.get("google", {}).get("api_key"))
    bing_ok = search_cfg.get("bing", {}).get("enabled", False) and \
              bool(search_cfg.get("bing", {}).get("api_key"))
    mode = get_search_mode()

    all_raw: list[dict] = []
    used_engines = []

    for kw in search_queries:
        if len(all_raw) >= 200:
            break

        logger.info(f"--- 搜索: {kw[:60]} ---")

        # 确定搜索顺序（按优先级）
        engine_order = []
        if mode == "serpjet_first":
            # SerpJet → Serper → Google → Bing（自动切换）
            if serpjet_ok:
                engine_order.append(("serpjet", serpjet_search.search))
            if serper_ok:
                engine_order.append(("serper", serper_search.search))
            if google_ok:
                engine_order.append(("google", google_search_api.search))
            if bing_ok:
                engine_order.append(("bing", bing_search_api.search))
        elif mode == "serper_first":
            # Serper → SerpJet → Google → Bing
            if serper_ok:
                engine_order.append(("serper", serper_search.search))
            if serpjet_ok:
                engine_order.append(("serpjet", serpjet_search.search))
            if google_ok:
                engine_order.append(("google", google_search_api.search))
            if bing_ok:
                engine_order.append(("bing", bing_search_api.search))
        elif mode == "google_first":
            if google_ok:
                engine_order.append(("google", google_search_api.search))
            if bing_ok:
                engine_order.append(("bing", bing_search_api.search))
        elif mode == "bing_first":
            if bing_ok:
                engine_order.append(("bing", bing_search_api.search))
            if google_ok:
                engine_order.append(("google", google_search_api.search))
        else:  # dual — 全部启用
            if serpjet_ok:
                engine_order.append(("serpjet", serpjet_search.search))
            if serper_ok:
                engine_order.append(("serper", serper_search.search))
            if google_ok:
                engine_order.append(("google", google_search_api.search))
            if bing_ok:
                engine_order.append(("bing", bing_search_api.search))

        for name, search_fn in engine_order:
            if len(all_raw) >= 200:
                break
            try:
                results = search_fn(kw, target_countries[0] if target_countries else "",
                                    industries=target_industries)
                for r in results:
                    r["crawl_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
                all_raw.extend(results)
                used_engines.append(name)
            except Exception as e:
                logger.error(f"  {name} 异常: {e}")
            finally:
                # 每次 API 调用后等待 2-5 秒，保护账号信誉
                import random as _rand
                _wait = _rand.uniform(2.0, 5.0)
                logger.debug(f"  等待 {_wait:.1f}s")
                time.sleep(_wait)

    # 如果 API 搜索无结果，尝试 Alibaba RFQ 作为补充
    if not all_raw and google_ok or bing_ok:
        # 本应成功但没结果，可能是额度不足
        logger.info("API 搜索无结果，尝试 Alibaba RFQ 补充...")
    if not all_raw:
        logger.warning("run: 无搜索结果")
        return False

    logger.info(f"原始结果: {len(all_raw)} 条 (引擎: {set(used_engines)})")

    # ── 3. 清洗层 ──
    cleaned = clean(all_raw, target_countries)
    logger.info(f"清洗后: {len(cleaned)} 条")
    if not cleaned:
        logger.warning("run: 清洗后无结果")
        return False

    # ── 4. 跳过已推荐客户 ──
    known_set = load_known_set()
    before_skip = len(cleaned)
    cleaned = [c for c in cleaned if not is_known(c, known_set)]
    logger.info(f"跳过已推荐: {before_skip - len(cleaned)} 条")

    # ── 5. 补邮箱 ──
    _enrich_emails(cleaned)

    # ── 6. AI 快速筛选（先分类，再深度分析） ──
    product_name = strategy.get("product_info", {}).get("product_name", "")
    quick_a, quick_b, quick_c = [], [], []
    for c in cleaned:
        grade = quick_classify(c, product_name)
        if grade == "A" or grade == "B":
            quick_b.append(c)
        elif grade == "C":
            quick_c.append(c)
        # D 级直接丢弃
    logger.info(f"AI 快速筛选: B={len(quick_b)}(真实公司), C={len(quick_c)}(可能公司), D={len(cleaned) - len(quick_b) - len(quick_c)}(排除)")

    # B 和 C 都进深度分析（让 AI 多看，不在快速筛选阶段过滤）
    to_analyze = quick_b + quick_c
    analyzed = []
    if to_analyze:
        logger.info(f"开始 AI 深度分析 ({len(to_analyze)} 家)...")
        for c in to_analyze:
            analysis = analyze_company(c, strategy)
            grade = analysis.get("grade", "D")
            c["ai_analysis"] = analysis
            c["buyer_score"] = analysis.get("confidence", 0)
            c["buyer_reason"] = analysis.get("reason", "")
            c["buyer_type"] = analysis.get("buyer_type", "")
            c["company_type"] = analysis.get("company_type", "")
            c["supply_chain_fit"] = analysis.get("supply_chain_fit", "")
            c["company_scale"] = analysis.get("company_scale", "")
            c["candidate_grade"] = grade
            if grade in ("A", "B", "C"):
                analyzed.append(c)
        logger.info(f"AI 深度分析完成: {len(analyzed)}/{len(to_analyze)}")
    else:
        logger.info("无可深度分析的公司")

    # ── 7. 质量筛选 ──
    final = [c for c in analyzed if c.get("email") and c.get("candidate_grade") in ("A", "B", "C")]
    if not final:
        logger.warning("run: 质量筛选后无有效客户")
        _save_simple(final, product_name, strategy)
        return False

    # ── 8. 输出 ──
    _save_simple(final, product_name, strategy)

    elapsed = time.time() - start_time
    logger.info(
        f"=== 搜索完成 ==="
        f"\n  耗时: {elapsed:.1f}s"
        f"\n  原始: {len(all_raw)} → 清洗: {len(cleaned)} → AI通过: {len(analyzed)} → 最终: {len(final)}"
        f"\n  输出: {CUSTOMERS_JSON}"
    )
    return True


# ── 内部函数 ──────────────────────────────────────────────────


def load_search_plan(product_id: str = "") -> Optional[dict]:
    """加载搜索策略。优先 search_plan，其次 buyer_strategy。"""
    if product_id:
        # search_plan 优先
        plan_path = os.path.join(
            PRODUCT_DATA_DIR, f"{product_id}_search_plan.json"
        )
        if os.path.exists(plan_path):
            with open(plan_path, "r", encoding="utf-8") as f:
                return json.load(f)

        # buyer_strategy 兜底
        bs_path = os.path.join(
            PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json"
        )
        if os.path.exists(bs_path):
            with open(bs_path, "r", encoding="utf-8") as f:
                return json.load(f)

        logger.warning(f"搜索策略不存在: {product_id}")
        return None

    # 未指定 product_id → 找最新的
    if not os.path.isdir(PRODUCT_DATA_DIR):
        return None

    plan_files = []
    for f in os.listdir(PRODUCT_DATA_DIR):
        if f.endswith("_search_plan.json") or f.endswith("_buyer_strategy.json"):
            plan_files.append(f)
    if not plan_files:
        return None

    # 按修改时间排序，取最新的
    plan_files.sort(
        key=lambda f: os.path.getmtime(os.path.join(PRODUCT_DATA_DIR, f)),
        reverse=True,
    )
    latest = os.path.join(PRODUCT_DATA_DIR, plan_files[0])
    with open(latest, "r", encoding="utf-8") as f:
        return json.load(f)


def format_product_info(plan: dict) -> str:
    """将 search_plan 格式化为产品描述文本（供 matcher/mail_generator 使用）。"""
    parts = [
        f"产品名称: {plan.get('product_name', '')}",
        f"关键词: {', '.join(plan.get('keywords', []))}",
        f"目标行业: {', '.join(plan.get('target_industries', []))}",
        f"目标国家: {', '.join(plan.get('target_countries', []))}",
        f"HS编码: {', '.join(plan.get('hs_codes', []))}",
        f"主要竞争对手: {', '.join(plan.get('competitors', []))}",
    ]
    return "\n".join(parts)


def _add_results(
    pool: list, new_results: list, source: str, limit: int
) -> None:
    """将爬虫结果加入总池，标注来源，不超过 limit。"""
    for r in new_results:
        r["source"] = source
        r["crawl_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    pool.extend(new_results[:limit])


def _deduplicate(customers: list) -> list:
    """按公司官网去重，无官网的按公司名去重。"""
    seen_websites: set = set()
    seen_names: set = set()
    result: list = []

    for c in customers:
        website = (c.get("website") or "").strip().lower()
        name = (c.get("company_name") or "").strip().lower()

        if website and website not in seen_websites:
            seen_websites.add(website)
            result.append(c)
        elif not website and name and name not in seen_names:
            seen_names.add(name)
            result.append(c)

    return result


def _enrich_emails(customers: list) -> None:
    """并行扫描公司网站补邮箱（最多 10 线程）。"""
    import concurrent.futures

    def _scan_one(c):
        if c.get("email"):
            return
        website = c.get("website", "")
        if not website:
            return
        logger.info(f"contact_scanner: 扫描 {website}")
        try:
            email = scan_contact(website)
            if email:
                c["email"] = email
                c["email_source"] = "官网扫描"
                logger.info(f"  -> 找到邮箱: {email}")
        except Exception as e:
            logger.error(f"contact_scanner 扫描失败 {website}: {e}")

    to_scan = [c for c in customers if not c.get("email") and c.get("website")]
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
        pool.map(_scan_one, to_scan)


def _ensure_customer_id(customer: dict) -> dict:
    """为单条客户生成稳定 customer_id（sha256 截取 16 位）"""
    if customer.get("customer_id"):
        return customer

    company_name = (customer.get("company_name") or "").strip()
    website = (customer.get("website") or "").strip()
    email = (customer.get("email") or "").strip()
    country = (customer.get("country") or "").strip()

    if website:
        raw = f"{website}|{company_name}".lower()
    else:
        raw = f"{email}|{company_name}|{country}".lower()

    customer["customer_id"] = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return customer


def load_known_set() -> set:
    """加载已推荐客户的特征集合（website + company_name），用于跳过。

    Returns:
        已推荐特征集合，元素格式为 "website:xxx" 或 "name:xxx"。
    """
    known: set = set()
    if not os.path.exists(CUSTOMERS_JSON):
        return known
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        for c in data.get("customers", []):
            w = (c.get("website") or "").strip().lower()
            if w:
                known.add(f"website:{w}")
            n = (c.get("company_name") or "").strip().lower()
            if n:
                known.add(f"name:{n}")
    except Exception:
        pass
    return known


def is_known(company: dict, known_set: set) -> bool:
    """检查公司是否已在已推荐名单中。"""
    w = (company.get("website") or "").strip().lower()
    if w and f"website:{w}" in known_set:
        return True
    n = (company.get("company_name") or "").strip().lower()
    if n and f"name:{n}" in known_set:
        return True
    return False


def delete_customer(customer_id: str) -> bool:
    """从数据库中删除指定客户。

    Args:
        customer_id: 客户唯一 ID。

    Returns:
        True 表示删除成功，False 表示未找到。
    """
    if not os.path.exists(CUSTOMERS_JSON):
        return False
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return False

    old_len = len(data.get("customers", []))
    data["customers"] = [c for c in data.get("customers", []) if c.get("customer_id") != customer_id]
    data["meta"] = data.get("meta", {})
    data["meta"]["total"] = len(data["customers"])

    if len(data["customers"]) == old_len:
        return False  # 没找到

    _atomic_save_customers(
        customers=data["customers"],
        meta=data["meta"],
        customers_json_path=CUSTOMERS_JSON,
    )
    return True


def _atomic_save_customers(
    customers: List[dict],
    meta: Dict[str, Any],
    *,
    customers_json_path: str,
) -> None:
    """
    三段式原子写入 + meta 深合并：
    1. copy2 备份旧文件 → .bak
    2. 写入临时文件 → .tmp
    3. os.replace 原子替换
    meta 深合并：保留已有全部字段，只补充/覆盖新 stage 信息
    """
    # 读取现有文件
    existing = None
    if os.path.exists(customers_json_path):
        try:
            with open(customers_json_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            existing = None

    existing_meta = {}
    if existing and isinstance(existing, dict):
        existing_meta = existing.get("meta", {}) or {}

    # 深合并 meta
    def deep_merge(a: dict, b: dict) -> dict:
        out = dict(a)
        for k, v in b.items():
            if k in out and isinstance(out[k], dict) and isinstance(v, dict):
                out[k] = deep_merge(out[k], v)
            else:
                out[k] = v
        return out

    merged_meta = deep_merge(existing_meta, meta)
    payload = {"meta": merged_meta, "customers": customers}

    # 备份旧文件（copy2 保留原文件，避免写入失败时丢失）
    bak_path = f"{customers_json_path}.bak"
    tmp_path = f"{customers_json_path}.tmp"

    if os.path.exists(customers_json_path):
        try:
            shutil.copy2(customers_json_path, bak_path)
        except Exception:
            pass

    # 写入临时文件
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    # 原子替换
    os.replace(tmp_path, customers_json_path)


def _save_customers(customers: list, product_name: str, search_plan: dict) -> None:
    """保存客户数据到 data/customers.json（增量累积，不覆盖后续阶段字段）"""
    # 读取现有客户（按 customer_id 建立索引）
    existing_customers: list[dict] = []
    if os.path.exists(CUSTOMERS_JSON):
        try:
            with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
                existing_data = json.load(f)
            existing_customers = existing_data.get("customers", []) or []
        except Exception:
            pass

    # 为现有客户补 customer_id
    for c in existing_customers:
        _ensure_customer_id(c)

    by_id: dict[str, dict] = {}
    for c in existing_customers:
        if isinstance(c, dict) and c.get("customer_id"):
            by_id[c["customer_id"]] = c

    # crawler 负责的字段白名单（只更新这些，不覆盖后续阶段字段）
    CRAWLER_FIELDS = {
        "company_name", "country", "website", "email",
        "requirement", "industry", "source", "crawl_time",
        "priority", "filter_reason", "business_type", "name_type",
        "email_source",
    }

    # 新客户生成 customer_id 并按字段白名单合并
    for c in customers:
        _ensure_customer_id(c)
        cid = c.get("customer_id")
        if not cid:
            continue

        if cid not in by_id:
            # 新客户：整条加入
            by_id[cid] = dict(c)
        else:
            # 已有客户：只更新 crawler 负责的字段，保留后续阶段字段
            target = by_id[cid]
            for k in CRAWLER_FIELDS:
                if k in c:
                    target[k] = c[k]

    merged = list(by_id.values())

    # 写入 meta
    output_meta = {
        "total": len(merged),
        "stages": {
            "crawled": {
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                "product_name": product_name,
                "product_id": search_plan.get("product_id", ""),
                "keywords_used": search_plan.get("keywords", []),
            }
        }
    }

    _atomic_save_customers(
        customers=merged,
        meta=output_meta,
        customers_json_path=CUSTOMERS_JSON,
    )


def get_customers() -> list:
    """读取已保存的客户列表。

    Returns:
        客户列表，文件不存在或解析失败返回空列表。
    """
    if not os.path.exists(CUSTOMERS_JSON):
        return []
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("customers", [])
    except Exception:
        return []


def _load_strategy(product_id: str = "") -> dict:
    """加载 buyer_strategy。"""
    if product_id:
        path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_buyer_strategy.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        logger.warning(f"策略不存在: {product_id}")
        return None

    if not os.path.isdir(PRODUCT_DATA_DIR):
        return None

    files = [f for f in os.listdir(PRODUCT_DATA_DIR) if f.endswith("_buyer_strategy.json")]
    if not files:
        return None
    files.sort(key=lambda f: os.path.getmtime(os.path.join(PRODUCT_DATA_DIR, f)), reverse=True)
    with open(os.path.join(PRODUCT_DATA_DIR, files[0]), "r", encoding="utf-8") as f:
        return json.load(f)


def _save_simple(customers: list, product_name: str, strategy: dict) -> None:
    """保存客户数据到 data/customers.json（按批次增量累积）。"""
    batch_id = time.strftime("%Y%m%d_%H%M")
    batch_time = time.strftime("%Y-%m-%d %H:%M:%S")

    # 为每个客户打上批次标签
    for c in customers:
        _ensure_customer_id(c)
        c["batch_id"] = batch_id
        c["batch_time"] = batch_time

    # 读取现有数据
    existing = {"meta": {"total": 0, "batches": []}, "customers": []}
    if os.path.exists(CUSTOMERS_JSON):
        try:
            with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            pass

    existing_customers = existing.get("customers", []) or []
    existing_batches = existing.get("meta", {}).get("batches", []) or []

    # 新批次信息
    grades = {}
    for c in customers:
        g = c.get("candidate_grade", "D")
        grades[g] = grades.get(g, 0) + 1

    new_batch = {
        "batch_id": batch_id,
        "time": batch_time,
        "product_name": product_name,
        "customer_count": len(customers),
        "grade_summary": grades,
    }

    # 合并客户（按 customer_id 去重）
    by_id = {}
    for c in existing_customers:
        if isinstance(c, dict) and c.get("customer_id"):
            by_id[c["customer_id"]] = c
    for c in customers:
        cid = c.get("customer_id")
        if cid:
            if cid in by_id:
                by_id[cid].update(c)
            else:
                by_id[cid] = c

    # 更新已有批次或追加新批次
    batch_exists = False
    for i, b in enumerate(existing_batches):
        if b["batch_id"] == batch_id:
            existing_batches[i] = new_batch
            batch_exists = True
            break
    if not batch_exists:
        existing_batches.insert(0, new_batch)  # 最新的在最前面

    merged = list(by_id.values())
    payload = {
        "meta": {
            "total": len(merged),
            "last_run": batch_time,
            "product_name": product_name,
            "batches": existing_batches,
        },
        "customers": merged,
    }

    with open(CUSTOMERS_JSON, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    logger.info(f"批次 {batch_id}: 保存 {len(customers)} 条客户, 累计 {len(merged)} 条")


def get_batches() -> list:
    """获取批次列表。"""
    if not os.path.exists(CUSTOMERS_JSON):
        return []
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("meta", {}).get("batches", [])
    except Exception:
        return []


def delete_batch(batch_id: str) -> bool:
    """删除指定批次的所有客户。

    Returns:
        True 表示删除成功，False 表示未找到。
    """
    if not os.path.exists(CUSTOMERS_JSON):
        return False
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return False

    customers = data.get("customers", [])
    batches = data.get("meta", {}).get("batches", [])

    # 找出删除的批次
    batch_to_delete = None
    for b in batches:
        if b["batch_id"] == batch_id:
            batch_to_delete = b
            break
    if not batch_to_delete:
        return False

    # 删除该批次客户
    before = len(customers)
    customers = [c for c in customers if c.get("batch_id") != batch_id]
    removed = before - len(customers)

    # 删除批次记录
    batches = [b for b in batches if b["batch_id"] != batch_id]

    data["customers"] = customers
    data["meta"]["batches"] = batches
    data["meta"]["total"] = len(customers)

    with open(CUSTOMERS_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    logger.info(f"删除批次 {batch_id}: 移除 {removed} 条客户")
    return True


# ── 搜索词评分过滤 ────────────────────────────────────────────

# 高价值词（+30 分）：项目/采购信号
_HIGH_VALUE_KEYWORDS = [
    "project", "expansion", "factory", "plant", "production line",
    "manufacturer", "supplier", "distributor", "importer", "contractor",
    "maintenance", "replacement", "tender", "rfq", "wholesaler",
    "fabrication", "installation", "engineering",
    "import", "agent", "wholesale", "procurement",
]

# 普通价值词（+15 分）：行业/产品相关
_MEDIUM_KEYWORDS = [
    "automotive", "pharmaceutical", "semiconductor", "hvac",
    "industrial", "paint", "booth", "coating", "filtration",
    "dust", "collector", "hepa", "cleanroom", "ventilation",
    "chemical", "mining", "cement", "power", "food",
    "oil", "gas", "manufacturing", "processing",
    "baghouse", "hospital", "gmp", "paint shop", "spray booth",
    "electronics", "pollution", "abatement",
]

# 基础词（+5 分）：通用描述
_BASIC_KEYWORDS = [
    "filter", "air", "media", "system", "equipment", "parts",
    "material", "bag", "cartridge", "cloth", "fabric", "mesh",
    "screen", "purification", "treatment",
]

# 扣分词（-20 分）：泛词/垃圾词
_PENALTY_KEYWORDS = [
    "company", "companies", "limited", "ltd", "corp", "inc", "group",
    "cheap", "free", "pdf", "manual", "definition", "wiki",
    "job", "career", "news", "blog", "article", "review",
    "home", "residential",
]

# 同行降权词（-30 分）：搜索到同行供应商
_COMPETITOR_KEYWORDS = [
    "filter manufacturer", "air filter manufacturer", "filter producer",
    "filtration company", "filter factory", "filter maker",
    "filtration manufacturer", "filter supplier",
]

# 地区词（+10 分）
_AREA_KEYWORDS = [
    "vietnam", "thailand", "indonesia", "malaysia", "philippines",
    "singapore", "myanmar", "cambodia", "laos", "india",
    "china", "japan", "korea", "taiwan", "bangladesh",
    "pakistan", "sri lanka", "nepal", "middle east", "uae",
    "saudi", "qatar", "oman", "kuwait", "bahrain",
    "turkey", "egypt", "iran", "iraq", "africa",
    "nigeria", "kenya", "south africa", "ethiopia", "ghana",
    "morocco", "algeria", "tunisia", "europe", "germany",
    "uk", "france", "italy", "spain", "netherlands",
    "poland", "russia", "ukraine", "america", "usa",
    "canada", "mexico", "brazil", "argentina", "chile",
    "colombia", "peru", "australia", "new zealand",
    # 越南主要城市
    "hanoi", "ha noi", "ho chi minh", "saigon", "haiphong", "hai phong",
    "danang", "da nang", "bac ninh", "dong nai", "binh duong",
    "vung tau", "long an", "can tho", "hue", "quang ninh",
]


def _query_score(query: str) -> int:
    """对搜索词进行质量评分。

    评分规则：
      - 高价值词（项目/采购信号）+30
      - 普通价值词（行业/产品）+15
      - 基础词 +5
      - 扣分词 -20
      - 地区词 +10
      - 低于 60 分跳过，不消耗 API

    Args:
        query: 搜索关键词（英文）

    Returns:
        0-100 的评分
    """
    q = query.lower()

    score = 0

    # 高价值词（累加，最多 +60）
    high_count = 0
    for kw in _HIGH_VALUE_KEYWORDS:
        if kw in q:
            high_count += 1
    score += min(high_count * 30, 60)

    # 普通价值词（累加，最多 +30）
    med_count = 0
    for kw in _MEDIUM_KEYWORDS:
        if kw in q:
            med_count += 1
    score += min(med_count * 15, 30)

    # 基础词（累加，最多 +15）
    basic_count = 0
    for kw in _BASIC_KEYWORDS:
        if kw in q:
            basic_count += 1
    score += min(basic_count * 5, 15)

    # 扣分词（累加，最多 -40）
    penalty_count = 0
    for kw in _PENALTY_KEYWORDS:
        if kw in q:
            penalty_count += 1
    score -= min(penalty_count * 20, 40)

    # 同行降权词（累加，最多 -60）
    comp_count = 0
    for kw in _COMPETITOR_KEYWORDS:
        if kw in q:
            comp_count += 1
    score -= min(comp_count * 30, 60)

    # 地区词
    for kw in _AREA_KEYWORDS:
        if kw in q:
            score += 10
            break

    return max(score, 0)  # 最低 0 分