# 产品信息管理模块
# 支持 Excel 导入、手动录入、AI 搜索策略生成、多套产品档案切换

import json
import logging
import os
import re
from typing import Any, Dict, List, Optional

import pandas as pd

from config import API_CONFIG
from translator import ai_chat, translate_to_english

logger = logging.getLogger(__name__)

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
PRODUCTS_JSON = os.path.join(DATA_DIR, "products.json")
SEARCH_PLAN_PREFIX = "search_plan"  # 生成 {product_id}_search_plan.json

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PRODUCT_DATA_DIR, exist_ok=True)


# ── 内部工具 ──────────────────────────────────────────────────


def _load_products_db() -> dict:
    """加载整个 products.json（产品库 + 当前激活 ID）。"""
    if not os.path.exists(PRODUCTS_JSON):
        return {"products": {}, "active_product_id": None}
    with open(PRODUCTS_JSON, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_products_db(db: dict) -> None:
    """持久化 products.json。"""
    with open(PRODUCTS_JSON, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)


def _next_product_id(db: dict) -> str:
    """自增生成 product_id，格式 p001 / p002 …"""
    existing = set(db.get("products", {}).keys())
    n = 1
    while f"p{n:03d}" in existing:
        n += 1
    return f"p{n:03d}"


# ── 公开接口 ──────────────────────────────────────────────────


def load_excel(file_path: str) -> Optional[dict]:
    """读取 Excel 文件，支持新版 6 个 Sheet 模板。

    Sheet 1: 产品信息 — 产品列表
    Sheet 2: 供应能力 — 工厂供应能力（MOQ、交期、认证、产能等）
    Sheet 3: 目标客户画像 — 谁需要、为什么买、痛点
    Sheet 4: 采购信号库 — 采购信号类型、搜索词、优先级
    Sheet 5: 排除规则 — 搜索排除规则
    Sheet 6: 输出结果 — 参考格式（不读取）

    也兼容旧版 4 Sheet 格式。

    Returns:
        {
            "products": [{...产品信息...}],
            "total": N,
            "supply_capability": {...供应能力...},
            "customer_profile": {...客户画像...},
            "signal_library": [{...采购信号...}],
            "block_rules": {...排除规则...},
        }
        失败返回 None。
    """
    if not os.path.exists(file_path):
        logger.error(f"load_excel: 文件不存在 {file_path}")
        return None

    try:
        xls = pd.ExcelFile(file_path, engine="openpyxl")
    except Exception as e:
        logger.error(f"load_excel: 读取 Excel 失败 {e}")
        return None

    sheet_names = xls.sheet_names
    result = {
        "products": [], "total": 0,
        "supply_capability": {},
        "customer_profile": {},
        "signal_library": [],
        "block_rules": {},
    }

    # ── Sheet 1: 产品信息 ─────────────────────────────────────
    if sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet_names[0])
        if not df.empty:
            df = df.dropna(how="all")
            df = df[~df.iloc[:, 0].astype(str).str.startswith("说明", na=False)]

        if not df.empty:
            column_map = {
                "产品名称": "product_name",
                "英文名称": "english_name",
                "产品类别": "category",
                "型号/牌号": "model",
                "HS Code": "hs_code",
                "主要材料": "material",
                "应用领域": "application",
                "产品描述": "description",
                "主要参数": "specifications",
                "认证": "certification",
                "优势": "advantage",
            }
            df_renamed = df.rename(columns=column_map)
            col_mapping_lower = {c: c.lower() for c in df_renamed.columns}
            df_renamed = df_renamed.rename(columns=col_mapping_lower)

            records = df_renamed.to_dict(orient="records")
            cleaned = []
            for rec in records:
                item = {k: v if pd.notna(v) else "" for k, v in rec.items()}
                if item.get("product_name"):
                    cleaned.append(item)

            result["products"] = cleaned
            result["total"] = len(cleaned)

    # ── Sheet 2: 供应能力（新版）/ 销售定位（旧版兼容） ──────
    if len(sheet_names) > 1:
        df2 = pd.read_excel(xls, sheet_name=sheet_names[1])
        if not df2.empty:
            df2 = df2.dropna(how="all")
            df2 = df2[~df2.iloc[:, 0].astype(str).str.startswith("说明", na=False)]
        if not df2.empty:
            row = df2.iloc[0].to_dict()

            # 先尝试新版字段名（供应能力）
            supply_map = {
                "月产能": "monthly_capacity",
                "最小订单量": "moq",
                "交货周期": "delivery_time",
                "认证": "certification",
                "出口经验": "export_experience",
                "包装方式": "packaging",
                "付款方式": "payment_terms",
                "价格优势": "price_advantage",
                "质量优势": "quality_advantage",
            }
            # 再尝试旧版字段名（销售定位）
            sales_map = {
                "目标市场": "target_market",
                "已有客户国家": "existing_countries",
                "希望开发国家": "target_countries",
                "客户类型": "customer_type",
                "价格定位": "price_position",
                "贸易方式": "trade_term",
                "MOQ": "moq",
                "月供应能力": "monthly_capacity",
            }

            supply_data = {}
            for cn, en in supply_map.items():
                if cn in row and pd.notna(row[cn]):
                    supply_data[en] = str(row[cn]).strip()
            # 如果新版字段没读到，尝试旧版
            if not supply_data:
                for cn, en in sales_map.items():
                    if cn in row and pd.notna(row[cn]):
                        supply_data[en] = str(row[cn]).strip()

            result["supply_capability"] = supply_data

    # ── Sheet 3: 目标客户画像（新版）/ 已有客户经验（旧版兼容） ──
    if len(sheet_names) > 2:
        df3 = pd.read_excel(xls, sheet_name=sheet_names[2])
        if not df3.empty:
            df3 = df3.dropna(how="all")
            df3 = df3[~df3.iloc[:, 0].astype(str).str.startswith("说明", na=False)]
        if not df3.empty:
            # 尝试新版：客户画像（单行）
            row = df3.iloc[0].to_dict()
            profile_map = {
                "目标客户类型": "target_type",
                "客户规模": "size",
                "客户痛点": "pain_points",
                "为什么选我们": "why_us",
                "采购决策人": "decision_maker",
            }
            profile_data = {}
            for cn, en in profile_map.items():
                if cn in row and pd.notna(row[cn]):
                    profile_data[en] = str(row[cn]).strip()

            if profile_data:
                result["customer_profile"] = profile_data
            else:
                # 旧版：已有客户经验（多行）
                history_map = {
                    "历史客户国家": "country",
                    "客户行业": "industry",
                    "成交产品": "product",
                    "成交原因": "reason",
                    "客户类型": "customer_type",
                }
                records = df3.to_dict(orient="records")
                history = []
                for rec in records:
                    item = {}
                    for cn, en in history_map.items():
                        if cn in rec and pd.notna(rec[cn]):
                            item[en] = str(rec[cn]).strip()
                    if item.get("country") or item.get("industry"):
                        history.append(item)
                result["customer_history"] = history

    # ── Sheet 4: 采购信号库（新版）/ 禁止规则（旧版兼容） ────
    if len(sheet_names) > 3:
        df4 = pd.read_excel(xls, sheet_name=sheet_names[3])
        if not df4.empty:
            df4 = df4.dropna(how="all")
            df4 = df4[~df4.iloc[:, 0].astype(str).str.startswith("说明", na=False)]
        if not df4.empty:
            # 尝试新版：采购信号库（多行）
            signal_map = {
                "信号类型": "signal_type",
                "英文搜索词": "search_query",
                "目标行业": "target_industry",
                "优先级": "priority",
            }
            records = df4.to_dict(orient="records")
            signals = []
            for rec in records:
                item = {}
                for cn, en in signal_map.items():
                    if cn in rec and pd.notna(rec[cn]):
                        item[en] = str(rec[cn]).strip()
                if item.get("signal_type") or item.get("search_query"):
                    signals.append(item)

            if signals:
                result["signal_library"] = signals
            else:
                # 旧版：禁止规则（单行）
                block_map = {
                    "禁止客户类型": "avoid_customer_types",
                    "禁止国家": "avoid_countries",
                    "禁止关键词": "avoid_keywords",
                    "其他限制": "other_restrictions",
                }
                row = df4.iloc[0].to_dict()
                block_data = {}
                for cn, en in block_map.items():
                    if cn in row and pd.notna(row[cn]):
                        block_data[en] = str(row[cn]).strip()
                result["block_rules"] = block_data

    # ── Sheet 5: 排除规则（新版单独 Sheet） ────────────────────
    if len(sheet_names) > 4:
        df5 = pd.read_excel(xls, sheet_name=sheet_names[4])
        if not df5.empty:
            df5 = df5.dropna(how="all")
            df5 = df5[~df5.iloc[:, 0].astype(str).str.startswith("说明", na=False)]
        if not df5.empty:
            block_map = {
                "禁止客户类型": "avoid_customer_types",
                "禁止国家": "avoid_countries",
                "禁止关键词": "avoid_keywords",
                "其他限制": "other_restrictions",
            }
            row = df5.iloc[0].to_dict()
            block_data = {}
            for cn, en in block_map.items():
                if cn in row and pd.notna(row[cn]):
                    block_data[en] = str(row[cn]).strip()
            if block_data:
                result["block_rules"] = block_data

    logger.info(
        f"load_excel: 读取完成"
        f"\n  产品数: {result['total']}"
        f"\n  Sheet 数: {len(sheet_names)}"
    )
    return result


def find_duplicates(product_names: list[str]) -> dict[str, str]:
    """根据产品名称列表查找已存在的记录。

    Args:
        product_names: 待检查的产品名称列表

    Returns:
        {product_name: product_id, ...} 的映射，仅包含已存在的。
    """
    if not product_names:
        return {}
    db = _load_products_db()
    name_set = set(n for n in product_names if n)
    result = {}
    for pid, data in db.get("products", {}).items():
        name = data.get("product_name", "")
        if name in name_set:
            result[name] = pid
    return result


def save_product(product_data: dict, duplicate_mode: str = "save_all") -> str:
    """保存产品信息到 products.json。

    支持两类输入：
        1. 来自 load_excel() 返回的 {"products": [...]} — 批量保存
        2. 单个产品字典 — 单条保存

    Args:
        product_data: 产品数据
        duplicate_mode: 产品名已存在时的处理策略
            - "save_all": 都保存，全部新增（默认，保持原有行为）
            - "skip": 跳过重复，已有的不动
            - "overwrite": 覆盖更新，用新数据替换已有的

    Returns:
        首个（或唯一）产品的 product_id。
    """
    db = _load_products_db()
    product_id = product_data.get("product_id") or _next_product_id(db)

    def _find_existing(name: str):
        if not name:
            return None
        for pid, data in db.get("products", {}).items():
            if data.get("product_name") == name:
                return pid
        return None

    # 批量导入
    if "products" in product_data and isinstance(product_data["products"], list):
        first_id = None
        for item in product_data["products"]:
            name = item.get("product_name", "")
            existing_pid = _find_existing(name)

            if existing_pid:
                if duplicate_mode == "skip":
                    continue
                elif duplicate_mode == "overwrite":
                    item["product_id"] = existing_pid
                    db["products"][existing_pid] = item
                    if first_id is None:
                        first_id = existing_pid
                    continue
                # save_all: 继续往下走，新增一条

            pid = item.get("product_id") or _next_product_id(db)
            item["product_id"] = pid
            db["products"][pid] = item
            if first_id is None:
                first_id = pid
        product_id = first_id or product_id
    else:
        # 单条保存
        name = product_data.get("product_name", "")
        existing_pid = _find_existing(name)

        if existing_pid:
            if duplicate_mode == "skip":
                logger.info(f"save_product: 跳过重复 product_name={name}")
                return existing_pid
            elif duplicate_mode == "overwrite":
                product_data["product_id"] = existing_pid
                db["products"][existing_pid] = product_data
                _save_products_db(db)
                logger.info(f"save_product: 已覆盖 product_id={existing_pid}")
                return existing_pid
            # save_all: fall through

        product_data["product_id"] = product_id
        db["products"][product_id] = product_data

    # 自动设为当前产品（如果还没有激活的话）
    if db.get("active_product_id") is None:
        db["active_product_id"] = product_id

    _save_products_db(db)
    logger.info(f"save_product: 已保存 product_id={product_id}")
    return product_id


def generate_search_plan(product_id: str) -> Optional[dict]:
    """根据产品信息生成搜索策略（调用大模型）。

    生成的 search_plan 保存至 product_data/{product_id}_search_plan.json。

    Returns:
        search_plan 字典，失败返回 None。
    """
    db = _load_products_db()
    product = db.get("products", {}).get(product_id)
    if product is None:
        logger.error(f"generate_search_plan: product_id={product_id} 不存在")
        return None

    # 组装产品描述
    product_desc = "\n".join(
        f"{k}: {v}" for k, v in product.items() if v and k != "product_id"
    )

    # 先翻译产品名称为英文
    product_name_cn = product.get("product_name", "")
    product_name_en = product_name_cn
    if product_name_cn:
        translated = translate_to_english(product_name_cn)
        if translated:
            product_name_en = translated

    system_prompt = (
        "你是一个外贸搜索策略专家。根据用户提供的产品信息，生成一份结构化的搜索策略。"
        "只输出合法的 JSON，不要包含 markdown 代码块标记。"
    )

    user_prompt = f"""产品信息：
{product_desc}

请生成以下 JSON 结构（严格遵循格式）：
{{
  "product_id": "{product_id}",
  "product_name": "{product_name_en}",
  "keywords": ["英文关键词1", "英文关键词2", ...],
  "target_industries": ["目标行业1", "目标行业2", ...],
  "target_countries": ["US", "DE", ...],
  "hs_codes": ["HS编码1", "HS编码2", ...],
  "competitors": ["竞争对手1", "竞争对手2", ...]
}}

要求：
- keywords 至少 5 个，从不同角度描述产品（产品名、材质、工艺、用途、采购术语）
- target_industries 至少 3 个
- target_countries 至少 5 个用两位国家代码
- hs_codes 至少 2 个
- competitors 至少 3 个
"""

    llm_result = ai_chat(
        messages=[{"role": "user", "content": user_prompt}],
        system_prompt=system_prompt,
        temperature=0.3,
    )
    if llm_result is None:
        return None

    # 尝试从结果中提取 JSON（可能包含 ```json ... ``` 包裹）
    try:
        # 去掉可能的 markdown 代码块包裹
        json_str = llm_result.strip()
        if "```" in json_str:
            json_str = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
            if json_str:
                json_str = json_str.group(1)
            else:
                # fallback: 去掉所有 ``` 标记
                json_str = llm_result.replace("```json", "").replace("```", "").strip()
        search_plan = json.loads(json_str)
    except json.JSONDecodeError:
        logger.error(f"generate_search_plan: LLM 返回非 JSON, raw={llm_result[:200]}")
        return None

    # 补充必要字段
    search_plan.setdefault("product_id", product_id)
    search_plan.setdefault("product_name", product_name_en)

    # 持久化
    plan_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_{SEARCH_PLAN_PREFIX}.json")
    with open(plan_path, "w", encoding="utf-8") as f:
        json.dump(search_plan, f, ensure_ascii=False, indent=2)

    logger.info(f"generate_search_plan: 已保存 {plan_path}")
    return search_plan


def switch_product(product_id: str) -> Optional[dict]:
    """切换当前激活的产品。

    Returns:
        该产品的数据字典，如果 product_id 不存在返回 None。
    """
    db = _load_products_db()
    product = db.get("products", {}).get(product_id)
    if product is None:
        logger.error(f"switch_product: product_id={product_id} 不存在")
        return None

    db["active_product_id"] = product_id
    _save_products_db(db)
    logger.info(f"switch_product: 已切换到 product_id={product_id}")
    return product


def list_products() -> List[dict]:
    """列出所有已保存的产品档案。

    Returns:
        产品摘要列表（不含大字段），每个元素包含 product_id、product_name 等。
    """
    db = _load_products_db()
    active_id = db.get("active_product_id")
    result = []
    for pid, data in db.get("products", {}).items():
        summary = {
            "product_id": pid,
            "product_name": data.get("product_name", ""),
            "is_active": pid == active_id,
        }
        # 附带 search_plan 存在状态
        plan_path = os.path.join(
            PRODUCT_DATA_DIR, f"{pid}_{SEARCH_PLAN_PREFIX}.json"
        )
        summary["has_search_plan"] = os.path.exists(plan_path)
        result.append(summary)
    return result


def delete_product(product_id: str) -> bool:
    """删除指定产品及其 search_plan。

    Returns:
        True 表示删除成功，False 表示产品不存在。
    """
    db = _load_products_db()
    if product_id not in db.get("products", {}):
        return False

    del db["products"][product_id]

    # 如果删除的是当前激活产品，将 active 设为 None
    if db.get("active_product_id") == product_id:
        db["active_product_id"] = None

    _save_products_db(db)

    # 同时删除对应的 search_plan 文件
    plan_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_{SEARCH_PLAN_PREFIX}.json")
    if os.path.exists(plan_path):
        os.remove(plan_path)

    logger.info(f"delete_product: 已删除 product_id={product_id}")
    return True