# 客户筛选模块
# 基于规则对爬虫采集到的客户信息进行过滤，不依赖 AI

import logging
import re
import socket
import subprocess
from typing import Dict, List, Optional, Tuple

from config import FILTER_CONFIG

logger = logging.getLogger(__name__)

# 公司描述关键词 → 标签
DESC_TRADE_KEYWORDS = [
    "manufacturer", "supplier", "distributor", "dealer", "trader",
    "wholesaler", "retailer", "factory", "producer", "maker",
]

# 公司名关键词 → 贸易商标签
NAME_TRADE_KEYWORDS = [
    "trading", "import", "export", "international",
    "enterprise", "group", "limited", "ltd", "corp",
    "corporation", "inc", "gmbh", "co.", "llc",
]

# 过滤国家（竞争对手）
FILTER_COUNTRIES = {
    "china", "cn", "chinese", "india", "in", "hong kong", "hk",
}


def filter_customers(customers: List[dict]) -> List[dict]:
    """对客户数据进行规则过滤。

    过滤规则：
    1. 公司描述含 manufacturer/supplier/distributor/dealer/trader → 标记"供应商/贸易商"（低优先级）
    2. 国家为中国/印度/香港 → 过滤（竞争对手）
    3. 公司名含 Trading/Import/Export/International → 标记"贸易商"（低优先级）
    4. 没有官网 → 过滤
    5. 官网域名 MX 解析失败 → 过滤

    Args:
        customers: 客户信息列表。

    Returns:
        过滤后的客户列表，每项附加 priority 和 filter_reason 字段。
        priority: "high" / "medium" / "low"
        filter_reason: 过滤理由或保留说明
    """
    max_per_page = FILTER_CONFIG.get("max_customers_per_page", 20)

    passed: list[dict] = []

    for c in customers:
        # ── 基础检查 ──────────────────────────────────────────
        name = (c.get("company_name") or "").strip()
        if not name:
            continue

        # 去重
        if _is_duplicate_name(name, passed):
            continue

        # ── 规则 2: 国家过滤（竞争对手） ──────────────────────
        country = (c.get("country") or "").strip().lower()
        if country in FILTER_COUNTRIES:
            logger.info(f"  过滤 [竞争对手] {name}: 国家={country}")
            continue

        # ── 规则 4: 没有官网 → 过滤 ────────────────────────────
        website = (c.get("website") or "").strip()
        if not website:
            logger.info(f"  过滤 [无官网] {name}")
            continue

        # ── 规则 5: MX 解析失败 → 过滤 ────────────────────────
        domain = _extract_domain(website)
        if domain and not _check_mx(domain):
            logger.info(f"  过滤 [MX解析失败] {name}: domain={domain}")
            continue

        # ── 规则 1: 公司描述标记 ──────────────────────────────
        desc = (c.get("requirement") or c.get("description") or "").lower()
        desc_tag = _check_desc_tags(desc)

        # ── 规则 3: 公司名标记 ────────────────────────────────
        name_tag = _check_name_tags(name.lower())

        # ── 确定优先级 ────────────────────────────────────────
        priority, filter_reason = _determine_priority(desc_tag, name_tag, c)

        c["priority"] = priority
        c["filter_reason"] = filter_reason
        if desc_tag:
            c["business_type"] = desc_tag
        if name_tag:
            c["name_type"] = name_tag

        passed.append(c)

    # 高优先级在前
    priority_order = {"高": 0, "中": 1, "低": 2}
    passed.sort(key=lambda x: priority_order.get(x.get("priority", "低"), 99))

    # 截取
    result = passed[:max_per_page]

    logger.info(
        f"filter_customers: {len(customers)} → {len(passed)} (通过) → {len(result)} (输出)"
    )
    return result


# ── 内部工具 ──────────────────────────────────────────────────


def _is_duplicate_name(name: str, existing: list) -> bool:
    """同名去重。"""
    name_lower = name.lower().strip()
    for c in existing:
        if (c.get("company_name") or "").lower().strip() == name_lower:
            return True
    return False


def _check_desc_tags(desc: str) -> str:
    """检查公司描述是否含贸易相关关键词。"""
    for kw in DESC_TRADE_KEYWORDS:
        if kw in desc:
            return "供应商/贸易商"
    return ""


def _check_name_tags(name: str) -> str:
    """检查公司名是否含贸易相关关键词。"""
    for kw in NAME_TRADE_KEYWORDS:
        if kw in name:
            return "贸易商"
    return ""


def _determine_priority(desc_tag: str, name_tag: str, customer: dict) -> Tuple[str, str]:
    """确定优先级和过滤理由。

    priority 规则：
    - 高: 有明确采购需求 + 有邮箱 + 有官网，且未被标记为贸易商
    - 中: 有官网 + 有邮箱，但无明确采购需求
    - 低: 被标记为贸易商/供应商，或信息不完整
    """
    has_email = bool(customer.get("email"))
    has_requirement = bool(customer.get("requirement"))
    has_website = bool(customer.get("website"))
    is_trade = bool(desc_tag) or bool(name_tag)

    reasons = []

    if is_trade:
        if desc_tag:
            reasons.append(desc_tag)
        if name_tag:
            reasons.append(name_tag)

    if not has_email:
        reasons.append("无邮箱")
    if not has_requirement:
        reasons.append("无采购需求")

    if is_trade or (not has_email and not has_requirement):
        priority = "低"
        if not reasons:
            reasons.append("信息不完整")
    elif has_email and has_requirement and has_website:
        priority = "高"
        reasons.append("信息完整")
    else:
        priority = "中"
        if not reasons:
            reasons.append("基本信息完整")

    return priority, "; ".join(reasons)


def _extract_domain(website: str) -> str:
    """从 URL 中提取域名。"""
    if not website:
        return ""
    website = website.strip().lower()
    # 去掉协议
    if "://" in website:
        website = website.split("://")[1]
    # 去掉路径
    website = website.split("/")[0]
    # 去掉端口
    website = website.split(":")[0]
    # 去掉 www. 前缀
    if website.startswith("www."):
        website = website[4:]
    return website


def _check_mx(domain: str) -> bool:
    """检查域名是否有 MX 记录（使用系统 nslookup 命令，带超时保护）。

    Returns:
        True 表示域名可解析，False 表示失败。
    """
    if not domain:
        return False

    # 方法 1: 尝试 nslookup MX 查询
    try:
        result = subprocess.run(
            ["nslookup", "-type=mx", domain],
            capture_output=True,
            text=True,
            timeout=5,  # 5 秒超时，避免卡住
        )
        if "mail exchanger" in result.stdout.lower():
            return True
    except subprocess.TimeoutExpired:
        logger.debug(f"nslookup MX 超时: {domain}")
    except Exception:
        pass

    # 方法 2: 快速 A 记录检查
    try:
        socket.setdefaulttimeout(5)
        socket.getaddrinfo(domain, 80, socket.AF_INET, socket.SOCK_STREAM)
        return True
    except Exception:
        return False