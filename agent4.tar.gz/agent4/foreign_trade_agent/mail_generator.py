# 邮件生成模块
# 针对匹配通过的客户，使用 AI 生成个性化开发信

import concurrent.futures
import json
import logging
import os
import time
from typing import List, Optional

from crawler import _atomic_save_customers, _ensure_customer_id, load_search_plan, format_product_info
from translator import ai_chat

logger = logging.getLogger(__name__)

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
MAIL_TEMPLATE_DIR = os.path.join(BASE_DIR, "mail_template")
CUSTOMERS_JSON = os.path.join(DATA_DIR, "customers.json")

os.makedirs(MAIL_TEMPLATE_DIR, exist_ok=True)


def generate_all(product_id: str = "") -> int:
    """为所有匹配达标的客户生成开发信。

    流程：
    1. 读取 product_data/ 下的 search_plan.json
    2. 读取 data/customers.json 中的客户列表
    3. 仅对 match_status="达标" 且尚未生成邮件的客户生成
    4. 生成简短版和详细版两套开发信
    5. 结果写回 data/customers.json

    Args:
        product_id: 产品 ID，可选。

    Returns:
        生成邮件的客户数量。
    """
    # ── 1. 读取 search_plan ─────────────────────────────────
    search_plan = load_search_plan(product_id)
    if search_plan is None:
        logger.error("generate_all: 未找到 search_plan")
        return 0

    product_name = search_plan.get("product_name", "未知产品")
    product_info = format_product_info(search_plan)

    # ── 2. 读取客户列表 ─────────────────────────────────────
    customers = _load_customers()
    if not customers:
        logger.warning("generate_all: 客户列表为空")
        return 0

    # ── 3. 读取邮件模板 ─────────────────────────────────────
    template = _load_template()

    # ── 4. 并行生成 ─────────────────────────────────────────
    generated_count = 0
    to_generate = [c for c in customers if c.get("match_status") == "达标"
                   and ("mail_short" not in c or "mail_detailed" not in c)]
    already_done = [c for c in customers if c.get("match_status") == "达标"
                    and "mail_short" in c and "mail_detailed" in c]

    for c in already_done:
        generated_count += 1
        logger.info(f"  [{c.get('company_name', '')}] 已生成，跳过")

    if to_generate:
        def _gen_one(c):
            short = _generate_short_email(c, product_name, product_info, template)
            detailed = _generate_detailed_email(c, product_name, product_info, template)
            return c, short, detailed

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(_gen_one, c) for c in to_generate]
            for future in concurrent.futures.as_completed(futures):
                try:
                    c, short, detailed = future.result()
                    if short:
                        c["mail_short"] = short
                    if detailed:
                        c["mail_detailed"] = detailed
                    if short or detailed:
                        generated_count += 1
                    logger.info(f"  [{c.get('company_name', '')}] 开发信已生成 (短={'✓' if short else '✗'}, 详={'✓' if detailed else '✗'})")
                except Exception as e:
                    logger.error(f"  生成异常: {e}")

    # ── 5. 写回 ─────────────────────────────────────────────
    _save_customers(customers)

    logger.info(f"=== 邮件生成完成: {generated_count} 家 ===")
    return generated_count


# ── 内部函数 ──────────────────────────────────────────────────


def load_search_plan(product_id: str = "") -> Optional[dict]:
    """加载 search_plan.json。"""
    if product_id:
        plan_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_search_plan.json")
        if os.path.exists(plan_path):
            with open(plan_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    if not os.path.isdir(PRODUCT_DATA_DIR):
        return None

    plan_files = [f for f in os.listdir(PRODUCT_DATA_DIR) if f.endswith("_search_plan.json")]
    if not plan_files:
        return None

    plan_files.sort(
        key=lambda f: os.path.getmtime(os.path.join(PRODUCT_DATA_DIR, f)),
        reverse=True,
    )
    latest = os.path.join(PRODUCT_DATA_DIR, plan_files[0])
    with open(latest, "r", encoding="utf-8") as f:
        return json.load(f)


def format_product_info(plan: dict) -> str:
    """将 search_plan 格式化为产品描述文本。"""
    parts = [
        f"产品名称: {plan.get('product_name', '')}",
        f"关键词: {', '.join(plan.get('keywords', []))}",
        f"目标行业: {', '.join(plan.get('target_industries', []))}",
        f"HS编码: {', '.join(plan.get('hs_codes', []))}",
    ]
    return "\n".join(parts)


def _load_customers() -> list:
    """从 data/customers.json 加载客户列表。"""
    if not os.path.exists(CUSTOMERS_JSON):
        return []
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("customers", [])
    except Exception as e:
        logger.error(f"读取 customers.json 失败: {e}")
        return []


def _save_customers(customers: list) -> None:
    """按 customer_id 增量合并写回，只更新 mail_short/mail_detailed"""
    # 读取现有数据
    existing = {"meta": {}, "customers": []}
    if os.path.exists(CUSTOMERS_JSON):
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            existing = json.load(f)

    existing_customers = existing.get("customers", []) or []
    by_id = {}

    for c in existing_customers:
        if isinstance(c, dict):
            _ensure_customer_id(c)
            cid = c.get("customer_id")
            if cid:
                by_id[cid] = c

    # 增量更新邮件生成结果
    for c in customers:
        if not isinstance(c, dict):
            continue
        _ensure_customer_id(c)
        cid = c.get("customer_id")
        if not cid:
            continue

        if cid not in by_id:
            by_id[cid] = c
        else:
            target = by_id[cid]
            for k in ["mail_short", "mail_detailed"]:
                if k in c:
                    target[k] = c[k]

    updated_customers = list(by_id.values())

    # meta 只写 mail_generated stage，不覆盖其他阶段
    meta_update = {
        "total": len(updated_customers),
        "stages": {
            "mail_generated": {
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
        }
    }

    _atomic_save_customers(
        customers=updated_customers,
        meta=meta_update,
        customers_json_path=CUSTOMERS_JSON,
    )


def _load_template() -> str:
    """从 mail_template/ 目录读取邮件模板。

    优先读取 custom_template.txt，如果不存在则返回硬编码的默认模板。
    本函数只读，不写文件。
    """
    # 用户自定义模板
    custom_path = os.path.join(MAIL_TEMPLATE_DIR, "custom_template.txt")
    if os.path.exists(custom_path):
        with open(custom_path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if content:
                return content

    # 默认模板（硬编码，不再自动创建文件）
    default_template = """Subject: {subject}

Dear {company_name},

{body}

Best regards,
{company_signature}"""

    return default_template


def _generate_short_email(
    customer: dict, product_name: str, product_info: str, template: str
) -> Optional[str]:
    """生成简短版开发信（3-4 句话，适合初次联系）。"""
    company_name = customer.get("company_name", "尊敬的客户")
    requirement = customer.get("requirement", "")

    system_prompt = (
        "你是一个专业的外贸业务员。根据客户信息和产品信息，"
        "生成一封简洁的英文开发信。\n\n"
        "要求：\n"
        "1. 3-4 句话，适合初次联系\n"
        "2. 包含标题（Subject）和正文\n"
        "3. 语气专业、礼貌、有吸引力\n"
        "4. 突出产品与客户需求的关联\n"
        "5. 不要过度承诺，不要写虚假信息\n"
        "6. 用 {{company_name}} 代替客户公司名，用 {{product_name}} 代替产品名\n"
        "7. 只输出邮件内容，不要附加解释"
    )

    user_prompt = (
        f"产品信息: {product_name}\n"
        f"客户公司: {company_name}\n"
        f"客户采购需求: {requirement}\n\n"
        "请生成简短版开发信（3-4 句话），格式：\n"
        "Subject: ...\n\n"
        "正文..."
    )

    try:
        result = ai_chat(
            messages=[{"role": "user", "content": user_prompt}],
            system_prompt=system_prompt,
            temperature=0.7,
        )
        return result
    except Exception as e:
        logger.error(f"生成简短开发信失败 [{company_name}]: {e}")
        return None


def _generate_detailed_email(
    customer: dict, product_name: str, product_info: str, template: str
) -> Optional[str]:
    """生成详细版开发信（含产品参数、工厂优势、认证、MOQ）。"""
    company_name = customer.get("company_name", "尊敬的客户")
    requirement = customer.get("requirement", "")

    system_prompt = (
        "你是一个专业的外贸业务员。根据客户信息和产品信息，"
        "生成一封详细的英文开发信。\n\n"
        "要求：\n"
        "1. 包含标题（Subject）和正文\n"
        "2. 包含产品参数、工厂优势、认证资质、MOQ等信息\n"
        "3. 语气专业、有说服力\n"
        "4. 突出产品与客户需求的匹配点\n"
        "5. 不要过度承诺，不要写虚假信息\n"
        "6. 用 {{company_name}} 代替客户公司名，用 {{product_name}} 代替产品名\n"
        "7. 不要编造具体数据（如价格、认证编号），使用占位符如 [XX认证] 或留空\n"
        "8. 只输出邮件内容，不要附加解释"
    )

    user_prompt = (
        f"产品信息:\n{product_info}\n"
        f"客户公司: {company_name}\n"
        f"客户采购需求: {requirement}\n\n"
        "请生成详细版开发信，格式：\n"
        "Subject: ...\n\n"
        "正文（请包含以下要素）：\n"
        "- 开场问候与自我介绍\n"
        "- 产品优势与参数说明\n"
        "- 工厂优势（产能、质量管控等）\n"
        "- 认证资质（用占位符）\n"
        "- MOQ 与包装信息\n"
        "- 结尾邀请与联系方式"
    )

    try:
        result = ai_chat(
            messages=[{"role": "user", "content": user_prompt}],
            system_prompt=system_prompt,
            temperature=0.7,
        )
        return result
    except Exception as e:
        logger.error(f"生成详细开发信失败 [{company_name}]: {e}")
        return None