# 产品匹配模块
# AI 语义匹配：将客户采购需求与产品信息进行匹配打分

import concurrent.futures
import json
import logging
import os
import time
from typing import List, Optional

from config import FILTER_CONFIG

from crawler import _atomic_save_customers, _ensure_customer_id, load_search_plan, format_product_info
from translator import ai_chat

logger = logging.getLogger(__name__)

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
CUSTOMERS_JSON = os.path.join(DATA_DIR, "customers.json")

os.makedirs(DATA_DIR, exist_ok=True)


def match_all(product_id: str = "") -> int:
    """对客户清单中的每家公司进行 AI 匹配打分。

    流程：
    1. 读取 product_data/ 下的 search_plan.json
    2. 读取 data/customers.json 中的客户列表
    3. 逐一调用 AI 判断匹配度（0-10）
    4. 低于阈值的标记为"不达标"
    5. 结果写回 data/customers.json

    Args:
        product_id: 产品 ID，可选。为空时自动查找最新 search_plan。

    Returns:
        成功匹配的客户数量。
    """
    # ── 1. 读取 search_plan ─────────────────────────────────
    search_plan = load_search_plan(product_id)
    if search_plan is None:
        logger.error("match_all: 未找到 search_plan")
        return 0

    product_name = search_plan.get("product_name", "未知产品")
    product_info = format_product_info(search_plan)

    # ── 2. 读取 customers ──────────────────────────────────
    customers = _load_customers()
    if not customers:
        logger.warning("match_all: 客户列表为空")
        return 0

    threshold = FILTER_CONFIG.get("match_threshold", 6)
    matched_count = 0

    logger.info(
        f"=== 开始匹配 ==="
        f"\n  产品: {product_name}"
        f"\n  客户数: {len(customers)}"
        f"\n  阈值: {threshold}"
    )

    # ── 3. 并行匹配 ─────────────────────────────────────────
    to_match = []
    for c in customers:
        if "score" in c and "match_reason" in c:
            company_name = c.get("company_name", "未知公司")
            logger.info(f"  [{company_name}] 已匹配，跳过 (score={c['score']})")
            if c.get("score", 0) >= threshold:
                matched_count += 1
        else:
            to_match.append(c)

    if to_match:
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            future_map = {
                pool.submit(_match_single, c, product_name, product_info): c
                for c in to_match
            }
            for future in concurrent.futures.as_completed(future_map):
                c = future_map[future]
                company_name = c.get("company_name", "未知公司")
                try:
                    score, reason = future.result()
                except Exception as e:
                    logger.error(f"  [{company_name}] 匹配异常: {e}")
                    score, reason = 5, "匹配异常，默认中等匹配"

                c["score"] = score
                c["match_reason"] = reason
                if score >= threshold:
                    c["match_status"] = "达标"
                    matched_count += 1
                else:
                    c["match_status"] = "不达标"
                logger.info(f"  [{company_name}] score={score}/10 → {c['match_status']}")

    # ── 4. 写回 ─────────────────────────────────────────────
    _save_customers(customers)

    # 统计
    passed_count = sum(1 for c in customers if c.get("match_status") == "达标")
    failed_count = sum(1 for c in customers if c.get("match_status") == "不达标")
    unscored_count = sum(1 for c in customers if "score" not in c)

    logger.info(
        f"=== 匹配完成 ==="
        f"\n  达标: {passed_count}"
        f"\n  不达标: {failed_count}"
        f"\n  未匹配: {unscored_count}"
    )
    return matched_count


# ── 内部函数 ──────────────────────────────────────────────────


def load_search_plan(product_id: str = "") -> Optional[dict]:
    """加载 search_plan.json。"""
    if product_id:
        plan_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_search_plan.json")
        if os.path.exists(plan_path):
            with open(plan_path, "r", encoding="utf-8") as f:
                return json.load(f)
        logger.warning(f"search_plan 不存在: {plan_path}")
        return None

    if not os.path.isdir(PRODUCT_DATA_DIR):
        return None

    plan_files = [f for f in os.listdir(PRODUCT_DATA_DIR) if f.endswith("_search_plan.json")]
    if not plan_files:
        return None

    plan_files.sort(
        key=lambda f: os.path.getmtime(os.path.join(PRODUCT_DATA_DIR, f)),
        reverse=True,
    )
    latest = os.path.join(PRODUCT_DATA_DIR, plan_files[0])
    with open(latest, "r", encoding="utf-8") as f:
        return json.load(f)


def format_product_info(plan: dict) -> str:
    """将 search_plan 格式化为产品描述文本。"""
    parts = [
        f"产品名称: {plan.get('product_name', '')}",
        f"关键词: {', '.join(plan.get('keywords', []))}",
        f"目标行业: {', '.join(plan.get('target_industries', []))}",
        f"目标国家: {', '.join(plan.get('target_countries', []))}",
        f"HS编码: {', '.join(plan.get('hs_codes', []))}",
        f"主要竞争对手: {', '.join(plan.get('competitors', []))}",
    ]
    return "\n".join(parts)


def _load_customers() -> list:
    """从 data/customers.json 加载客户列表。"""
    if not os.path.exists(CUSTOMERS_JSON):
        return []
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("customers", [])
    except Exception as e:
        logger.error(f"读取 customers.json 失败: {e}")
        return []


def _save_customers(customers: list) -> None:
    """按 customer_id 增量合并写回，只更新 score/match_reason/match_status"""
    # 读取现有数据
    existing = {"meta": {}, "customers": []}
    if os.path.exists(CUSTOMERS_JSON):
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            existing = json.load(f)

    existing_customers = existing.get("customers", []) or []
    by_id = {}

    for c in existing_customers:
        if isinstance(c, dict):
            _ensure_customer_id(c)
            cid = c.get("customer_id")
            if cid:
                by_id[cid] = c

    # 增量更新本阶段计算的客户
    for c in customers:
        if not isinstance(c, dict):
            continue
        _ensure_customer_id(c)
        cid = c.get("customer_id")
        if not cid:
            continue

        if cid not in by_id:
            by_id[cid] = c
        else:
            target = by_id[cid]
            for k in ["score", "match_reason", "match_status"]:
                if k in c:
                    target[k] = c[k]

    updated_customers = list(by_id.values())

    # meta 只写 matched stage，不覆盖其他阶段
    meta_update = {
        "total": len(updated_customers),
        "stages": {
            "matched": {
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                "threshold": FILTER_CONFIG.get("match_threshold", 6),
            }
        }
    }

    _atomic_save_customers(
        customers=updated_customers,
        meta=meta_update,
        customers_json_path=CUSTOMERS_JSON,
    )


def _match_single(customer: dict, product_name: str, product_info: str) -> tuple:
    """对单个客户进行 AI 匹配打分。

    Returns:
        (score: int, reason: str) 元组。
        score 范围 0-10，reason 为匹配理由。
    """
    company_name = customer.get("company_name", "")
    requirement = customer.get("requirement", "")
    industry = customer.get("industry", "")
    country = customer.get("country", "")

    # 构建客户信息
    customer_info = (
        f"公司名称: {company_name}\n"
        f"国家: {country}\n"
        f"行业: {industry}\n"
        f"采购需求: {requirement}"
    )

    system_prompt = (
        "你是一个外贸客户匹配专家。根据产品信息和客户信息，"
        "判断该客户的采购需求与我们的产品的匹配程度。\n\n"
        "评分规则：\n"
        "10分 = 高度匹配，客户正在采购完全相同的产品\n"
        "7-9分 = 强匹配，客户需求与产品高度相关\n"
        "4-6分 = 中等匹配，有一定关联但需要进一步确认\n"
        "1-3分 = 弱匹配，客户需求与产品关联度低\n"
        "0分 = 完全不匹配\n\n"
        "请以 JSON 格式回复，不要加 markdown 代码块标记：\n"
        '{"score": 分数, "reason": "匹配理由（中英文均可，简要说明为什么给这个分数）"}'
    )

    user_prompt = f"【产品信息】\n{product_info}\n\n【客户信息】\n{customer_info}"

    try:
        result = ai_chat(
            messages=[{"role": "user", "content": user_prompt}],
            system_prompt=system_prompt,
            temperature=0.3,
        )
        if result is None:
            logger.warning(f"  [{company_name}] AI 调用失败，设为默认 5 分")
            return 5, "AI 匹配失败，默认中等匹配"

        # 解析 JSON
        result = result.strip()
        if "```" in result:
            import re
            m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", result, re.DOTALL)
            if m:
                result = m.group(1)
            else:
                result = result.replace("```json", "").replace("```", "").strip()

        data = json.loads(result)
        score = int(data.get("score", 5))
        reason = data.get("reason", "AI 匹配结果")

        # 确保 score 在 0-10 范围内
        score = max(0, min(10, score))
        return score, reason

    except Exception as e:
        logger.warning(f"  [{company_name}] 匹配解析失败: {e}")
        return 5, "匹配解析失败，默认中等匹配"