# 邮件发送模块
# 封装 SMTP 发送功能，提供单封邮件发送接口

import logging
import os
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Optional

from config import SMTP_CONFIG

# 总开关：防止误发真实邮件（环境变量 DRY_RUN_MAIL=true 时不连接 SMTP）
DRY_RUN_MAIL = os.getenv("DRY_RUN_MAIL", "true").lower() == "true"

logger = logging.getLogger(__name__)


def send_email(
    to_email: str,
    subject: str,
    body: str,
    cc: Optional[List[str]] = None,
    attachments: Optional[List[str]] = None,
) -> bool:
    """发送一封邮件。

    Args:
        to_email: 收件人邮箱。
        subject: 邮件主题。
        body: 邮件正文（纯文本）。
        cc: 抄送列表，可选。
        attachments: 附件文件路径列表，可选。

    Returns:
        True 表示发送成功，False 表示失败。
    """
    # 总开关：DRY_RUN 模式下不连接 SMTP
    if DRY_RUN_MAIL:
        logger.info(f"[DRY_RUN] 模拟发送到 {to_email}, subject={subject}")
        return True

    cfg = SMTP_CONFIG.get("default", {})
    smtp_server = cfg.get("smtp_server", "")
    port = cfg.get("port", 465)
    use_ssl = cfg.get("use_ssl", True)
    from_email = cfg.get("email", "")
    password = cfg.get("password", "")

    if not smtp_server or not from_email or not password:
        logger.warning("send_email: SMTP 配置不完整，跳过发送")
        return False

    try:
        # 构建邮件
        msg = MIMEMultipart()
        msg["From"] = from_email
        msg["To"] = to_email
        msg["Subject"] = subject
        if cc:
            msg["Cc"] = ", ".join(cc)

        msg.attach(MIMEText(body, "plain", "utf-8"))

        # 附件
        if attachments:
            for filepath in attachments:
                try:
                    with open(filepath, "rb") as f:
                        part = MIMEBase("application", "octet-stream")
                        part.set_payload(f.read())
                    encoders.encode_base64(part)
                    filename = filepath.split("/")[-1]
                    part.add_header(
                        "Content-Disposition",
                        f"attachment; filename={filename}",
                    )
                    msg.attach(part)
                except Exception as e:
                    logger.warning(f"附件添加失败 {filepath}: {e}")

        # 发送
        if use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
                server.login(from_email, password)
                server.send_message(msg)
        else:
            with smtplib.SMTP(smtp_server, port) as server:
                server.starttls()
                server.login(from_email, password)
                server.send_message(msg)

        logger.info(f"send_email: 成功发送到 {to_email}")
        return True

    except Exception as e:
        logger.error(f"send_email: 发送失败 ({to_email}): {e}")
        return False