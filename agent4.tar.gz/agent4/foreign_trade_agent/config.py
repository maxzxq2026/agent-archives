# 配置模块
# 所有配置集中管理，业务模块引用此模块获取配置
# 运行时 API 配置优先从 data/api_config.json 读取（通过 Web 界面保存）

import json
import os

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
API_CONFIG_JSON = os.path.join(_BASE_DIR, "data", "api_config.json")
SMTP_CONFIG_JSON = os.path.join(_BASE_DIR, "data", "smtp_config.json")


def _load_api_config_json() -> dict:
    """从 data/api_config.json 加载运行时 API 配置。"""
    if not os.path.isfile(API_CONFIG_JSON):
        return {}
    try:
        with open(API_CONFIG_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def _load_config_json(path: str) -> dict:
    """通用 JSON 配置文件加载。"""
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_api_config(base_url: str, api_key: str, model: str) -> dict:
    """保存 API 配置到 data/api_config.json 并更新内存中的配置。"""
    data = {"base_url": base_url, "api_key": api_key, "model": model}
    os.makedirs(os.path.dirname(API_CONFIG_JSON), exist_ok=True)
    with open(API_CONFIG_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    # 同步更新内存中的配置，当前会话立即生效
    API_CONFIG["default"]["base_url"] = base_url
    API_CONFIG["default"]["api_key"] = api_key
    API_CONFIG["default"]["model"] = model
    return data


def save_smtp_config(smtp_server: str, port: int, use_ssl: bool, email: str, password: str) -> dict:
    """保存 SMTP 配置到 data/smtp_config.json 并更新内存中的配置。"""
    data = {
        "smtp_server": smtp_server, "port": port,
        "use_ssl": use_ssl, "email": email, "password": password,
    }
    os.makedirs(os.path.dirname(SMTP_CONFIG_JSON), exist_ok=True)
    with open(SMTP_CONFIG_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    SMTP_CONFIG["default"].update(data)
    return data


# 默认 API 配置（会被 api_config.json 覆盖）
API_CONFIG = {
    "default": {
        "base_url": "",
        "api_key": "",
        "model": "",
        "vision_supported": False,
    }
}

# 运行时配置覆盖
_runtime_api = _load_api_config_json()
if _runtime_api.get("base_url"):
    API_CONFIG["default"]["base_url"] = _runtime_api["base_url"]
if _runtime_api.get("api_key"):
    API_CONFIG["default"]["api_key"] = _runtime_api["api_key"]
if _runtime_api.get("model"):
    API_CONFIG["default"]["model"] = _runtime_api["model"]

SMTP_CONFIG = {
    "default": {
        "smtp_server": "",
        "port": 465,
        "use_ssl": True,
        "email": "",
        "password": "",
    }
}

# 运行时 SMTP 配置覆盖
_runtime_smtp = _load_config_json(SMTP_CONFIG_JSON)
if _runtime_smtp.get("smtp_server"):
    SMTP_CONFIG["default"].update(_runtime_smtp)

CRAWLER_CONFIG = {
    "request_timeout": 30,
    "daily_limit": 200,
    "min_delay": 1,
    "max_delay": 4,
    "per_source_limit": 50,
    "max_retries": 1,
    "min_buyer_score": 50,  # AI 分析后，低于此分的客户不存入数据库
}

FILTER_CONFIG = {
    "match_threshold": 6,
    "max_customers_per_page": 20,
    "buyer_threshold": 50,  # 客户页面买家评分阈值
}

MAIL_CONFIG = {
    "batch_interval": 60,
    "daily_safe_limit": 50,
    "max_attachments_mb": 10,
}


# ═══════════════════════════════════════════════════════════════
# V4 新增：搜索引擎配置 + 用量跟踪
# ═══════════════════════════════════════════════════════════════

SEARCH_CONFIG_JSON = os.path.join(_BASE_DIR, "data", "search_config.json")
USAGE_LOG_JSON = os.path.join(_BASE_DIR, "data", "usage_log.json")


def get_search_config() -> dict:
    """获取搜索引擎配置（Google / Bing）。"""
    cfg = _load_config_json(SEARCH_CONFIG_JSON)
    if not cfg:
        return {"google": {"enabled": False}, "bing": {"enabled": False}}
    return cfg


def save_search_config(serpjet: dict = None, google: dict = None,
                        bing: dict = None, serper: dict = None) -> dict:
    """保存搜索引擎配置。"""
    cfg = _load_config_json(SEARCH_CONFIG_JSON)
    if serpjet:
        cfg["serpjet"] = serpjet
    if google:
        cfg["google"] = google
    if bing:
        cfg["bing"] = bing
    if serper:
        cfg["serper"] = serper
    os.makedirs(os.path.dirname(SEARCH_CONFIG_JSON), exist_ok=True)
    with open(SEARCH_CONFIG_JSON, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg


def get_search_mode() -> str:
    """获取搜索模式。"""
    cfg = _load_config_json(SEARCH_CONFIG_JSON)
    return cfg.get("mode", "google_first")


def get_target_regions() -> list:
    """获取目标搜索区域（国家列表）。"""
    cfg = _load_config_json(SEARCH_CONFIG_JSON)
    return cfg.get("target_regions", [])


def set_target_regions(regions: list) -> None:
    """设置目标搜索区域。"""
    cfg = _load_config_json(SEARCH_CONFIG_JSON)
    cfg["target_regions"] = regions
    with open(SEARCH_CONFIG_JSON, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def set_search_mode(mode: str) -> None:
    """设置搜索模式。"""
    cfg = _load_config_json(SEARCH_CONFIG_JSON)
    cfg["mode"] = mode
    with open(SEARCH_CONFIG_JSON, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def get_usage() -> dict:
    """获取今日使用记录。"""
    today = __import__("time").strftime("%Y-%m-%d")
    usage = _load_config_json(USAGE_LOG_JSON)
    if usage.get("date") != today:
        usage = {"date": today, "serpjet_used": 0, "serper_used": 0, "google_used": 0, "bing_used": 0, "logs": []}
        _save_usage(usage)
    return usage


def _save_usage(usage: dict) -> None:
    """保存使用记录。"""
    os.makedirs(os.path.dirname(USAGE_LOG_JSON), exist_ok=True)
    with open(USAGE_LOG_JSON, "w", encoding="utf-8") as f:
        json.dump(usage, f, ensure_ascii=False, indent=2)


def check_quota(engine: str) -> bool:
    """只检查配额是否足够，不记录消耗。

    Returns:
        True=还有配额，False=已达上限。
    """
    usage = get_usage()
    search_cfg = get_search_config()
    engine_cfg = search_cfg.get(engine, {})
    daily_limit = engine_cfg.get("daily_limit", 100)
    used = usage.get(f"{engine}_used", 0)
    return used < daily_limit


def record_search(engine: str, keyword: str, results_count: int = 0,
                   clean_count: int = 0, qualified_count: int = 0,
                   grade: str = "") -> bool:
    """记录一次搜索消耗，检查额度。

    Args:
        engine: 搜索引擎名称
        keyword: 搜索关键词
        results_count: API 返回的原始结果数
        clean_count: 清洗后结果数
        qualified_count: AI 分析通过数
        grade: 最高等级（A/B/C）

    Returns:
        True=额度足够，False=已达上限。
    """
    usage = get_usage()
    search_cfg = get_search_config()
    engine_cfg = search_cfg.get(engine, {})
    daily_limit = engine_cfg.get("daily_limit", 100)
    used = usage.get(f"{engine}_used", 0)

    if used >= daily_limit:
        return False

    usage[f"{engine}_used"] = used + 1
    usage.setdefault("logs", []).append({
        "time": __import__("time").strftime("%Y-%m-%d %H:%M:%S"),
        "engine": engine,
        "keyword": keyword,
        "results_count": results_count,
        "clean_count": clean_count,
        "qualified_count": qualified_count,
        "grade": grade,
    })
    _save_usage(usage)
    return True


def get_usage_stats() -> dict:
    """获取使用统计（前端展示用）。"""
    usage = get_usage()
    search_cfg = get_search_config()
    return {
        "date": usage.get("date", ""),
        "serpjet": {
            "used": usage.get("serpjet_used", 0),
            "limit": search_cfg.get("serpjet", {}).get("daily_limit", 100),
        },
        "serper": {
            "used": usage.get("serper_used", 0),
            "limit": search_cfg.get("serper", {}).get("daily_limit", 100),
        },
        "google": {
            "used": usage.get("google_used", 0),
            "limit": search_cfg.get("google", {}).get("daily_limit", 100),
        },
        "bing": {
            "used": usage.get("bing_used", 0),
            "limit": search_cfg.get("bing", {}).get("daily_limit", 100),
        },
        "total_logs": len(usage.get("logs", [])),
    }


def check_license() -> bool:
    """License 检查占位，当前始终返回 True。"""
    return True