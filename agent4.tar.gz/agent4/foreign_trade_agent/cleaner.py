"""
搜索结果清洗层（Cleaner）- V4 新增模块

在搜索结果进入 AI 分析之前，先用规则过滤掉明显无效的数据。

功能：
1. 排除垃圾结果：新闻、博客、招聘、PDF、Wiki、展会
2. 保留优质结果：公司官网、产品页、关于我们
3. 去重（按网站）

位置：search_engine → cleaner → AI analysis
"""

import logging
import re
from typing import List

logger = logging.getLogger(__name__)

# ── 排除规则 ──────────────────────────────────────────────────

EXCLUDE_URL_PATTERNS = [
    r"/blog/", r"/news/", r"/press/", r"/media/", r"/article/",
    r"/category/", r"/tag/", r"/author/",
    r"/job", r"/career", r"/careers", r"/hr/", r"/recruit",
    r"\.pdf$", r"\.doc$", r"\.docx$", r"\.ppt$", r"\.pptx$",
    r"/event", r"/events", r"/webinar", r"/exhibition", r"/trade-show",
    r"/conference", r"/summit",
    r"/forum", r"/community", r"/support",
    r"/login", r"/signup", r"/register",
    r"/cart", r"/checkout", r"/wishlist",
    r"/wiki/", r"/faq", r"/help",
]

EXCLUDE_DOMAINS = [
    "wikipedia.org", "youtube.com", "facebook.com", "twitter.com",
    "linkedin.com", "instagram.com", "reddit.com", "pinterest.com",
    "amazon.com", "ebay.com", "aliexpress.com", "alibaba.com",
    "made-in-china.com", "globalsources.com", "indiamart.com",
    "tradekey.com", "ecplaza.net", "exportersindia.com",
]

EXCLUDE_TITLE_KEYWORDS = [
    "news", "top 10", "best", "review", "how to", "what is",
    "buy now", "shop now", "free shipping", "sale",
]

PRIORITY_URL_PATTERNS = [
    r"/about", r"/about-us",
    r"/contact", r"/contact-us",
    r"/product", r"/products",
    r"/company", r"/factory",
    r"/manufacturer", r"/supplier",
    r"/who-we-are",
]


def clean(results: list[dict], target_countries: list = None) -> list[dict]:
    """对搜索结果进行清洗。

    Args:
        results: 搜索引擎返回的原始结果列表。
        target_countries: 目标国家列表（可选）。

    Returns:
        清洗后的结果列表。
    """
    if not results:
        return []

    before = len(results)
    logger.info(f"cleaner: 开始清洗 {before} 条结果")

    # 1. 去重
    seen_websites = set()
    deduped = []
    for r in results:
        w = (r.get("website") or "").strip().lower()
        if w and w not in seen_websites:
            seen_websites.add(w)
            deduped.append(r)
    logger.info(f"cleaner: 去重后 {len(deduped)} 条")

    # 2. URL 规则过滤
    url_filtered = []
    for r in deduped:
        url = (r.get("website") or "").strip().lower()
        name = r.get("company_name", "")[:40]
        if not url:
            logger.info(f"  reject [无URL] {name}")
            continue

        is_priority = any(re.search(p, url) for p in PRIORITY_URL_PATTERNS)
        domain_excluded = any(d in url for d in EXCLUDE_DOMAINS)
        path_excluded = any(re.search(p, url) for p in EXCLUDE_URL_PATTERNS)

        if is_priority and not domain_excluded:
            url_filtered.append(r)
            continue
        if domain_excluded:
            logger.info(f"  reject [域名排除] {name} ({url[:60]})")
            continue
        if path_excluded:
            # 明确是哪种路径排除
            for p in EXCLUDE_URL_PATTERNS:
                if re.search(p, url):
                    logger.info(f"  reject [路径排除] {name} ({p})")
                    break
            continue
        url_filtered.append(r)
    logger.info(f"cleaner: URL过滤后 {len(url_filtered)} 条")

    # 3. 标题关键词过滤
    title_filtered = []
    for r in url_filtered:
        title = (r.get("company_name") or "").lower()
        name = r.get("company_name", "")[:40]
        skip = False
        for kw in EXCLUDE_TITLE_KEYWORDS:
            if title.startswith(kw):
                skip = True
                logger.info(f"  reject [标题排除] {name} ({kw})")
                break
        if not skip:
            title_filtered.append(r)
    logger.info(f"cleaner: 标题过滤后 {len(title_filtered)} 条")

    # 4. 国家过滤 — 已关闭（国家维度交给 company_analyzer 的评分处理）
    #     不再硬性过滤，避免错过全球工程公司/渠道商
    if target_countries:
        logger.info(f"cleaner: 国家过滤已关闭（由 AI 评分替代），跳过过滤")
    country_filtered = title_filtered

    logger.info(f"cleaner: 清洗完成 {before} → {len(country_filtered)}")
    return country_filtered