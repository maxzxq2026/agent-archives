# 产品信息管理模块
# 支持 Excel 导入、手动录入、AI 搜索策略生成、多套产品档案切换

import json
import logging
import os
import re
from typing import Any, Dict, List, Optional

import pandas as pd

from config import API_CONFIG
from translator import ai_chat, translate_to_english

logger = logging.getLogger(__name__)

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
PRODUCTS_JSON = os.path.join(DATA_DIR, "products.json")
SEARCH_PLAN_PREFIX = "search_plan"  # 生成 {product_id}_search_plan.json

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PRODUCT_DATA_DIR, exist_ok=True)


# ── 内部工具 ──────────────────────────────────────────────────


def _load_products_db() -> dict:
    """加载整个 products.json（产品库 + 当前激活 ID）。"""
    if not os.path.exists(PRODUCTS_JSON):
        return {"products": {}, "active_product_id": None}
    with open(PRODUCTS_JSON, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_products_db(db: dict) -> None:
    """持久化 products.json。"""
    with open(PRODUCTS_JSON, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)


def _next_product_id(db: dict) -> str:
    """自增生成 product_id，格式 p001 / p002 …"""
    existing = set(db.get("products", {}).keys())
    n = 1
    while f"p{n:03d}" in existing:
        n += 1
    return f"p{n:03d}"


# ── 公开接口 ──────────────────────────────────────────────────


def load_excel(file_path: str) -> Optional[dict]:
    """读取 Excel 文件，提取产品信息。

    自动识别以下列名（支持中英文）：
        product_name / 产品名称
        specifications / 规格
        material / 材质
        description / 产品描述
        category / 产品类别
        price / 参考价格

    Returns:
        产品信息字典，失败返回 None。
    """
    if not os.path.exists(file_path):
        logger.error(f"load_excel: 文件不存在 {file_path}")
        return None

    try:
        df = pd.read_excel(file_path, engine="openpyxl")
    except Exception as e:
        logger.error(f"load_excel: 读取 Excel 失败 {e}")
        return None

    if df.empty:
        logger.warning("load_excel: Excel 为空")
        return {"products": []}

    # 列名映射（中文 → 英文）
    column_map = {
        "产品名称": "product_name",
        "规格": "specifications",
        "材质": "material",
        "产品描述": "description",
        "产品类别": "category",
        "参考价格": "price",
    }
    df_renamed = df.rename(columns=column_map)
    # 统一小写
    col_mapping_lower = {c: c.lower() for c in df_renamed.columns}
    df_renamed = df_renamed.rename(columns=col_mapping_lower)

    records = df_renamed.to_dict(orient="records")

    # 清洗空值
    cleaned = []
    for rec in records:
        cleaned.append({k: v if pd.notna(v) else "" for k, v in rec.items()})

    return {"products": cleaned, "total": len(cleaned)}


def save_product(product_data: dict) -> str:
    """保存产品信息到 products.json。

    支持两类输入：
        1. 来自 load_excel() 返回的 {"products": [...]} — 批量保存
        2. 单个产品字典 — 单条保存

    Returns:
        首个（或唯一）产品的 product_id。
    """
    db = _load_products_db()
    product_id = product_data.get("product_id") or _next_product_id(db)

    # 批量导入
    if "products" in product_data and isinstance(product_data["products"], list):
        first_id = None
        for item in product_data["products"]:
            pid = item.get("product_id") or _next_product_id(db)
            item["product_id"] = pid
            db["products"][pid] = item
            if first_id is None:
                first_id = pid
        product_id = first_id or product_id
    else:
        # 单条保存
        product_data["product_id"] = product_id
        db["products"][product_id] = product_data

    # 自动设为当前产品（如果还没有激活的话）
    if db.get("active_product_id") is None:
        db["active_product_id"] = product_id

    _save_products_db(db)
    logger.info(f"save_product: 已保存 product_id={product_id}")
    return product_id


def generate_search_plan(product_id: str) -> Optional[dict]:
    """根据产品信息生成搜索策略（调用大模型）。

    生成的 search_plan 保存至 product_data/{product_id}_search_plan.json。

    Returns:
        search_plan 字典，失败返回 None。
    """
    db = _load_products_db()
    product = db.get("products", {}).get(product_id)
    if product is None:
        logger.error(f"generate_search_plan: product_id={product_id} 不存在")
        return None

    # 组装产品描述
    product_desc = "\n".join(
        f"{k}: {v}" for k, v in product.items() if v and k != "product_id"
    )

    # 先翻译产品名称为英文
    product_name_cn = product.get("product_name", "")
    product_name_en = product_name_cn
    if product_name_cn:
        translated = translate_to_english(product_name_cn)
        if translated:
            product_name_en = translated

    system_prompt = (
        "你是一个外贸搜索策略专家。根据用户提供的产品信息，生成一份结构化的搜索策略。"
        "只输出合法的 JSON，不要包含 markdown 代码块标记。"
    )

    user_prompt = f"""产品信息：
{product_desc}

请生成以下 JSON 结构（严格遵循格式）：
{{
  "product_id": "{product_id}",
  "product_name": "{product_name_en}",
  "keywords": ["英文关键词1", "英文关键词2", ...],
  "target_industries": ["目标行业1", "目标行业2", ...],
  "target_countries": ["US", "DE", ...],
  "hs_codes": ["HS编码1", "HS编码2", ...],
  "competitors": ["竞争对手1", "竞争对手2", ...]
}}

要求：
- keywords 至少 5 个，从不同角度描述产品（产品名、材质、工艺、用途、采购术语）
- target_industries 至少 3 个
- target_countries 至少 5 个用两位国家代码
- hs_codes 至少 2 个
- competitors 至少 3 个
"""

    llm_result = ai_chat(
        messages=[{"role": "user", "content": user_prompt}],
        system_prompt=system_prompt,
        temperature=0.3,
    )
    if llm_result is None:
        return None

    # 尝试从结果中提取 JSON（可能包含 ```json ... ``` 包裹）
    try:
        # 去掉可能的 markdown 代码块包裹
        json_str = llm_result.strip()
        if "```" in json_str:
            json_str = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", json_str, re.DOTALL)
            if json_str:
                json_str = json_str.group(1)
            else:
                # fallback: 去掉所有 ``` 标记
                json_str = llm_result.replace("```json", "").replace("```", "").strip()
        search_plan = json.loads(json_str)
    except json.JSONDecodeError:
        logger.error(f"generate_search_plan: LLM 返回非 JSON, raw={llm_result[:200]}")
        return None

    # 补充必要字段
    search_plan.setdefault("product_id", product_id)
    search_plan.setdefault("product_name", product_name_en)

    # 持久化
    plan_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_{SEARCH_PLAN_PREFIX}.json")
    with open(plan_path, "w", encoding="utf-8") as f:
        json.dump(search_plan, f, ensure_ascii=False, indent=2)

    logger.info(f"generate_search_plan: 已保存 {plan_path}")
    return search_plan


def switch_product(product_id: str) -> Optional[dict]:
    """切换当前激活的产品。

    Returns:
        该产品的数据字典，如果 product_id 不存在返回 None。
    """
    db = _load_products_db()
    product = db.get("products", {}).get(product_id)
    if product is None:
        logger.error(f"switch_product: product_id={product_id} 不存在")
        return None

    db["active_product_id"] = product_id
    _save_products_db(db)
    logger.info(f"switch_product: 已切换到 product_id={product_id}")
    return product


def list_products() -> List[dict]:
    """列出所有已保存的产品档案。

    Returns:
        产品摘要列表（不含大字段），每个元素包含 product_id、product_name 等。
    """
    db = _load_products_db()
    active_id = db.get("active_product_id")
    result = []
    for pid, data in db.get("products", {}).items():
        summary = {
            "product_id": pid,
            "product_name": data.get("product_name", ""),
            "is_active": pid == active_id,
        }
        # 附带 search_plan 存在状态
        plan_path = os.path.join(
            PRODUCT_DATA_DIR, f"{pid}_{SEARCH_PLAN_PREFIX}.json"
        )
        summary["has_search_plan"] = os.path.exists(plan_path)
        result.append(summary)
    return result


def delete_product(product_id: str) -> bool:
    """删除指定产品及其 search_plan。

    Returns:
        True 表示删除成功，False 表示产品不存在。
    """
    db = _load_products_db()
    if product_id not in db.get("products", {}):
        return False

    del db["products"][product_id]

    # 如果删除的是当前激活产品，将 active 设为 None
    if db.get("active_product_id") == product_id:
        db["active_product_id"] = None

    _save_products_db(db)

    # 同时删除对应的 search_plan 文件
    plan_path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_{SEARCH_PLAN_PREFIX}.json")
    if os.path.exists(plan_path):
        os.remove(plan_path)

    logger.info(f"delete_product: 已删除 product_id={product_id}")
    return True