# Streamlit 应用入口
# 外贸获客助手 v1.0 — 6 个页面的完整可视化界面

import json
import logging
import os
import shutil
import tempfile
import time
import zipfile
from typing import Optional

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

# ── 配置 Streamlit 日志 ──────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

# ── 页面配置（必须在任何 st 命令之前） ──────────────────────
st.set_page_config(
    page_title="外贸获客助手 v1.0",
    page_icon="🌐",
    layout="wide",
    initial_sidebar_state="expanded",
)

# 将 Streamlit 文件上传器的英文替换为中文
st.markdown("""
<style>
    /* 拖拽提示文字 */
    [data-testid="stFileUploaderDropzoneInstructions"] > div > span {
        font-size: 0 !important;
    }
    [data-testid="stFileUploaderDropzoneInstructions"] > div > span::after {
        content: "将文件拖拽到此处，或点击选择文件" !important;
        font-size: 14px !important;
        white-space: nowrap !important;
    }
    /* 文件大小限制提示 */
    [data-testid="stFileUploaderDropzoneInstructions"] > div > small {
        font-size: 0 !important;
    }
    [data-testid="stFileUploaderDropzoneInstructions"] > div > small::after {
        content: "限制 200MB 每个文件 • XLSX" !important;
        font-size: 12px !important;
    }
    /* 选择文件按钮 */
    [data-testid="stFileUploaderDropzone"] button {
        font-size: 0 !important;
    }
    [data-testid="stFileUploaderDropzone"] button::after {
        content: "选择文件" !important;
        font-size: 14px !important;
    }
    /* Deploy 按钮 */
    [data-testid="stDeployButton"] span {
        font-size: 0 !important;
    }
    [data-testid="stDeployButton"] span::after {
        content: "部署" !important;
        font-size: 14px !important;
    }
    /* Deploy 弹窗标题 */
    [data-testid="stDeployDialog"] h2 {
        font-size: 0 !important;
    }
    [data-testid="stDeployDialog"] h2::after {
        content: "部署此应用" !important;
        font-size: 20px !important;
    }
    /* Streamlit Community Cloud */
    span:-webkit-any-contains("Streamlit Community Cloud") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("Streamlit Community Cloud")::after {
        content: "Streamlit 社区云" !important;
    }
    /* For the community */
    span:-webkit-any-contains("For the community") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("For the community")::after {
        content: "面向社区" !important;
    }
    /* Deploy unlimited public apps for free */
    span:-webkit-any-contains("Deploy unlimited public apps for free") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("Deploy unlimited public apps for free")::after {
        content: "免费部署无限数量的公共应用" !important;
    }
    /* Apps are discoverable */
    span:-webkit-any-contains("Apps are discoverable") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("Apps are discoverable")::after {
        content: "应用可通过 Streamlit 画廊和搜索引擎发现" !important;
    }
    /* Custom deployment */
    span:-webkit-any-contains("Custom deployment") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("Custom deployment")::after {
        content: "自定义部署" !important;
    }
    /* For companies */
    span:-webkit-any-contains("For companies") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("For companies")::after {
        content: "面向企业" !important;
    }
    /* Deploy on your own hardware */
    span:-webkit-any-contains("Deploy on your own hardware") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("Deploy on your own hardware")::after {
        content: "在您自己的硬件或云端部署，支持 Docker、Kubernetes 等" !important;
    }
    /* Set up your own authentication */
    span:-webkit-any-contains("Set up your own authentication") {
        font-size: 0 !important;
    }
    span:-webkit-any-contains("Set up your own authentication")::after {
        content: "设置您自己的身份验证" !important;
    }
</style>
""", unsafe_allow_html=True)

# ── 导入业务模块 ─────────────────────────────────────────────
from config import API_CONFIG, CRAWLER_CONFIG, FILTER_CONFIG, MAIL_CONFIG, save_api_config, API_CONFIG_JSON
from product_manager import (
    load_excel as pm_load_excel,
    save_product as pm_save_product,
    generate_search_plan as pm_generate_search_plan,
    switch_product as pm_switch_product,
    list_products as pm_list_products,
    delete_product as pm_delete_product,
)
from crawler import run as crawler_run, get_customers, _atomic_save_customers
from matcher import match_all
from mail_generator import generate_all

from ui_components import inject_enterprise_css, render_page_header

# ── 路径常量 ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCT_DATA_DIR = os.path.join(BASE_DIR, "product_data")
PRODUCTS_JSON = os.path.join(DATA_DIR, "products.json")
CUSTOMERS_JSON = os.path.join(DATA_DIR, "customers.json")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PRODUCT_DATA_DIR, exist_ok=True)

# 注入企业级 UI 样式
inject_enterprise_css()


# ═══════════════════════════════════════════════════════════════
# 工具函数
# ═══════════════════════════════════════════════════════════════

def safe_runner(func, *args, **kwargs):
    """安全执行函数，捕获异常返回友好提示。"""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        st.error(f"操作执行失败: {str(e)[:200]}")
        return None


def load_customers_from_disk() -> list:
    """从磁盘读取客户列表。"""
    if not os.path.exists(CUSTOMERS_JSON):
        return []
    try:
        with open(CUSTOMERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("customers", [])
    except Exception:
        return []


def load_search_plan_from_disk(product_id: str = "") -> Optional[dict]:
    """从磁盘读取 search_plan。"""
    if product_id:
        path = os.path.join(PRODUCT_DATA_DIR, f"{product_id}_search_plan.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        return None
    # 找最新的
    if not os.path.isdir(PRODUCT_DATA_DIR):
        return None
    files = [f for f in os.listdir(PRODUCT_DATA_DIR) if f.endswith("_search_plan.json")]
    if not files:
        return None
    files.sort(key=lambda f: os.path.getmtime(os.path.join(PRODUCT_DATA_DIR, f)), reverse=True)
    with open(os.path.join(PRODUCT_DATA_DIR, files[0]), "r", encoding="utf-8") as f:
        return json.load(f)


def get_products_summary() -> list:
    """获取产品摘要列表，带缓存。"""
    if "products_summary" not in st.session_state:
        st.session_state.products_summary = safe_runner(pm_list_products) or []
    return st.session_state.products_summary


def refresh_products():
    """刷新产品列表缓存。"""
    st.session_state.products_summary = safe_runner(pm_list_products) or []


def copy_button(text: str, label: str = "📋 复制到剪贴板", key: str = "copy"):
    """生成一个真正的复制到剪贴板按钮（使用 JavaScript）。"""
    import json as _json
    safe_text = _json.dumps(text)
    components.html(
        f"""
        <button onclick="navigator.clipboard.writeText({safe_text}); this.innerText='✅ 已复制'; this.style.color='#22c55e'"
                style="background:#1a1a2e; border:1px solid #6366f1; color:#e2e8f0; padding:6px 16px; border-radius:6px; cursor:pointer; font-size:14px;">
            {label}
        </button>
        """,
        height=40,
    )


# ═══════════════════════════════════════════════════════════════
# 侧边栏导航
# ═══════════════════════════════════════════════════════════════

PAGES = {
    "产品库": "product",
    "线索采集": "crawler",
    "客户管理": "customers",
    "邮件触达": "email",
    "系统设置": "settings",
    "数据导出": "export",
    "统计分析": "dashboard",
}

st.sidebar.title("外贸获客助手")

if "page" not in st.session_state:
    st.session_state.page = "product"

# 按键式导航，响应更快
for label, page_id in PAGES.items():
    is_active = st.session_state.page == page_id
    btn_type = "primary" if is_active else "secondary"
    if st.sidebar.button(label, key=f"nav_{page_id}", use_container_width=True, type=btn_type):
        st.session_state.page = page_id
        st.rerun()

st.sidebar.markdown("---")
st.sidebar.caption(f"数据目录: `{DATA_DIR}`")


# ═══════════════════════════════════════════════════════════════
# 页面路由
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
# 页面 1: 产品管理
# ─────────────────────────────────────────────────────────────

if st.session_state.page == "product":
    render_page_header(
        title="产品库",
        breadcrumb="首页 / 产品库",
        subtitle="维护产品档案、采集策略与投放要点",
    )

    tab1, tab2, tab3 = st.tabs(["📤 上传文件", "✏️ 手动输入", "🗂️ 产品档案"])

    # ── Tab 1: 上传 Excel ────────────────────────────────────
    with tab1:
        st.markdown("上传包含产品信息的 Excel 文件（.xlsx）")

        uploaded_file = st.file_uploader(
            "选择 Excel 文件",
            type=["xlsx"],
            label_visibility="collapsed",
            key="excel_uploader",
        )

        if uploaded_file is not None:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                tmp.write(uploaded_file.getvalue())
                tmp_path = tmp.name

            with st.spinner("正在读取 Excel..."):
                result = safe_runner(pm_load_excel, tmp_path)

            os.unlink(tmp_path)

            if result and result.get("products"):
                st.success(f"读取到 {result['total']} 条产品记录")
                st.dataframe(
                    pd.DataFrame(result["products"]),
                    use_container_width=True,
                    hide_index=True,
                )

                if st.button("💾 保存到产品库", type="primary", key="btn_save_excel"):
                    pid = safe_runner(pm_save_product, result)
                    if pid:
                        st.success(f"已保存，产品 ID: {pid}")
                        refresh_products()
            else:
                st.warning("未读取到产品数据，请检查 Excel 格式")

    # ── Tab 2: 手动输入 ──────────────────────────────────────
    with tab2:
        st.markdown("手动输入产品信息")

        col1, col2 = st.columns(2)
        with col1:
            manual_name = st.text_input("产品名称 *", key="manual_name")
            manual_spec = st.text_input("规格", key="manual_spec")
            manual_material = st.text_input("材质", key="manual_material")
            manual_cert = st.text_input("认证（如 ISO/CE）", key="manual_cert")
        with col2:
            manual_moq = st.text_input("MOQ", key="manual_moq")
            manual_capacity = st.text_input("产能/月", key="manual_capacity")
            manual_advantage = st.text_area("工厂优势", key="manual_advantage", height=100)

        if st.button("💾 保存产品", type="primary", key="btn_save_manual"):
            if not manual_name.strip():
                st.warning("请输入产品名称")
            else:
                product_data = {
                    "product_name": manual_name.strip(),
                    "specifications": manual_spec.strip(),
                    "material": manual_material.strip(),
                    "certification": manual_cert.strip(),
                    "moq": manual_moq.strip(),
                    "monthly_capacity": manual_capacity.strip(),
                    "factory_advantage": manual_advantage.strip(),
                }
                pid = safe_runner(pm_save_product, product_data)
                if pid:
                    st.success(f"已保存，产品 ID: {pid}")
                    refresh_products()

    # ── Tab 3: 产品档案 ──────────────────────────────────────
    with tab3:
        products = get_products_summary()

        if not products:
            st.info("暂无产品档案，请先上传或手动输入")
        else:
            product_options = {f"{p['product_id']} — {p['product_name']}": p for p in products}
            default_key = None
            for key, p in product_options.items():
                if p.get("is_active"):
                    default_key = key
                    break
            if default_key is None:
                default_key = list(product_options.keys())[0]

            selected_product = st.selectbox(
                "选择产品",
                list(product_options.keys()),
                index=list(product_options.keys()).index(default_key) if default_key in product_options else 0,
                key="product_selector",
            )

            if selected_product:
                prod = product_options[selected_product]
                pid = prod["product_id"]
                has_plan = prod.get("has_search_plan", False)

                col1, col2, col3 = st.columns([1, 2, 1])
                with col1:
                    if st.button("🔄 切换到此产品", type="primary", key="btn_switch"):
                        safe_runner(pm_switch_product, pid)
                        refresh_products()
                        st.success(f"已切换到 {pid}")
                        st.rerun()

                with col2:
                    if st.button("🤖 生成搜索策略", type="primary", key="btn_gen_plan"):
                        with st.spinner("正在调用 AI 生成搜索策略..."):
                            plan = safe_runner(pm_generate_search_plan, pid)
                        if plan:
                            st.success("搜索策略已生成")
                            st.session_state[f"plan_{pid}"] = plan
                            st.rerun()
                        elif plan is None:
                            st.warning("生成失败，请检查 API 配置")

                with col3:
                    if st.button("🗑️ 删除产品", type="secondary", key="btn_del_product"):
                        if safe_runner(pm_delete_product, pid):
                            st.success(f"已删除 {pid}")
                            refresh_products()
                            st.rerun()

                # 显示 search_plan
                plan_display = st.session_state.get(f"plan_{pid}") or load_search_plan_from_disk(pid)
                if plan_display:
                    with st.expander("📋 搜索策略详情", expanded=True):
                        col1, col2 = st.columns(2)
                        with col1:
                            st.markdown("**关键词**")
                            st.write("、".join(plan_display.get("keywords", [])))
                            st.markdown("**目标行业**")
                            st.write("、".join(plan_display.get("target_industries", [])))
                        with col2:
                            st.markdown("**目标国家**")
                            st.write("、".join(plan_display.get("target_countries", [])))
                            st.markdown("**HS 编码**")
                            st.write("、".join(plan_display.get("hs_codes", [])))
                            st.markdown("**竞争对手**")
                            st.write("、".join(plan_display.get("competitors", [])))


# ─────────────────────────────────────────────────────────────
# 页面 2: 爬虫控制
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "crawler":
    render_page_header(
        title="线索采集",
        breadcrumb="首页 / 线索采集",
        subtitle="配置采集流程，匹配线索并累计新增客户",
    )

    # 显示当前搜索策略
    plan = load_search_plan_from_disk()
    if plan:
        with st.expander("📋 当前搜索策略", expanded=True):
            cols = st.columns(4)
            cols[0].markdown(f"**产品**  \n{plan.get('product_name', 'N/A')}")
            cols[1].markdown(f"**关键词**  \n{'、'.join(plan.get('keywords', []))}")
            cols[2].markdown(f"**目标行业**  \n{'、'.join(plan.get('target_industries', []))}")

            country_map = {c: f"🌍 {c}" for c in plan.get("target_countries", [])}
            cols[3].markdown(f"**目标国家**  \n{'、'.join(country_map.keys())}")
    else:
        st.info("暂无搜索策略，请先在「产品管理」页面生成")

    st.markdown("---")

    # 爬虫控制区域
    col_start, col_status = st.columns([1, 2])

    with col_start:
        if st.button("▶️ 开始搜索", type="primary", key="btn_start_crawl", use_container_width=True):
            if not plan:
                st.warning("请先生成搜索策略")
            else:
                with st.spinner("正在搜索客户信息..."):
                    progress_bar = st.progress(0, text="初始化...")
                    progress_bar.progress(10, text="正在搜索 B2B 平台...")
                    success = safe_runner(crawler_run, plan.get("product_id", ""))
                    progress_bar.progress(80, text="搜索完成，正在处理...")

                if success:
                    progress_bar.progress(100, text="✅ 搜索完成")
                    st.success("爬虫搜索完成！")
                else:
                    progress_bar.progress(100, text="⚠️ 搜索完成（无结果）")
                    st.warning("搜索完成，但未找到符合条件的新客户")
                st.rerun()

    with col_status:
        customers = load_customers_from_disk()
        total = len(customers)
        with_email = sum(1 for c in customers if c.get("email"))
        high_priority = sum(1 for c in customers if c.get("priority") == "高")

        cols = st.columns(3)
        cols[0].metric("总客户数", total)
        cols[1].metric("有邮箱", with_email)
        cols[2].metric("高优先级", high_priority)

    # 最近搜索结果
    if customers:
        st.markdown("---")
        st.markdown("**最近搜索结果**")
        df = pd.DataFrame(customers)
        display_cols = [c for c in ["company_name", "country", "email", "priority", "score"] if c in df.columns]
        if display_cols:
            st.dataframe(df[display_cols].head(10), use_container_width=True, hide_index=True)


# ─────────────────────────────────────────────────────────────
# 页面 3: 客户列表
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "customers":
    render_page_header(
        title="客户管理",
        breadcrumb="首页 / 客户管理",
        subtitle="查看客户档案、处理状态与跟进进度",
    )

    customers = load_customers_from_disk()

    if not customers:
        st.info("暂无客户数据，请先在「爬虫控制」页面执行搜索")
    else:
        # 初始化选中状态
        if "selected_indices" not in st.session_state:
            st.session_state.selected_indices = set()
        if "expanded_customer" not in st.session_state:
            st.session_state.expanded_customer = None

        # 匹配分阈值滑块（与 FILTER_CONFIG 同步）
        _default_threshold = FILTER_CONFIG.get("match_threshold", 6)
        threshold = st.slider(
            "匹配分阈值",
            min_value=0, max_value=10, value=_default_threshold, step=1,
            key="threshold_slider",
            help="仅显示匹配分 ≥ 阈值的客户。此值也用于 AI 匹配打分判定。",
        )
        # 同步更新内存中配置，使 matcher 使用同一阈值
        FILTER_CONFIG["match_threshold"] = threshold

        # 过滤
        filtered = [c for c in customers if (c.get("score") or 0) >= threshold]

        st.caption(f"共 {len(customers)} 条客户，匹配分 ≥ {threshold} 的 {len(filtered)} 条")

        if not filtered:
            st.info(f"暂无匹配分 ≥ {threshold} 的客户")
        else:
            # 分页
            page_size = 20
            total_pages = max(1, (len(filtered) + page_size - 1) // page_size)
            if "page_num" not in st.session_state:
                st.session_state.page_num = 0

            page_num = st.session_state.page_num
            start_idx = page_num * page_size
            end_idx = min(start_idx + page_size, len(filtered))
            page_items = filtered[start_idx:end_idx]

            # 表格
            df_display = []
            for i, c in enumerate(page_items):
                global_idx = start_idx + i
                df_display.append({
                    "": "✅" if global_idx in st.session_state.selected_indices else "",
                    "公司名称": c.get("company_name", ""),
                    "国家": c.get("country", ""),
                    "官网": c.get("website", "")[:40],
                    "邮箱": c.get("email", ""),
                    "匹配分": c.get("score", "-"),
                    "优先级": c.get("priority", ""),
                })

            df = pd.DataFrame(df_display)
            event = st.dataframe(
                df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "": st.column_config.TextColumn("选中", width="small"),
                    "匹配分": st.column_config.NumberColumn(width="small"),
                    "优先级": st.column_config.TextColumn(width="small"),
                },
                key="customer_table",
            )

            # 行点击展开详情
            for i, c in enumerate(page_items):
                global_idx = start_idx + i
                col_a, col_b = st.columns([1, 20])
                with col_a:
                    checked = st.checkbox(
                        "选中",
                        key=f"sel_{global_idx}",
                        value=global_idx in st.session_state.selected_indices,
                        label_visibility="collapsed",
                    )
                    if checked:
                        st.session_state.selected_indices.add(global_idx)
                    else:
                        st.session_state.selected_indices.discard(global_idx)

                with col_b:
                    if st.button(
                        f"📄 {c.get('company_name', '')}",
                        key=f"expand_{global_idx}",
                        use_container_width=True,
                        type="secondary",
                    ):
                        if st.session_state.expanded_customer == global_idx:
                            st.session_state.expanded_customer = None
                        else:
                            st.session_state.expanded_customer = global_idx
                        st.rerun()

                # 展开详情
                if st.session_state.get("expanded_customer") == global_idx:
                    with st.container(border=True):
                        col1, col2 = st.columns(2)
                        with col1:
                            st.markdown(f"**公司名**: {c.get('company_name', '')}")
                            st.markdown(f"**国家**: {c.get('country', '')}")
                            st.markdown(f"**行业**: {c.get('industry', '')}")
                            st.markdown(f"**官网**: {c.get('website', '')}")
                        with col2:
                            st.markdown(f"**邮箱**: {c.get('email', '')}")
                            st.markdown(f"**匹配分**: {c.get('score', '-')}/10")
                            st.markdown(f"**优先级**: {c.get('priority', '')}")
                            st.markdown(f"**来源**: {c.get('source', '')}")
                        st.markdown(f"**采购需求**: {c.get('requirement', '无')}")
                        st.markdown(f"**匹配理由**: {c.get('match_reason', '无')}")
                        del_col, _ = st.columns([1, 5])
                        with del_col:
                            if st.button(f"🗑️ 删除此客户", key=f"del_customer_{global_idx}", type="secondary"):
                                cid = c.get("customer_id")
                                customers_all = load_customers_from_disk()
                                customers_all = [cc for cc in customers_all if cc.get("customer_id") != cid]
                                _atomic_save_customers(
                                    customers=customers_all,
                                    meta={"total": len(customers_all)},
                                    customers_json_path=CUSTOMERS_JSON,
                                )
                                st.success(f"已删除 {c.get('company_name', '')}")
                                st.session_state.pop("customers_cache", None)
                                st.rerun()

            # 分页控制
            col_prev, col_info, col_next = st.columns([1, 3, 1])
            with col_prev:
                if page_num > 0:
                    if st.button("◀ 上一页", use_container_width=True):
                        st.session_state.page_num -= 1
                        st.rerun()
            with col_info:
                st.markdown(f"<p style='text-align:center'>第 {page_num+1}/{total_pages} 页</p>", unsafe_allow_html=True)
            with col_next:
                if page_num < total_pages - 1:
                    if st.button("下一页 ▶", use_container_width=True):
                        st.session_state.page_num += 1
                        st.rerun()

            # 全选/取消
            col_all, col_clear, col_count = st.columns([1, 1, 3])
            with col_all:
                if st.button("✅ 全选当前页", use_container_width=True):
                    for i in range(start_idx, end_idx):
                        st.session_state.selected_indices.add(i)
                    st.rerun()
            with col_clear:
                if st.button("❌ 取消全选", use_container_width=True):
                    st.session_state.selected_indices.clear()
                    st.rerun()
            with col_count:
                st.caption(f"已选中 {len(st.session_state.selected_indices)} 条")


# ─────────────────────────────────────────────────────────────
# 页面 4: 开发信
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "email":
    render_page_header(
        title="邮件触达",
        breadcrumb="首页 / 邮件触达",
        subtitle="基于线索评分安排邮件内容与发送批次",
    )

    customers = load_customers_from_disk()

    if not customers:
        st.info("暂无客户数据")
    else:
        # 只显示达标的客户
        qualified = [c for c in customers if c.get("match_status") == "达标"]
        if not qualified:
            st.info("暂无达标客户，请先在「爬虫控制」执行匹配")
            matched_any = [c for c in customers if "score" in c]
            if matched_any:
                if st.button("🤖 AI 匹配打分", type="primary"):
                    with st.spinner("正在 AI 匹配..."):
                        safe_runner(match_all)
                    st.rerun()
            if st.button("✉️ 生成开发信", type="primary"):
                with st.spinner("正在生成开发信..."):
                    safe_runner(generate_all)
                st.rerun()
        else:
            # 选择客户
            options = {f"{c.get('company_name', '')} — {c.get('country', '')}": c for c in qualified}
            selected_email = st.selectbox("选择客户", list(options.keys()), key="email_customer_select")

            if selected_email:
                c = options[selected_email]

                # 如果还没有开发信，先生成
                if "mail_short" not in c or "mail_detailed" not in c:
                    st.info("该客户尚未生成开发信")
                    if st.button("✉️ 生成开发信", type="primary", key="btn_gen_email"):
                        with st.spinner("正在生成..."):
                            safe_runner(generate_all)
                        st.success("开发信已生成")
                        st.rerun()
                else:
                    # Tab 切换简短版/详细版
                    tab_short, tab_detailed = st.tabs(["📝 简短版", "📄 详细版"])

                    with tab_short:
                        content_short = st.text_area(
                            "简短版开发信（可编辑）",
                            value=c.get("mail_short", ""),
                            height=300,
                            key="mail_short_edit",
                        )
                        col1, col2, col3 = st.columns([1, 1, 1])
                        with col1:
                            copy_button(content_short)
                        with col2:
                            if st.button("✅ 标记为已处理", key="mark_short"):
                                # 防御性检查：如果 c 没有任何标识字段，提前报错
                                if not c.get("customer_id") and not c.get("website") and not c.get("email"):
                                    st.error("⚠️ 该客户缺少唯一标识（customer_id/website/email），无法更新")
                                    st.stop()
                                
                                # 更新客户状态（按 customer_id 定位，避免同名错改）
                                customers_all = load_customers_from_disk()
                                
                                # 确定查找 ID（优先 customer_id，降级到 website/email）
                                target_cid = c.get("customer_id")
                                if not target_cid:
                                    # 降级方案：用 website 或 email 作为备选 ID
                                    # 注意：不用 company_name，因为同名公司太多，容易误改
                                    target_cid = c.get("website") or c.get("email")
                                
                                # 遍历查找并更新
                                for cc in customers_all:
                                    cc_cid = cc.get("customer_id")
                                    if not cc_cid:
                                        # 老客户可能没有 customer_id，现场补一个
                                        cc_cid = cc.get("website") or cc.get("email")
                                    
                                    if cc_cid == target_cid and target_cid:
                                        cc["mail_status"] = "已处理"
                                        cc["mail_short"] = content_short
                                        break
                                
                                _atomic_save_customers(
                                    customers=customers_all,
                                    meta={"total": len(customers_all)},
                                    customers_json_path=CUSTOMERS_JSON,
                                )
                                st.success("已标记为已处理")
                                st.session_state.pop("customers_cache", None)
                                st.rerun()

                        with col3:
                            if st.button("📤 发送邮件", key="send_short"):
                                from mail_sender import send_email
                                from config import SMTP_CONFIG
                                cfg = SMTP_CONFIG.get("default", {})
                                if not cfg.get("smtp_server"):
                                    st.warning("请先在「设置」中配置 SMTP")
                                elif not c.get("email"):
                                    st.warning("该客户没有邮箱地址")
                                else:
                                    # 提取 subject 和 body
                                    lines = content_short.strip().split("\n", 1)
                                    subject = lines[0].replace("Subject:", "").strip() if lines[0].startswith("Subject:") else f"Partnership with {c.get('company_name', '')}"
                                    body = lines[1] if len(lines) > 1 else content_short
                                    success = send_email(
                                        to_email=c["email"],
                                        subject=subject,
                                        body=body,
                                    )
                                    if success:
                                        st.success(f"✅ 已发送到 {c['email']}")
                                    else:
                                        st.error("发送失败，请检查 SMTP 配置")

                    with tab_detailed:
                        content_detailed = st.text_area(
                            "详细版开发信（可编辑）",
                            value=c.get("mail_detailed", ""),
                            height=400,
                            key="mail_detailed_edit",
                        )
                        col1, col2, col3 = st.columns([1, 1, 1])
                        with col1:
                            copy_button(content_detailed)
                        with col2:
                            if st.button("✅ 标记为已处理", key="mark_detailed"):
                                # 防御性检查：如果 c 没有任何标识字段，提前报错
                                if not c.get("customer_id") and not c.get("website") and not c.get("email"):
                                    st.error("⚠️ 该客户缺少唯一标识（customer_id/website/email），无法更新")
                                    st.stop()
                                
                                # 更新客户状态（按 customer_id 定位，避免同名错改）
                                customers_all = load_customers_from_disk()
                                
                                # 确定查找 ID（优先 customer_id，降级到 website/email）
                                target_cid = c.get("customer_id")
                                if not target_cid:
                                    # 降级方案：用 website 或 email 作为备选 ID
                                    # 注意：不用 company_name，因为同名公司太多，容易误改
                                    target_cid = c.get("website") or c.get("email")
                                
                                # 遍历查找并更新
                                for cc in customers_all:
                                    cc_cid = cc.get("customer_id")
                                    if not cc_cid:
                                        # 老客户可能没有 customer_id，现场补一个
                                        cc_cid = cc.get("website") or cc.get("email")
                                    
                                    if cc_cid == target_cid and target_cid:
                                        cc["mail_status"] = "已处理"
                                        cc["mail_detailed"] = content_detailed
                                        break
                                
                                _atomic_save_customers(
                                    customers=customers_all,
                                    meta={"total": len(customers_all)},
                                    customers_json_path=CUSTOMERS_JSON,
                                )
                                st.success("已标记为已处理")
                                st.session_state.pop("customers_cache", None)
                                st.rerun()

                        with col3:
                            if st.button("📤 发送邮件", key="send_detailed"):
                                from mail_sender import send_email
                                from config import SMTP_CONFIG
                                cfg = SMTP_CONFIG.get("default", {})
                                if not cfg.get("smtp_server"):
                                    st.warning("请先在「设置」中配置 SMTP")
                                elif not c.get("email"):
                                    st.warning("该客户没有邮箱地址")
                                else:
                                    lines = content_detailed.strip().split("\n", 1)
                                    subject = lines[0].replace("Subject:", "").strip() if lines[0].startswith("Subject:") else f"Partnership with {c.get('company_name', '')}"
                                    body = lines[1] if len(lines) > 1 else content_detailed
                                    success = send_email(
                                        to_email=c["email"],
                                        subject=subject,
                                        body=body,
                                    )
                                    if success:
                                        st.success(f"✅ 已发送到 {c['email']}")
                                    else:
                                        st.error("发送失败，请检查 SMTP 配置")


# ─────────────────────────────────────────────────────────────
# 页面 5: 设置
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "settings":
    render_page_header(
        title="系统设置",
        breadcrumb="首页 / 系统设置",
        subtitle="配置代理、邮件发送、数据与运行参数",
    )

    tab_api, tab_smtp, tab_about = st.tabs(["🔌 API 配置", "📧 SMTP 邮件", "ℹ️ 关于"])

    with tab_api:
        st.markdown("配置 AI 服务连接信息，用于生成搜索策略、客户匹配打分、开发信等。")

        # 从 api_config.json 实时读取，确保页面切换后仍显示已保存的值
        import json as _json
        _cfg_path = API_CONFIG_JSON
        _saved = {}
        if os.path.isfile(_cfg_path):
            try:
                with open(_cfg_path, "r", encoding="utf-8") as _f:
                    _saved = _json.load(_f)
            except Exception:
                pass

        base_url = _saved.get("base_url", "")
        api_key = _saved.get("api_key", "")
        model = _saved.get("model", "")

        with st.form("api_config_form", clear_on_submit=False):
            col1, col2 = st.columns(2)
            with col1:
                new_base_url = st.text_input(
                    "API 地址",
                    value=base_url,
                    placeholder="https://api.openai.com/v1",
                    help="兼容 OpenAI 格式的 API 地址",
                )
                new_model = st.text_input(
                    "模型名称",
                    value=model,
                    placeholder="gpt-4o / qwen-plus / deepseek-chat",
                    help="填写你的模型名称",
                )
            with col2:
                new_api_key = st.text_input(
                    "API 密钥",
                    value=api_key if api_key else "",
                    type="password",
                    placeholder="sk-...",
                    help="你的 API 密钥",
                )

            st.markdown("---")
            if st.form_submit_button("💾 保存配置", type="primary", use_container_width=True):
                if not new_base_url.strip() or not new_api_key.strip():
                    st.error("API 地址和密钥不能为空")
                else:
                    save_api_config(new_base_url.strip(), new_api_key.strip(), new_model.strip())
                    st.success("✅ 配置已保存，刷新后生效")

                    # 提示重启
                    st.info(
                        "💡 部分模块（如爬虫、匹配）在下次操作时自动使用新配置，"
                        "无需重启应用。"
                    )

        # 显示当前配置状态
        st.markdown("---")
        st.markdown("**当前状态**")
        if base_url and api_key:
            masked_key = api_key[:6] + "****" + api_key[-4:] if len(api_key) > 12 else "****"
            st.markdown(f"- ✅ API 地址: `{base_url}`")
            st.markdown(f"- ✅ API 密钥: `{masked_key}`")
            st.markdown(f"- ✅ 模型: `{model or '未设置'}`")
        else:
            st.warning("⚠️ API 配置未完成，请填写后保存")

    with tab_smtp:
        st.markdown("配置 SMTP 邮件发送服务，用于直接发送开发信。")

        # 读取已保存的 SMTP 配置
        import json as _js
        _smtp_path = os.path.join(os.path.dirname(API_CONFIG_JSON), "smtp_config.json")
        _saved_smtp = {}
        if os.path.isfile(_smtp_path):
            try:
                with open(_smtp_path, "r", encoding="utf-8") as _f:
                    _saved_smtp = _js.load(_f)
            except Exception:
                pass

        with st.form("smtp_config_form", clear_on_submit=False):
            col1, col2 = st.columns(2)
            with col1:
                smtp_server = st.text_input("SMTP 服务器", value=_saved_smtp.get("smtp_server", ""), placeholder="smtp.example.com")
                smtp_port = st.number_input("端口", value=_saved_smtp.get("port", 465), min_value=1, max_value=65535, step=1)
                smtp_ssl = st.checkbox("使用 SSL", value=_saved_smtp.get("use_ssl", True))
            with col2:
                smtp_email = st.text_input("发件邮箱", value=_saved_smtp.get("email", ""), placeholder="your@email.com")
                smtp_password = st.text_input("邮箱密码/授权码", value=_saved_smtp.get("password", ""), type="password")

            if st.form_submit_button("💾 保存 SMTP 配置", type="primary", use_container_width=True):
                from config import save_smtp_config
                save_smtp_config(smtp_server, int(smtp_port), smtp_ssl, smtp_email, smtp_password)
                st.success("✅ SMTP 配置已保存")

        # 显示当前状态
        if _saved_smtp.get("smtp_server") and _saved_smtp.get("email"):
            pw = "****" if _saved_smtp.get("password") else "未设置"
            st.markdown(f"- ✅ SMTP: `{_saved_smtp['smtp_server']}:{_saved_smtp.get('port', 465)}`")
            st.markdown(f"- ✅ 邮箱: `{_saved_smtp['email']}`")
        else:
            st.warning("⚠️ SMTP 配置未完成，发送邮件功能不可用")

    with tab_about:
        st.markdown("### 🌐 外贸获客助手 v1.0")
        st.markdown("基于 AI 的外贸客户开发与邮件营销工具。")
        st.markdown("")
        st.markdown("**技术栈**: Streamlit + requests + BeautifulSoup + pandas")
        st.markdown("**数据目录**: `data/`")
        st.markdown("**依赖**: 见 `requirements.txt`")


# ─────────────────────────────────────────────────────────────
# 页面 6: 数据导出
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "export":
    render_page_header(
        title="数据导出",
        breadcrumb="首页 / 数据导出",
        subtitle="导出线索/客户/触达结果，便于对账与归档",
    )

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### 📄 导出 Excel")
        st.markdown("导出全部客户数据，包含公司信息、匹配分、开发信、发送状态")

        customers = load_customers_from_disk()
        if not customers:
            st.info("暂无客户数据可导出")
        else:
            if st.button("📤 导出 Excel", type="primary", use_container_width=True, key="btn_export_excel"):
                try:
                    df = pd.DataFrame(customers)
                    # 展开嵌套字段
                    for col in ["mail_short", "mail_detailed", "match_reason", "filter_reason"]:
                        if col in df.columns:
                            df[col] = df[col].astype(str)

                    export_path = os.path.join(DATA_DIR, "customers_export.xlsx")
                    df.to_excel(export_path, index=False, engine="openpyxl")
                    st.success(f"✅ 已导出: {export_path}")

                    with open(export_path, "rb") as f:
                        st.download_button(
                            "📥 下载 Excel",
                            data=f,
                            file_name="customers_export.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            use_container_width=True,
                        )
                except Exception as e:
                    st.error(f"导出失败: {str(e)[:200]}")

    with col2:
        st.markdown("### 📦 全量迁移包")
        st.markdown("打包 data/ 和 product_data/ 目录为 zip 文件")

        if st.button("📦 导出迁移包", type="primary", use_container_width=True, key="btn_export_zip"):
            try:
                zip_path = os.path.join(DATA_DIR, "backup_export.zip")
                with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                    for folder in ["data", "product_data"]:
                        folder_path = os.path.join(BASE_DIR, folder)
                        if os.path.isdir(folder_path):
                            for root, _, files in os.walk(folder_path):
                                for fn in files:
                                    if fn.endswith(".zip"):
                                        continue
                                    file_path = os.path.join(root, fn)
                                    arcname = os.path.relpath(file_path, BASE_DIR)
                                    zf.write(file_path, arcname)
                st.success(f"✅ 已打包: {zip_path} ({os.path.getsize(zip_path)/1024:.1f} KB)")

                with open(zip_path, "rb") as f:
                    st.download_button(
                        "📥 下载迁移包",
                        data=f,
                        file_name="backup_export.zip",
                        mime="application/zip",
                        use_container_width=True,
                    )
            except Exception as e:
                st.error(f"打包失败: {str(e)[:200]}")

    # 显示导出文件列表
    st.markdown("---")
    st.markdown("### 📂 数据目录")

    if os.path.isdir(DATA_DIR):
        files = [f for f in os.listdir(DATA_DIR) if os.path.isfile(os.path.join(DATA_DIR, f)) and not f.startswith(".")]
        if files:
            for f in sorted(files, key=lambda x: os.path.getmtime(os.path.join(DATA_DIR, x)), reverse=True):
                fpath = os.path.join(DATA_DIR, f)
                size = os.path.getsize(fpath)
                mtime = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(fpath)))
                st.text(f"  {mtime}  {size:>8,} B  {f}")


# ─────────────────────────────────────────────────────────────
# 页面 6: 统计看板
# ─────────────────────────────────────────────────────────────

elif st.session_state.page == "dashboard":
    render_page_header(
        title="统计分析",
        breadcrumb="首页 / 统计分析",
        subtitle="查看采集、评分、触达与新增客户的核心指标",
    )

    customers = load_customers_from_disk()
    total = len(customers)
    qualified = sum(1 for c in customers if c.get("match_status") == "达标")
    emailed = sum(1 for c in customers if c.get("mail_status") == "已处理" or ("mail_short" in c and c.get("mail_short")))
    high_priority = sum(1 for c in customers if c.get("priority") == "高")

    # 四个指标卡片
    cols = st.columns(4)
    with cols[0]:
        st.metric("累计客户数", total)
    with cols[1]:
        st.metric("达标客户", qualified)
    with cols[2]:
        st.metric("已生成邮件", emailed)
    with cols[3]:
        rate = f"{emailed/max(qualified, 1)*100:.0f}%" if qualified else "-"
        st.metric("邮件覆盖率", rate)

    st.markdown("---")

    if customers:
        col_chart1, col_chart2 = st.columns(2)

        # 柱状图：国家分布
        with col_chart1:
            st.markdown("**🌍 客户按国家分布**")
            country_counts = {}
            for c in customers:
                country = c.get("country", "未知")
                country_counts[country] = country_counts.get(country, 0) + 1

            if country_counts:
                df_country = pd.DataFrame(
                    sorted(country_counts.items(), key=lambda x: x[1], reverse=True),
                    columns=["国家", "客户数"],
                )
                st.bar_chart(df_country.set_index("国家"), height=300)

        # 饼图：匹配分数分布
        with col_chart2:
            st.markdown("**📊 匹配分数分布**")
            scored = [c.get("score", 0) for c in customers if "score" in c]
            if scored:
                bins = {"0-3分": 0, "4-6分": 0, "7-8分": 0, "9-10分": 0}
                for s in scored:
                    s = int(s)
                    if s <= 3:
                        bins["0-3分"] += 1
                    elif s <= 6:
                        bins["4-6分"] += 1
                    elif s <= 8:
                        bins["7-8分"] += 1
                    else:
                        bins["9-10分"] += 1

                df_score = pd.DataFrame(
                    list(bins.items()),
                    columns=["分数段", "客户数"],
                )
                st.bar_chart(df_score.set_index("分数段"), height=300, color="#ff9f43")

        # 优先级分布
        st.markdown("**⭐ 优先级分布**")
        priority_counts = {}
        for c in customers:
            pri = c.get("priority", "未分类")
            priority_counts[pri] = priority_counts.get(pri, 0) + 1
        if priority_counts:
            df_pri = pd.DataFrame(
                sorted(priority_counts.items(), key=lambda x: {"高": 0, "中": 1, "低": 2}.get(x[0], 9)),
                columns=["优先级", "客户数"],
            )
            st.bar_chart(df_pri.set_index("优先级"), height=200)
    else:
        st.info("暂无数据，请先在「爬虫控制」页面执行搜索")


# ═══════════════════════════════════════════════════════════════
# 底部免责声明
# ═══════════════════════════════════════════════════════════════

st.markdown("---")
st.markdown(
    "<p style='color:#e74c3c; font-size:13px; text-align:center;'>"
    "⚠️ 免责声明：工具不含跨境上网服务，批量邮件存在风险，发送前务必人工复核"
    "</p>",
    unsafe_allow_html=True,
)
