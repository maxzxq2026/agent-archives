# ui_components.py
import streamlit as st


def inject_enterprise_css():
    st.markdown(
        """
        <style>
        /* =============== 整体企业配色 =============== */
        .stApp { background-color:#f5f7fa; color:#262626; }
        html, body { background-color:#f5f7fa; color:#262626; font-size:14px; }

        /* =============== 页面标题栏（企业后台工具栏风） =============== */
        .page-header {
            background: #ffffff;
            border: 1px solid #e8eef6;
            border-radius: 10px;
            padding: 14px 16px;
            margin: 6px 0 16px 0;
            box-shadow: 0 1px 0 rgba(16,24,40,.02);
        }

        .page-header-top {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .breadcrumb {
            font-size: 12px;
            color: #8c8c8c;
            letter-spacing: .2px;
        }

        .page-title {
            font-size: 20px;
            font-weight: 700;
            color: #1f2a44;
            line-height: 1.2;
        }

        .page-subtitle {
            margin-top: 6px;
            font-size: 13px;
            color: #6b7280;
            line-height: 1.35;
        }

        /* =============== 侧边栏菜单按钮：扁平化 + active 高亮 =============== */
        section[data-testid="stSidebar"] .stButton button {
            background: transparent !important;
            border: none !important;
            border-radius: 0 !important;
            justify-content: flex-start !important;
            padding-left: 16px !important;
            height: 40px !important;
            font-size: 14px !important;
            color: #595959 !important;
            box-shadow: none !important;
        }

        section[data-testid="stSidebar"] .stButton button:hover {
            background: #f0f5ff !important;
            color: #1890ff !important;
        }

        /* active 页：primary 按钮（通过 kind 判断） */
        section[data-testid="stSidebar"] .stButton button[kind="primary"] {
            background: #e6f7ff !important;
            color: #1890ff !important;
            font-weight: 600 !important;
            border-right: 3px solid #1890ff !important;
        }

        /* =============== 可选：让按钮更企业风 =============== */
        .stButton > button {
            border-radius: 6px !important;
        }

        /* =============== 按钮色板收敛（Step A） =============== */
        /* 主按钮：深蓝 */
        .stButton > button[kind="primary"] {
            background: #1a3a5c !important;
            color: #ffffff !important;
            border: 1px solid #1a3a5c !important;
            font-weight: 500 !important;
        }
        .stButton > button[kind="primary"]:hover {
            background: #234b73 !important;
            border-color: #234b73 !important;
        }

        /* 次要按钮：灰底描边 */
        .stButton > button[kind="secondary"] {
            background: #ffffff !important;
            color: #4a5568 !important;
            border: 1px solid #d1d5db !important;
        }
        .stButton > button[kind="secondary"]:hover {
            background: #f9fafb !important;
            border-color: #9ca3af !important;
        }

        /* 分隔线 */
        hr, .stHorizontalBlock hr {
            border: none !important;
            border-top: 1px solid #e8eef6 !important;
            margin: 20px 0 !important;
        }

        /* =============== 卡片容器统一（Step B） =============== */
        /* 适用于 st.container(border=True) */
        div[data-testid="stVerticalBlockBorder"] {
            background: #ffffff;
            border: 1px solid #e8eef6 !important;
            border-radius: 8px;
            padding: 16px 16px 8px 16px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        }

        /* =============== 提示框沉稳化（Step B） =============== */
        div[data-testid="stAlert"] {
            border-radius: 6px;
            border-left: 4px solid;
            padding: 10px 14px !important;
        }
        /* 信息提示 */
        div[data-testid="stInfo"] {
            background: #f0f7ff;
            border-color: #1890ff;
        }
        /* 成功提示 */
        div[data-testid="stSuccess"] {
            background: #f0faf0;
            border-color: #52c41a;
        }
        /* 警告提示 */
        div[data-testid="stWarning"] {
            background: #fffbe6;
            border-color: #faad14;
        }
        /* 错误提示 */
        div[data-testid="stError"] {
            background: #fff2f0;
            border-color: #ff4d4f;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_page_header(title: str, breadcrumb: str = "", subtitle: str = ""):
    # 用一个容器把层级做出来（企业后台会这么做）
    breadcrumb_html = f'<div class="breadcrumb">{breadcrumb}</div>' if breadcrumb else ""
    subtitle_html = f'<div class="page-subtitle">{subtitle}</div>' if subtitle else ""

    st.markdown(
        f"""
        <div class="page-header">
            <div class="page-header-top">
                {breadcrumb_html}
                <div class="page-title">{title}</div>
            </div>
            {subtitle_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def open_toolbar():
    return st.container(border=True)


def open_card():
    return st.container(border=True)