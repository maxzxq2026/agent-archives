"""
公司网站联系邮箱扫描插件。

扫描目标公司网站的联系页面，寻找采购相关的邮箱地址。
"""

import logging
import re
from typing import Optional
from urllib.parse import urljoin, urlparse

import requests

from crawler_plugins._common import random_ua

logger = logging.getLogger(__name__)

# 优先匹配的采购类邮箱前缀
PRIORITY_PREFIXES = (
    "procurement", "purchasing", "supplychain",
    "vendor", "supplier", "sourcing",
    "buyer", "supply",
)

# 扫描路径，按优先级排序
SCAN_PATHS = [
    "/contact",
    "/contact-us",
    "/about",
    "/about-us",
    "/supplier",
    "/procurement",
    "/contactus",
    "/contact_us",
]

_EMAIL_PATTERN = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")


def scan(company_website: str) -> Optional[str]:
    """扫描目标公司网站，寻找采购类邮箱地址。

    依次访问 /contact, /about, /supplier, /procurement, /contact-us 等页面，
    优先匹配 procurement@, purchasing@, vendor@ 等采购相关邮箱前缀，
    同时提取所有 mailto: 链接和页面正文中的邮箱。

    Args:
        company_website: 公司网站 URL。可以带或不带协议前缀。

    Returns:
        找到的第一个邮箱地址，优先返回采购类邮箱；找不到返回 None。
    """
    # 规范化 URL
    base_url = _normalize_url(company_website)
    if not base_url:
        return None

    session = _build_scan_session()

    # 候选邮箱，按优先级收集
    priority_emails: list[str] = []
    fallback_emails: list[str] = []

    for path in SCAN_PATHS:
        page_url = urljoin(base_url, path)
        content = _fetch_page(page_url, session)
        if content is None:
            continue

        emails = _extract_emails(content)
        for email in emails:
            if email in priority_emails or email in fallback_emails:
                continue
            if any(email.lower().startswith(p) for p in PRIORITY_PREFIXES):
                priority_emails.append(email)
            else:
                fallback_emails.append(email)

        # 一旦找到优先邮箱，提前返回
        if priority_emails:
            return priority_emails[0]

    session.close()

    # 没有优先邮箱，返回第一个普通邮箱
    return fallback_emails[0] if fallback_emails else None


def _normalize_url(url: str) -> Optional[str]:
    """规范化公司网站 URL，确保可访问。"""
    url = url.strip().strip("/")
    if not url:
        return None
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    parsed = urlparse(url)
    if not parsed.netloc:
        return None
    return f"{parsed.scheme}://{parsed.netloc}"


def _build_scan_session() -> requests.Session:
    """创建用于扫描的 requests Session。"""
    session = requests.Session()
    session.headers.update({
        "User-Agent": random_ua(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    # 单次请求超时 15 秒，整体扫描不设硬限
    return session


def _fetch_page(url: str, session: requests.Session) -> Optional[str]:
    """获取页面 HTML 文本，失败返回 None。"""
    try:
        session.headers.update({"User-Agent": random_ua()})
        resp = session.get(url, timeout=15)
        if resp.status_code == 200:
            return resp.text
        else:
            logger.debug(f"HTTP {resp.status_code} 跳过: {url}")
            return None
    except requests.exceptions.Timeout:
        logger.debug(f"超时 15s: {url}")
        return None
    except requests.exceptions.ConnectionError:
        logger.debug(f"连接失败: {url}")
        return None
    except Exception as e:
        logger.debug(f"请求异常 ({url}): {e}")
        return None


def _extract_emails(html: str) -> list[str]:
    """从 HTML 中提取所有邮箱地址，去重后返回。"""
    emails: list[str] = []
    seen: set[str] = set()

    # 1. 从 mailto: 链接中提取
    for m in re.finditer(r'href\s*=\s*["\']mailto:([^"\']+)["\']', html, re.I):
        email = m.group(1).strip()
        if email and email not in seen:
            seen.add(email)
            emails.append(email)

    # 2. 从正文中提取所有邮箱
    for m in _EMAIL_PATTERN.finditer(html):
        email = m.group(0).strip()
        if email not in seen:
            seen.add(email)
            emails.append(email)

    return emails
