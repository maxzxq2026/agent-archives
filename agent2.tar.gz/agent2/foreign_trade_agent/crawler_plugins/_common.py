# 爬虫共享工具模块
# 提供 User-Agent 池、随机延时、安全 HTTP 请求等通用功能

import logging
import random
import re
import time
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# ── 10 个常见浏览器 User-Agent ──────────────────────────────
USER_AGENTS = [
    # Chrome 126 (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    # Chrome 126 (macOS)
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    # Chrome 125 (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    # Firefox 128 (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
    # Safari 17.5 (macOS)
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    # Edge 126 (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    # Chrome 126 (Linux)
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    # Firefox 127 (macOS)
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.5; rv:127.0) Gecko/20100101 Firefox/127.0",
    # Chrome 124 (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    # Edge 125 (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0",
]


def random_ua() -> str:
    """从 10 个常见 UA 中随机选一个返回。"""
    return random.choice(USER_AGENTS)


def random_delay(min_s: float = 1.0, max_s: float = 4.0) -> None:
    """随机等待 min_s ~ max_s 秒。"""
    delay = random.uniform(min_s, max_s)
    time.sleep(delay)


def build_session() -> requests.Session:
    """创建一个带随机 UA 的 requests Session。"""
    session = requests.Session()
    session.headers.update({
        "User-Agent": random_ua(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
    })
    return session


def safe_request(
    url: str,
    session: Optional[requests.Session] = None,
    timeout: int = 30,
    max_retries_429: int = 1,
) -> Optional[requests.Response]:
    """安全的 HTTP GET 请求，处理常见错误状态码。

    规则：
    - 429 (限流) → 暂停 60 秒后重试，最多重试 max_retries_429 次
    - 403 / 503 → 跳过，不重试，记录日志
    - 其他异常 → 返回 None，记录日志
    - 超时 30 秒

    Args:
        url: 请求 URL。
        session: 可选 Session 对象，不传则新建。
        timeout: 超时秒数，默认 30。
        max_retries_429: 429 后的最大重试次数，默认 1。

    Returns:
        Response 对象，失败返回 None。
    """
    close_session = False
    if session is None:
        session = build_session()
        close_session = True

    retries_left = max_retries_429

    while True:
        try:
            # 每次请求换 UA
            session.headers.update({"User-Agent": random_ua()})
            resp = session.get(url, timeout=timeout)

            if resp.status_code == 200:
                return resp

            # 429 Too Many Requests
            if resp.status_code == 429:
                if retries_left > 0:
                    retries_left -= 1
                    logger.warning(
                        f"429 限流 (url={url}), 暂停 60s 后重试, 剩余重试={retries_left}"
                    )
                    time.sleep(60)
                    continue
                else:
                    logger.error(f"429 限流且重试耗尽: {url}")
                    return None

            # 403 / 503 — 跳过，不重试
            if resp.status_code in (403, 503):
                logger.warning(f"HTTP {resp.status_code} 跳过: {url}")
                return None

            # 其他非 200 状态码
            logger.warning(f"HTTP {resp.status_code} (url={url})")
            return None

        except requests.exceptions.Timeout:
            logger.error(f"请求超时 (30s): {url}")
            return None
        except requests.exceptions.ConnectionError:
            logger.error(f"连接失败: {url}")
            return None
        except Exception as e:
            logger.error(f"请求异常 ({url}): {e}")
            return None
        finally:
            if close_session:
                session.close()


# ═══════════════════════════════════════════════════════════════
# 共享解析函数（三个爬虫插件共用）
# ═══════════════════════════════════════════════════════════════


def extract_text(soup_item, selectors: list) -> str:
    """按选择器优先级提取文本，找到即返回。"""
    for sel in selectors:
        el = soup_item.select_one(sel)
        if el:
            txt = el.get_text(strip=True)
            if txt:
                return txt
    return ""


def extract_country_from_text(text: str) -> str:
    """从文本中提取常见国家名。"""
    pattern = re.compile(
        r"\b(India|Pakistan|Bangladesh|Vietnam|Indonesia|Thailand|Malaysia|Philippines|"
        r"Singapore|South Korea|Japan|Taiwan|China|Turkey|UAE|Saudi Arabia|Egypt|"
        r"Nigeria|South Africa|Kenya|Ethiopia|Ghana|USA|Canada|Mexico|Brazil|Argentina|"
        r"Chile|Colombia|Peru|UK|Germany|France|Italy|Spain|Netherlands|Poland|"
        r"Australia|New Zealand|Russia|Ukraine|Kazakhstan|Uzbekistan|Korea|Iran|Iraq)\b",
        re.I,
    )
    m = pattern.search(text)
    return m.group(1) if m else ""


def is_domestic(entry: dict) -> bool:
    """判断是否国内买家（中国/香港），是则返回 True。"""
    country = (entry.get("country") or "").lower()
    if country in ("china", "cn", "hong kong", "hk"):
        return True
    name = entry.get("company_name", "")
    if re.search(r"[一-鿿]", name):
        return True
    return False